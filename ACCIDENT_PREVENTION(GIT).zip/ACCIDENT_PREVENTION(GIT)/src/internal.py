import cv2
import mediapipe as mp
import os
import time
import numpy as np
import winsound

from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ============================================================
# AI HELMET - COMBINED INTERNAL DRIVER AWARENESS
# Concentration + Drowsiness
# ONE CAMERA + ONE FACE LANDMARKER + ONE LOOP
# ============================================================


# ============================================================
# PROJECT PATH
# ============================================================

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

MODEL_PATH = os.path.join(
    PROJECT_ROOT,
    "models",
    "face_landmarker.task"
)

if not os.path.exists(MODEL_PATH):
    print("ERROR: face_landmarker.task not found!")
    print("Expected location:")
    print(MODEL_PATH)
    raise SystemExit


# ============================================================
# MEDIAPIPE
# ============================================================

base_options = python.BaseOptions(
    model_asset_path=MODEL_PATH
)

options = vision.FaceLandmarkerOptions(
    base_options=base_options,
    running_mode=vision.RunningMode.VIDEO,
    num_faces=1,
    min_face_detection_confidence=0.5,
    min_face_presence_confidence=0.5,
    min_tracking_confidence=0.5,
    output_face_blendshapes=False,
    output_facial_transformation_matrixes=False
)

landmarker = vision.FaceLandmarker.create_from_options(options)


# ============================================================
# CAMERA
# ============================================================

camera = cv2.VideoCapture(0)

if not camera.isOpened():
    print("ERROR: Camera could not be opened.")
    landmarker.close()
    raise SystemExit

camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)


# ============================================================
# LANDMARKS
# ============================================================

NOSE_TIP = 1
CHIN = 152

LEFT_EYE_OUTER = 33
RIGHT_EYE_OUTER = 263

LEFT_MOUTH = 61
RIGHT_MOUTH = 291

LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]


# ============================================================
# 3D FACE MODEL FOR HEAD POSE
# ============================================================

MODEL_POINTS = np.array(
    [
        (0.0, 0.0, 0.0),
        (0.0, -63.6, -12.5),
        (-43.3, 32.7, -26.0),
        (43.3, 32.7, -26.0),
        (-28.9, -28.9, -24.1),
        (28.9, -28.9, -24.1)
    ],
    dtype=np.float64
)


# ============================================================
# SETTINGS
# ============================================================

# Head-pose calibration
CALIBRATION_TIME = 3.0

# Concentration
YAW_THRESHOLD = 15.0
PITCH_THRESHOLD = 15.0
DISTRACTION_TIME = 2.0

# Adaptive drowsiness
# The driver's normal open-eye EAR is measured during startup.
# Drowsiness is detected when EAR falls below this fraction
# of the driver's normal baseline.
EAR_DROP_RATIO = 0.70
DROWSY_TIME = 1.5

# Warning
WARNING_INTERVAL = 1.5


# ============================================================
# STATE VARIABLES
# ============================================================

calibration_start = time.time()

calibration_yaw = []
calibration_pitch = []
ear_calibration = []

calibration_complete = False

baseline_yaw = 0.0
baseline_pitch = 0.0
baseline_ear = None

distraction_start = None
eyes_closed_start = None

last_warning_time = 0

# IMPORTANT: MediaPipe VIDEO mode requires a timestamp.
timestamp_ms = 0


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def get_landmark_point(landmarks, index, width, height):
    landmark = landmarks[index]
    return (
        landmark.x * width,
        landmark.y * height
    )


def calculate_head_pose(landmarks, width, height):
    try:
        image_points = np.array(
            [
                get_landmark_point(landmarks, NOSE_TIP, width, height),
                get_landmark_point(landmarks, CHIN, width, height),
                get_landmark_point(landmarks, LEFT_EYE_OUTER, width, height),
                get_landmark_point(landmarks, RIGHT_EYE_OUTER, width, height),
                get_landmark_point(landmarks, LEFT_MOUTH, width, height),
                get_landmark_point(landmarks, RIGHT_MOUTH, width, height)
            ],
            dtype=np.float64
        )

        focal_length = width

        camera_center = (
            width / 2,
            height / 2
        )

        camera_matrix = np.array(
            [
                [focal_length, 0, camera_center[0]],
                [0, focal_length, camera_center[1]],
                [0, 0, 1]
            ],
            dtype=np.float64
        )

        distortion_coefficients = np.zeros((4, 1))

        success, rotation_vector, _ = cv2.solvePnP(
            MODEL_POINTS,
            image_points,
            camera_matrix,
            distortion_coefficients,
            flags=cv2.SOLVEPNP_ITERATIVE
        )

        if not success:
            return None, None

        rotation_matrix, _ = cv2.Rodrigues(rotation_vector)

        angles = cv2.RQDecomp3x3(rotation_matrix)[0]

        pitch = angles[0]
        yaw = angles[1]

        return yaw, pitch

    except Exception:
        return None, None


def determine_direction(yaw, pitch, baseline_yaw, baseline_pitch):
    if yaw is None or pitch is None:
        return "UNKNOWN"

    yaw_difference = yaw - baseline_yaw
    pitch_difference = pitch - baseline_pitch

    if yaw_difference > YAW_THRESHOLD:
        return "LOOKING LEFT"

    if yaw_difference < -YAW_THRESHOLD:
        return "LOOKING RIGHT"

    if pitch_difference > PITCH_THRESHOLD:
        return "LOOKING DOWN"

    if pitch_difference < -PITCH_THRESHOLD:
        return "LOOKING UP"

    return "LOOKING FORWARD"


def distance(point1, point2):
    return np.linalg.norm(np.array(point1) - np.array(point2))


def calculate_ear(eye_points):
    vertical_1 = distance(eye_points[1], eye_points[5])
    vertical_2 = distance(eye_points[2], eye_points[4])
    horizontal = distance(eye_points[0], eye_points[3])

    if horizontal == 0:
        return 0.0

    return (vertical_1 + vertical_2) / (2.0 * horizontal)


def get_eye_points(landmarks, eye_indexes, width, height):
    points = []

    for index in eye_indexes:
        landmark = landmarks[index]
        points.append((landmark.x * width, landmark.y * height))

    return points


def play_warning(frequency, duration):
    try:
        winsound.Beep(frequency, duration)
    except Exception:
        pass


# ============================================================
# START
# ============================================================

print()
print("================================================")
print("        AI HELMET - DRIVER AWARENESS")
print("================================================")
print()
print("ONE CAMERA")
print("ONE MEDIAPIPE MODEL")
print("CONCENTRATION + DROWSINESS")
print()
print("For the first 3 seconds:")
print("LOOK STRAIGHT AHEAD WITH YOUR EYES NORMALLY OPEN.")
print()
print("Press Q to exit.")
print()


# ============================================================
# MAIN LOOP
# ============================================================

try:

    while True:

        # ----------------------------------------------------
        # READ ONE CAMERA FRAME
        # ----------------------------------------------------

        ret, frame = camera.read()

        if not ret:
            print("ERROR: Could not read camera.")
            break

        frame = cv2.flip(frame, 1)

        height, width, _ = frame.shape

        # ----------------------------------------------------
        # MEDIAPIPE IMAGE
        # ----------------------------------------------------

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        mp_image = mp.Image(
            image_format=mp.ImageFormat.SRGB,
            data=rgb_frame
        )

        # ----------------------------------------------------
        # ONE FACE DETECTION
        # ----------------------------------------------------

        result = landmarker.detect_for_video(mp_image, timestamp_ms)

        timestamp_ms += 33

        # ----------------------------------------------------
        # DEFAULT VALUES
        # (FIX: yaw/pitch must always exist, even on NO FACE
        #  frames, or the display code below crashes.)
        # ----------------------------------------------------

        concentration_status = "NO FACE"
        drowsiness_status = "NO FACE"
        awareness_status = "NO FACE"

        direction = "UNKNOWN"

        average_ear = 0.0

        distraction_duration = 0.0
        eyes_closed_duration = 0.0

        status_color = (0, 0, 255)

        yaw = None
        pitch = None
        left_eye = []
        right_eye = []

        # ====================================================
        # FACE FOUND
        # ====================================================

        if result.face_landmarks:

            landmarks = result.face_landmarks[0]

            # =================================================
            # HEAD POSE / CONCENTRATION
            # =================================================

            yaw, pitch = calculate_head_pose(landmarks, width, height)

            # -------------------------------------------------
            # CALIBRATION
            # -------------------------------------------------

            elapsed = time.time() - calibration_start

            # Collect EAR throughout initial calibration.
            left_eye = get_eye_points(landmarks, LEFT_EYE, width, height)
            right_eye = get_eye_points(landmarks, RIGHT_EYE, width, height)

            left_ear = calculate_ear(left_eye)
            right_ear = calculate_ear(right_eye)

            average_ear = (left_ear + right_ear) / 2.0

            if not calibration_complete:

                # Collect normal head pose
                if yaw is not None and pitch is not None:
                    calibration_yaw.append(yaw)
                    calibration_pitch.append(pitch)

                # Collect only reasonable open-eye values
                # for the adaptive EAR baseline.
                if 0.15 < average_ear < 0.60:
                    ear_calibration.append(average_ear)

                remaining = max(0.0, CALIBRATION_TIME - elapsed)

                concentration_status = "CALIBRATING"
                drowsiness_status = "CALIBRATING"
                awareness_status = "CALIBRATING"

                status_color = (0, 255, 255)

                if elapsed >= CALIBRATION_TIME:

                    # Head-pose baseline
                    if calibration_yaw:
                        baseline_yaw = float(np.median(calibration_yaw))
                        baseline_pitch = float(np.median(calibration_pitch))

                    # EAR baseline
                    if ear_calibration:
                        baseline_ear = float(np.median(ear_calibration))

                    # If EAR baseline couldn't be collected,
                    # use a conservative fallback.
                    if baseline_ear is None:
                        baseline_ear = 0.30

                    calibration_complete = True

                    print()
                    print("Calibration complete!")
                    print(f"Baseline yaw   : {baseline_yaw:.2f}")
                    print(f"Baseline pitch : {baseline_pitch:.2f}")
                    print(f"Baseline EAR   : {baseline_ear:.3f}")
                    print(
                        f"Adaptive EAR threshold: "
                        f"{baseline_ear * EAR_DROP_RATIO:.3f}"
                    )
                    print()

            else:

                # =================================================
                # CONCENTRATION
                # =================================================

                direction = determine_direction(
                    yaw, pitch, baseline_yaw, baseline_pitch
                )

                # FIX: this must match determine_direction()'s
                # actual return value: "LOOKING FORWARD" (space),
                # not "LOOKING_FORWARD" (underscore). This mismatch
                # was the reason it always reported DISTRACTED.
                if direction == "LOOKING FORWARD":

                    concentration_status = "CONCENTRATED"
                    distraction_start = None

                else:

                    if distraction_start is None:
                        distraction_start = time.time()

                    distraction_duration = time.time() - distraction_start

                    if distraction_duration >= DISTRACTION_TIME:
                        concentration_status = "DISTRACTED"
                    else:
                        concentration_status = direction

                # =================================================
                # DROWSINESS
                # =================================================

                dynamic_threshold = baseline_ear * EAR_DROP_RATIO

                if average_ear < dynamic_threshold:

                    if eyes_closed_start is None:
                        eyes_closed_start = time.time()

                    eyes_closed_duration = time.time() - eyes_closed_start

                    if eyes_closed_duration >= DROWSY_TIME:
                        drowsiness_status = "DROWSY"
                    else:
                        drowsiness_status = "EYES CLOSING"

                else:

                    eyes_closed_start = None
                    drowsiness_status = "ALERT"

                # =================================================
                # COMBINED AWARENESS
                # =================================================

                if concentration_status == "DISTRACTED" and drowsiness_status == "DROWSY":
                    awareness_status = "CRITICAL"
                    status_color = (0, 0, 255)

                elif drowsiness_status == "DROWSY":
                    awareness_status = "DROWSY"
                    status_color = (0, 0, 255)

                elif concentration_status == "DISTRACTED":
                    awareness_status = "DISTRACTED"
                    status_color = (0, 100, 255)

                elif drowsiness_status == "EYES CLOSING" or concentration_status != "CONCENTRATED":
                    awareness_status = "CAUTION"
                    status_color = (0, 255, 255)

                else:
                    awareness_status = "ALERT"
                    status_color = (0, 255, 0)

                # =================================================
                # AUDIO WARNING
                # =================================================

                current_time = time.time()

                if awareness_status in ("DISTRACTED", "DROWSY", "CRITICAL"):

                    if current_time - last_warning_time >= WARNING_INTERVAL:

                        if awareness_status == "CRITICAL":
                            play_warning(1600, 700)
                        elif awareness_status == "DROWSY":
                            play_warning(1400, 600)
                        else:
                            play_warning(1000, 500)

                        last_warning_time = current_time

            # =================================================
            # DRAW FACE LANDMARKS
            # =================================================

            for landmark in landmarks:
                x = int(landmark.x * width)
                y = int(landmark.y * height)

                cv2.circle(frame, (x, y), 1, (255, 255, 255), -1)

            # Draw eye landmarks
            for point in left_eye + right_eye:
                cv2.circle(
                    frame,
                    (int(point[0]), int(point[1])),
                    3,
                    (255, 255, 0),
                    -1
                )

        # ====================================================
        # NO FACE
        # ====================================================

        else:

            concentration_status = "NO FACE"
            drowsiness_status = "NO FACE"
            awareness_status = "NO DRIVER"

            status_color = (0, 0, 255)

            distraction_start = None
            eyes_closed_start = None

        # ====================================================
        # DISPLAY
        # ====================================================

        cv2.putText(
            frame,
            "AI HELMET - DRIVER AWARENESS",
            (30, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.75,
            (255, 255, 255),
            2
        )

        # Combined awareness
        cv2.putText(
            frame,
            f"AWARENESS: {awareness_status}",
            (30, 80),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            status_color,
            3
        )

        # Concentration
        cv2.putText(
            frame,
            f"CONCENTRATION: {concentration_status}",
            (30, 120),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2
        )

        # Head
        cv2.putText(
            frame,
            f"HEAD: {direction}",
            (30, 155),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2
        )

        # Drowsiness
        cv2.putText(
            frame,
            f"DROWSINESS: {drowsiness_status}",
            (30, 190),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2
        )

        # EAR
        if result.face_landmarks:

            cv2.putText(
                frame,
                f"EAR: {average_ear:.3f}",
                (30, 225),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )

            if baseline_ear is not None:

                dynamic_threshold = baseline_ear * EAR_DROP_RATIO

                cv2.putText(
                    frame,
                    f"EAR threshold: {dynamic_threshold:.3f}",
                    (30, 260),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.60,
                    (255, 255, 255),
                    2
                )

        # FIX: moved this block out of the "no face" text column
        # (was 30,190 / 30,225 -- overlapping EAR/drowsiness text)
        # and now guarded properly with correct indentation.
        if calibration_complete and yaw is not None and pitch is not None:

            yaw_diff = yaw - baseline_yaw
            pitch_diff = pitch - baseline_pitch

            cv2.putText(
                frame,
                f"Yaw diff: {yaw_diff:.1f}",
                (30, 295),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )

            cv2.putText(
                frame,
                f"Pitch diff: {pitch_diff:.1f}",
                (30, 330),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )

        # Looking-away timer
        if distraction_start is not None:

            cv2.putText(
                frame,
                f"Looking away: {distraction_duration:.1f}s",
                (30, 365),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (0, 255, 255),
                2
            )

        # Eyes-closed timer
        if eyes_closed_start is not None:

            cv2.putText(
                frame,
                f"Eyes closed: {eyes_closed_duration:.1f}s",
                (30, 400),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (0, 255, 255),
                2
            )

        # ====================================================
        # WARNING MESSAGE
        # ====================================================

        if awareness_status == "CRITICAL":

            cv2.putText(
                frame,
                "!!! DROWSY + DISTRACTED !!!",
                (30, 440),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.85,
                (0, 0, 255),
                3
            )

        elif awareness_status == "DROWSY":

            cv2.putText(
                frame,
                "WARNING: DROWSINESS DETECTED!",
                (30, 440),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.80,
                (0, 0, 255),
                3
            )

        elif awareness_status == "DISTRACTED":

            cv2.putText(
                frame,
                "WARNING: PLEASE FOCUS!",
                (30, 440),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.80,
                (0, 100, 255),
                3
            )

        # ====================================================
        # FOOTER
        # ====================================================

        cv2.putText(
            frame,
            "Press Q to exit",
            (30, height - 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.60,
            (255, 255, 255),
            2
        )

        # ====================================================
        # SHOW ONE WINDOW
        # ====================================================

        cv2.imshow("AI Helmet - Internal Driver Awareness", frame)

        # ====================================================
        # EXIT
        # ====================================================

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break


finally:

    camera.release()
    cv2.destroyAllWindows()
    landmarker.close()

    print()
    print("==========================================")
    print("Driver awareness monitoring stopped.")
    print("==========================================")
