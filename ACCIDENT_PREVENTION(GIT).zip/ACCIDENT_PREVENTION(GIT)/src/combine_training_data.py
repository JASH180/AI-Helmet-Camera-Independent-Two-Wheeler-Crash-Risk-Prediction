"""
combine_training_data.py

feature_collector.py is run once per video source (CCD, Kaggle -
different folders, different labels files, different --output names).
This script concatenates those outputs into one dataset/training_data.csv
that train_crash_model.py trains on.

Usage:
    python src/combine_training_data.py
"""

import os
import pandas as pd


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATASET_DIR = os.path.join(PROJECT_ROOT, "dataset")

INPUT_FILES = [
    os.path.join(DATASET_DIR, "training_data_ccd.csv"),
    os.path.join(DATASET_DIR, "training_data_kaggle.csv"),
    os.path.join(DATASET_DIR, "training_data_cyclist.csv"),
]

OUTPUT_FILE = os.path.join(DATASET_DIR, "training_data.csv")


def main():

    frames = []

    for path in INPUT_FILES:
        if os.path.exists(path):
            frame = pd.read_csv(path)
            frame["source"] = os.path.basename(path)
            frames.append(frame)
            print(f"Loaded {len(frame)} rows from {path}")
        else:
            print(f"(skipping, not found: {path})")

    if not frames:
        print("No training_data_*.csv files found - run feature_collector.py first.")
        return

    combined = pd.concat(frames, ignore_index=True)

    combined.to_csv(OUTPUT_FILE, index=False)

    print()
    print(f"Combined {len(combined)} total rows -> {OUTPUT_FILE}")
    print(f"Positive (pre-crash) rows: {combined['label'].sum()}")
    print(f"Negative rows: {(combined['label'] == 0).sum()}")


if __name__ == "__main__":
    main()
