"""
combine_universal_data.py - merges dataset/training_universal_*.csv into
dataset/training_universal.csv (source + viewpoint already inside each file).

    python src/combine_universal_data.py
"""
import os
import glob
import pandas as pd

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
D = os.path.join(ROOT, "dataset")
VIEW = {"ccd": "other_vehicle_dashcam", "kaggle": "other_vehicle_dashcam",
        "cyclist": "cyclist_pov", "gopro": "biker_gopro"}

frames = []
for path in sorted(glob.glob(os.path.join(D, "training_universal_*.csv"))):
    if path.endswith("training_universal.csv") or "before_relabel" in path:
        continue
    f = pd.read_csv(path)
    if "source" not in f:
        f["source"] = os.path.basename(path)[len("training_universal_"):-4]
    if "viewpoint" not in f:
        f["viewpoint"] = f["source"].map(VIEW).fillna(f["source"])
    # keep video ids unique across sources
    f["video_id"] = f["source"].astype(str) + "/" + f["video_id"].astype(str)
    frames.append(f)
    print(f"{os.path.basename(path)}: {len(f)} windows, {f['video_id'].nunique()} clips, "
          f"{100*f['label'].mean():.0f}% pre-crash")

if not frames:
    raise SystemExit("No training_universal_*.csv found - run universal_collector.py first.")

out = pd.concat(frames, ignore_index=True)
dups = out.duplicated(["video_id", "window_start_sec"]).sum()
if dups:
    raise SystemExit(f"{dups} duplicate windows found - a backup/old file is probably being merged. Remove it from dataset/.")
out.to_csv(os.path.join(D, "training_universal.csv"), index=False)
print(f"\nSaved {len(out)} windows -> dataset/training_universal.csv")
