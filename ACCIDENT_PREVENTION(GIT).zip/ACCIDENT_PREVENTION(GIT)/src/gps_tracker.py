import math


# ============================================================
# GPS DISTANCE CALCULATOR
# ============================================================

def calculate_distance(lat1, lon1, lat2, lon2):
    """
    Calculate distance between two GPS coordinates.
    Returns distance in kilometres.
    """

    # Radius of Earth in kilometres
    R = 6371.0

    # Convert degrees to radians
    lat1 = math.radians(lat1)
    lon1 = math.radians(lon1)

    lat2 = math.radians(lat2)
    lon2 = math.radians(lon2)

    # Difference
    dlat = lat2 - lat1
    dlon = lon2 - lon1

    # Haversine formula
    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1)
        * math.cos(lat2)
        * math.sin(dlon / 2) ** 2
    )

    c = 2 * math.atan2(
        math.sqrt(a),
        math.sqrt(1 - a)
    )

    distance = R * c

    return distance


# ============================================================
# GPS TRACKER
# ============================================================

class GPSTracker:

    def __init__(self):

        self.previous_latitude = None
        self.previous_longitude = None

        self.total_distance = 0.0


    # --------------------------------------------------------
    # ADD NEW GPS LOCATION
    # --------------------------------------------------------

    def update_location(
        self,
        latitude,
        longitude
    ):

        # First GPS reading
        if (
            self.previous_latitude is None
            or self.previous_longitude is None
        ):

            self.previous_latitude = latitude
            self.previous_longitude = longitude

            return 0.0


        # Calculate distance from previous location
        distance = calculate_distance(
            self.previous_latitude,
            self.previous_longitude,
            latitude,
            longitude
        )


        # Add to total distance
        self.total_distance += distance


        # Update previous location
        self.previous_latitude = latitude
        self.previous_longitude = longitude


        return distance


    # --------------------------------------------------------
    # GET TOTAL DISTANCE
    # --------------------------------------------------------

    def get_total_distance(self):

        return self.total_distance


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    print()
    print("====================================")
    print("       GPS TRACKER TEST")
    print("====================================")
    print()


    tracker = GPSTracker()


    # Starting location
    tracker.update_location(
        12.9716,
        77.5946
    )


    # Second GPS location
    distance = tracker.update_location(
        12.9750,
        77.6000
    )


    print(
        f"Distance travelled: {distance:.3f} km"
    )


    # Third GPS location
    distance = tracker.update_location(
        12.9800,
        77.6050
    )


    print(
        f"Additional distance: {distance:.3f} km"
    )


    print()
    print(
        f"TOTAL DISTANCE: "
        f"{tracker.get_total_distance():.3f} km"
    )

    print()
    print("GPS tracker working successfully!")