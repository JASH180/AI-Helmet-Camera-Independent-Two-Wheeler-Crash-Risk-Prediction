import os
import cv2
import winsound
import time

from ultralytics import YOLO

from road_risk import (
    calculate_vehicle_risk,
    is_road_vehicle
)

from data_logger import log_event

# The trained "is a crash about to happen" model, if it exists.
# Trained by src/train_crash_model.py on Crash-1500/Normal + Kaggle +
# cyclist footage. summarize_window/FEATURE_COLUMNS come from
# crash_features.py so the live numbers are computed exactly the same
# way as training.
from crash_features import summarize_window, FEATURE_COLUMNS

try:
    import joblib
    JOBLIB_AVAILABLE = True
except ImportError:
    JOBLIB_AVAILABLE = False

try:
    import xgboost as xgb
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False


# ============================================================
# SETTINGS
# ============================================================

MODEL_NAME = "yolo11n.pt"

CONFIDENCE = 0.45

WARNING_INTERVAL = 2.0

last_warning_time = 0

last_logged_time = 0

LOG_INTERVAL = 3.0

# ------------------------------------------------------------
# CRASH-PREDICTION MODEL SETTINGS
# ------------------------------------------------------------

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

# train_crash_model.py now saves a generic .joblib file (it may be an
# XGBoost model, Random Forest, Voting ensemble, etc. - whichever won
# the model comparison). The old XGBoost-only .json path is kept as a
# fallback so this still works even if you haven't retrained yet.
CRASH_MODEL_PATH_JOBLIB = os.path.join(
    PROJECT_ROOT, "models", "crash_risk_model.joblib"
)

CRASH_MODEL_PATH_JSON_LEGACY = os.path.join(
    PROJECT_ROOT, "models", "crash_risk_model.json"
)

# How many seconds of frames get aggregated into one prediction.
# Must match WINDOW_SECONDS in feature_collector.py (training side).
CRASH_WINDOW_SECONDS = 1.0

# Predicted probability (0-1) above which we raise a crash alert.
# NOTE: tune this based on your train_crash_model.py results.
CRASH_ALERT_THRESHOLD = 0.75

crash_model = None

if JOBLIB_AVAILABLE and os.path.exists(CRASH_MODEL_PATH_JOBLIB):

    crash_model = joblib.load(CRASH_MODEL_PATH_JOBLIB)

    print(f"Crash prediction model loaded from {CRASH_MODEL_PATH_JOBLIB}")
    print(f"  (model type: {type(crash_model).__name__})")

elif XGBOOST_AVAILABLE and os.path.exists(CRASH_MODEL_PATH_JSON_LEGACY):

    crash_model = xgb.XGBClassifier()
    crash_model.load_model(CRASH_MODEL_PATH_JSON_LEGACY)

    print(f"Crash prediction model loaded from {CRASH_MODEL_PATH_JSON_LEGACY} (legacy format)")
    print("  Run src/train_crash_model.py to upgrade to the newer, compared model.")

else:

    print()
    print("NOTE: no crash_risk_model.joblib or crash_risk_model.json found.")
    print("Road monitoring will still run using the rule-based risk score,")
    print("but the trained 'accident about to happen' alert is disabled")
    print("until you run the training pipeline.")
    print()

# Rolling buffer of this-window's per-frame feature dicts, in the
# exact shape crash_features.summarize_window() expects.
crash_window_frames = []
crash_window_start_time = time.time()


last_crash_alert_time = 0
CRASH_ALERT_INTERVAL = 2.0
last_crash_probability = None

# ------------------------------------------------------------
# LIVE RIDE LOG - what makes the R dashboard "live"
# ------------------------------------------------------------
# Every window (once per CRASH_WINDOW_SECONDS), we append one row
# here with everything the R Shiny dashboard needs. RStudio's
# reactivePoll() re-reads this file every second and redraws the
# charts - so as you actually ride, the dashboard updates itself
# with no manual steps in between.

import csv
import datetime

LIVE_LOG_PATH = os.path.join(PROJECT_ROOT, "dataset", "live_ride_log.csv")

# Built from FEATURE_COLUMNS (crash_features.py) rather than hardcoded,
# so adding/changing features there doesn't silently break this logger.
LIVE_LOG_COLUMNS = (
    ["timestamp", "elapsed_sec"]
    + FEATURE_COLUMNS
    + ["crash_probability", "status"]
)

ride_start_time = time.time()

RIDES_ARCHIVE_DIR = os.path.join(PROJECT_ROOT, "dataset", "rides")


def archive_previous_ride():
    """If a previous session left a live_ride_log.csv behind, move it
    into dataset/rides/ (named by when it was last written) so each
    ride becomes its own file. The Shiny dashboard's Compare Rides tab
    reads that folder, so you can compare today's ride with earlier
    ones. The live log then starts fresh for this session."""

    try:
        if not os.path.exists(LIVE_LOG_PATH) or os.path.getsize(LIVE_LOG_PATH) < 200:
            return

        os.makedirs(RIDES_ARCHIVE_DIR, exist_ok=True)
        stamp = datetime.datetime.fromtimestamp(os.path.getmtime(LIVE_LOG_PATH)).strftime("%Y%m%d_%H%M%S")
        os.replace(LIVE_LOG_PATH, os.path.join(RIDES_ARCHIVE_DIR, f"ride_{stamp}.csv"))
        print(f"Previous ride archived to dataset/rides/ride_{stamp}.csv")
    except OSError as error:
        print(f"Could not archive previous ride log ({error}); continuing.")


archive_previous_ride()


def status_from_probability(probability):
    if probability is None:
        return "UNKNOWN"
    score = probability * 100
    if score < 30:
        return "SAFE"
    elif score < 60:
        return "CAUTION"
    elif score < 80:
        return "HIGH RISK"
    else:
        return "CRITICAL"


def log_live_window(feature_row, probability):
    """Appends one row to dataset/live_ride_log.csv - this file is
    what the R Shiny dashboard watches to redraw itself live."""

    file_exists = os.path.exists(LIVE_LOG_PATH)

    os.makedirs(os.path.dirname(LIVE_LOG_PATH), exist_ok=True)

    with open(LIVE_LOG_PATH, "a", newline="", encoding="utf-8") as file:

        writer = csv.DictWriter(file, fieldnames=LIVE_LOG_COLUMNS)

        if not file_exists:
            writer.writeheader()

        row = {
            "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
            "elapsed_sec": round(time.time() - ride_start_time, 1),
            "crash_probability": round(probability, 3) if probability is not None else "",
            "status": status_from_probability(probability),
        }
        row.update(feature_row)

        writer.writerow(row)


def predict_crash_probability(feature_row):
    """Turns one window's summarized feature row into a single crash
    probability using the trained model. Returns None if no model
    is loaded or the feature row is empty."""

    if crash_model is None or feature_row is None:
        return None

    ordered_values = [[feature_row[column] for column in FEATURE_COLUMNS]]

    probability = crash_model.predict_proba(ordered_values)[0][1]

    return float(probability)


# ============================================================
# LOAD YOLO
# ============================================================

print()
print("Loading YOLO model...")

model = YOLO(MODEL_NAME)

print("YOLO model loaded successfully.")


# ============================================================
# OPEN PHONE CAMERA
# ============================================================
#
# This is meant to be your PHONE acting as the outward-facing
# camera (mounted on the helmet/handlebars), NOT the laptop's
# built-in webcam - that's already used by internal.py for the
# driver-facing camera, and only one process can hold a given
# camera device at a time.
#
# Two ways to connect a phone as CAMERA_SOURCE below:
#
#   A) Network stream (recommended - works over WiFi, no drivers,
#      no USB cable, most reliable):
#        - Android: install the "IP Webcam" app (Pavel Khlebovich),
#          open it, tap "Start server". It shows a URL like
#          http://192.168.1.42:8080
#          Set CAMERA_SOURCE = "http://192.168.1.42:8080/video"
#        - iPhone: install "IP Camera Lite" or similar, same idea -
#          it gives you an http:// stream URL to paste below.
#        Your phone and laptop must be on the SAME WiFi network.
#
#   B) USB virtual webcam (DroidCam / iVCam / EpocCam): install the
#      app on your phone AND its companion driver on Windows, plug
#      in via USB (or use their WiFi mode), it then shows up as a
#      numbered camera device. Set CAMERA_SOURCE = 1 (or try 2, 3...
#      until it works - Device Manager > Cameras shows the index).

CAMERA_SOURCE = "http://192.168.1.42:8080/video"  # <-- EDIT THIS to your phone's IP Webcam URL (option A), or an integer like 1 (option B)

camera = cv2.VideoCapture(CAMERA_SOURCE)

if not camera.isOpened():

    print(f"ERROR: could not open CAMERA_SOURCE = {CAMERA_SOURCE!r}")
    print()
    print("This must be your PHONE, not the laptop webcam (camera 0 is")
    print("already used by internal.py for the driver-facing camera).")
    print()
    print("If using the IP Webcam Android app: confirm the app shows")
    print("'Start server' as active, and that CAMERA_SOURCE above exactly")
    print("matches the http://<ip>:8080/video address it displays, and")
    print("that your phone + laptop are on the same WiFi network.")
    print()
    print("If using DroidCam/iVCam (USB/virtual webcam): try changing")
    print("CAMERA_SOURCE above to 1, then 2, etc. - check Windows Device")
    print("Manager > Cameras for the exact device your phone app created.")
    exit()


# ============================================================
# CAMERA RESOLUTION
# ============================================================

camera.set(
    cv2.CAP_PROP_FRAME_WIDTH,
    1280
)

camera.set(
    cv2.CAP_PROP_FRAME_HEIGHT,
    720
)


print()
print("==========================================")
print("       AI HELMET ROAD SAFETY")
print("==========================================")
print()
print("External camera: READY")
print("YOLO tracking: READY")
print("Warning logger: READY")
print()
print("Press Q to stop.")
print()


# ============================================================
# PREVIOUS OBJECT SIZES
# ============================================================

previous_sizes = {}

# Network phone streams occasionally drop/corrupt a single frame -
# that shouldn't kill the whole program. Only give up if reads fail
# for a long, continuous stretch (real disconnect).
consecutive_failures = 0
MAX_CONSECUTIVE_FAILURES = 60  # ~a couple seconds of bad frames


# ============================================================
# MAIN LOOP
# ============================================================

while True:

    # --------------------------------------------------------
    # READ FRAME
    # --------------------------------------------------------

    ret, frame = camera.read()

    if not ret:

        consecutive_failures += 1

        if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
            print(
                f"Could not read camera for {MAX_CONSECUTIVE_FAILURES} "
                f"frames in a row - assuming real disconnect."
            )
            break

        # Single/occasional bad frame (common on WiFi MJPEG streams) -
        # just skip it and try the next one.
        continue

    consecutive_failures = 0


    frame = cv2.flip(
        frame,
        1
    )


    height, width, _ = frame.shape


    # ========================================================
    # YOLO TRACKING
    # ========================================================

    results = model.track(
        frame,
        persist=True,
        conf=CONFIDENCE,
        verbose=False
    )


    result = results[0]


    # ========================================================
    # DEFAULT SYSTEM STATUS
    # ========================================================

    highest_risk = 0

    highest_status = "SAFE"

    danger_object = "NONE"

    approaching_object = "NONE"

    # Feed the crash-prediction model - same shape as crash_features.py
    frame_object_count = 0

    frame_max_growth_ratio = 0.0


    # ========================================================
    # PROCESS OBJECTS
    # ========================================================

    if result.boxes is not None:

        for box in result.boxes:

            # ------------------------------------------------
            # CLASS
            # ------------------------------------------------

            class_id = int(
                box.cls[0]
            )

            class_name = model.names[
                class_id
            ]


            # ------------------------------------------------
            # ONLY ROAD VEHICLES
            # ------------------------------------------------

            if not is_road_vehicle(
                class_name
            ):

                continue


            # ------------------------------------------------
            # CONFIDENCE
            # ------------------------------------------------

            confidence = float(
                box.conf[0]
            )


            # ------------------------------------------------
            # TRACK ID
            # ------------------------------------------------

            if box.id is not None:

                track_id = int(
                    box.id[0]
                )

            else:

                track_id = -1


            # ------------------------------------------------
            # BOUNDING BOX
            # ------------------------------------------------

            x1, y1, x2, y2 = map(
                int,
                box.xyxy[0]
            )


            # ------------------------------------------------
            # OBJECT AREA
            # ------------------------------------------------

            object_width = x2 - x1

            object_height = y2 - y1

            current_area = (
                object_width *
                object_height
            )


            # ------------------------------------------------
            # APPROACHING CALCULATION
            # ------------------------------------------------

            growth_ratio = 0.0

            approaching = False


            if track_id != -1:

                previous_area = previous_sizes.get(
                    track_id
                )


                if previous_area is not None:

                    growth_ratio = (
                        (
                            current_area
                            - previous_area
                        )
                        / previous_area
                    )


                    if growth_ratio > 0.10:

                        approaching = True


                previous_sizes[
                    track_id
                ] = current_area


            # ------------------------------------------------
            # RISK
            # ------------------------------------------------

            risk, risk_status = calculate_vehicle_risk(
                x1,
                y1,
                x2,
                y2,
                width,
                height,
                growth_ratio
            )

            frame_object_count += 1

            frame_max_growth_ratio = max(frame_max_growth_ratio, growth_ratio)


            # ------------------------------------------------
            # SAVE HIGHEST RISK
            # ------------------------------------------------

            if risk > highest_risk:

                highest_risk = risk

                highest_status = risk_status

                danger_object = (
                    f"{class_name} "
                    f"#{track_id}"
                )


            if approaching:

                approaching_object = (
                    f"{class_name} "
                    f"#{track_id}"
                )


            # =================================================
            # BOX COLOUR
            # =================================================

            if risk_status == "CRITICAL":

                box_color = (
                    0,
                    0,
                    255
                )

            elif risk_status == "HIGH":

                box_color = (
                    0,
                    100,
                    255
                )

            elif risk_status == "MEDIUM":

                box_color = (
                    0,
                    255,
                    255
                )

            else:

                box_color = (
                    0,
                    255,
                    0
                )


            # =================================================
            # DRAW BOX
            # =================================================

            cv2.rectangle(
                frame,
                (x1, y1),
                (x2, y2),
                box_color,
                3
            )


            # =================================================
            # LABEL
            # =================================================

            label = (
                f"{class_name} "
                f"ID:{track_id} "
                f"{confidence * 100:.0f}%"
            )


            cv2.putText(
                frame,
                label,
                (
                    x1,
                    max(
                        y1 - 10,
                        20
                    )
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                box_color,
                2
            )


            # =================================================
            # APPROACHING LABEL
            # =================================================

            if approaching:

                cv2.putText(
                    frame,
                    "APPROACHING",
                    (
                        x1,
                        min(
                            y2 + 25,
                            height - 10
                        )
                    ),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 0, 255),
                    3
                )


    # ========================================================
    # CRASH-PREDICTION MODEL: FEED THIS FRAME INTO THE WINDOW
    # ========================================================

    crash_window_frames.append({
        "risk_score": highest_risk,
        "risk_status": highest_status,
        "object_count": frame_object_count,
        "growth_ratio": frame_max_growth_ratio,
    })

    crash_probability = None

    now = time.time()

    if now - crash_window_start_time >= CRASH_WINDOW_SECONDS:

        feature_row = summarize_window(crash_window_frames)
        crash_probability = predict_crash_probability(feature_row)

        if feature_row is not None:
            log_live_window(feature_row, crash_probability)

        crash_window_frames = []
        crash_window_start_time = now

        if crash_probability is not None:
            last_crash_probability = crash_probability

    # Keep showing the most recent prediction between windows,
    # rather than blanking it out every frame.
    if crash_probability is None:
        crash_probability = last_crash_probability


    # ========================================================
    # DISPLAY RISK
    # ========================================================

    if highest_status == "CRITICAL":

        risk_color = (
            0,
            0,
            255
        )

    elif highest_status == "HIGH":

        risk_color = (
            0,
            100,
            255
        )

    elif highest_status == "MEDIUM":

        risk_color = (
            0,
            255,
            255
        )

    else:

        risk_color = (
            0,
            255,
            0
        )


    # ========================================================
    # HEADER
    # ========================================================

    cv2.putText(
        frame,
        "AI HELMET - EXTERNAL CAMERA",
        (30, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.75,
        (255, 255, 255),
        2
    )


    # ========================================================
    # DETECTION STATUS
    # ========================================================

    cv2.putText(
        frame,
        f"OBJECT: {danger_object}",
        (30, 75),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (255, 255, 255),
        2
    )


    # ========================================================
    # APPROACH STATUS
    # ========================================================

    if approaching_object != "NONE":

        approach_text = (
            f"APPROACH: {approaching_object}"
        )

        approach_color = (
            0,
            0,
            255
        )

    else:

        approach_text = (
            "APPROACH: NONE"
        )

        approach_color = (
            0,
            255,
            0
        )


    cv2.putText(
        frame,
        approach_text,
        (30, 110),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        approach_color,
        2
    )


    # ========================================================
    # RISK
    # ========================================================

    cv2.putText(
        frame,
        f"RISK SCORE: {highest_risk}/100",
        (30, 150),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        risk_color,
        3
    )


    cv2.putText(
        frame,
        f"STATUS: {highest_status}",
        (30, 190),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.9,
        risk_color,
        3
    )


    # ========================================================
    # CRASH-PREDICTION MODEL DISPLAY
    # ========================================================

    if crash_probability is not None:

        crash_alert = crash_probability >= CRASH_ALERT_THRESHOLD

        crash_color = (0, 0, 255) if crash_alert else (255, 255, 255)

        cv2.putText(
            frame,
            f"CRASH MODEL: {crash_probability * 100:.0f}%",
            (30, 275),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            crash_color,
            3
        )

    else:

        crash_alert = False


    # ========================================================
    # WARNING
    # ========================================================

    if crash_alert:

        cv2.putText(
            frame,
            "!!! ACCIDENT PREDICTED !!!",
            (30, 235),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            (0, 0, 255),
            3
        )

    elif highest_status == "CRITICAL":

        cv2.putText(
            frame,
            "!!! COLLISION RISK !!!",
            (30, 235),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            (0, 0, 255),
            3
        )

    elif highest_status == "HIGH":

        cv2.putText(
            frame,
            "!!! VEHICLE APPROACHING !!!",
            (30, 235),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 100, 255),
            3
        )


    # ========================================================
    # AUDIO WARNING
    # ========================================================

    current_time = time.time()

    if crash_alert:

        if current_time - last_crash_alert_time >= CRASH_ALERT_INTERVAL:

            # Distinct, higher-pitched pattern so it's not confused
            # with the rule-based "vehicle approaching" beep below.
            winsound.Beep(1800, 300)
            winsound.Beep(1800, 300)

            last_crash_alert_time = current_time

            log_event(
                0.0,
                "CRASH_MODEL_ALERT",
                "CRITICAL",
                f"Trained model predicted an imminent crash "
                f"({crash_probability * 100:.0f}% probability)."
            )


    if highest_status in (
        "HIGH",
        "CRITICAL"
    ):

        if (
            current_time -
            last_warning_time
            >= WARNING_INTERVAL
        ):

            if highest_status == "CRITICAL":

                winsound.Beep(
                    1500,
                    700
                )

            else:

                winsound.Beep(
                    1000,
                    400
                )


            last_warning_time = current_time


    # ========================================================
    # LOG WARNING
    # ========================================================

    if highest_status in (
        "HIGH",
        "CRITICAL"
    ):

        if (
            current_time -
            last_logged_time
            >= LOG_INTERVAL
        ):

            log_event(
                0.0,
                "ROAD_WARNING",
                highest_status,
                (
                    f"{danger_object} "
                    f"approaching; "
                    f"risk score "
                    f"{highest_risk}/100"
                )
            )


            last_logged_time = current_time


    # ========================================================
    # FOOTER
    # ========================================================

    cv2.putText(
        frame,
        "Press Q to exit",
        (
            30,
            height - 25
        ),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (255, 255, 255),
        2
    )


    # ========================================================
    # SHOW
    # ========================================================

    cv2.imshow(
        "AI Helmet - Road Safety",
        frame
    )


    # ========================================================
    # EXIT
    # ========================================================

    key = cv2.waitKey(1) & 0xFF


    if key == ord("q"):

        break


# ============================================================
# CLEANUP
# ============================================================

camera.release()

cv2.destroyAllWindows()


print()
print("==========================================")
print("Road monitoring stopped.")
print("Road warnings were saved to ride_events.csv.")
print("==========================================")