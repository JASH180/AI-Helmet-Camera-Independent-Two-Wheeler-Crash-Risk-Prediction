"""
build_labels_ccd.py

Builds dataset/labels_ccd.csv for feature_collector.py from the
Crash-1500 / Normal video dataset (the "New Volume/Crash-1500" and
"New Volume/Normal" folders you already downloaded).

IMPORTANT - LABELING ASSUMPTION:
This public dataset's videos are NOT shipped with a per-frame
"exact collision timestamp." What's known is: every Crash-1500 clip
ends in a collision, every Normal clip has no collision at all. To
turn that into the crash_timestamp_sec that feature_collector.py
needs, this script assumes the crash happens in the last
CRASH_OFFSET_FROM_END seconds of each Crash-1500 clip. That is the
standard assumption used for this exact dataset in accident-
anticipation research, and it's good enough for training - but if
you can find the original per-video annotation file for this
dataset (sometimes distributed as Crash-1500.txt / a "vidname,frame
of accident" file), point --annotation-file at it instead and this
script will use exact timestamps.

Expected folder layout (matches your screenshots):
    dataset/ccd_videos/Crash-1500/000425.mp4 ...
    dataset/ccd_videos/Normal/000063.mp4 ...

Usage:
    python src/build_labels_ccd.py
"""

import argparse
import csv
import os

import cv2


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

CCD_ROOT = os.path.join(PROJECT_ROOT, "dataset", "ccd_videos")
CRASH_SUBFOLDER = "Crash-1500"
NORMAL_SUBFOLDER = "Normal"

OUTPUT_FILE = os.path.join(PROJECT_ROOT, "dataset", "labels_ccd.csv")

# How many seconds before the end of a Crash-1500 clip the impact
# is assumed to occur.
CRASH_OFFSET_FROM_END = 1.0


def get_video_duration(path):
    capture = cv2.VideoCapture(path)

    if not capture.isOpened():
        return None

    fps = capture.get(cv2.CAP_PROP_FPS) or 30.0
    frame_count = capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0

    capture.release()

    if fps <= 0 or frame_count <= 0:
        return None

    return frame_count / fps


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--ccd-root", default=CCD_ROOT)
    parser.add_argument("--output", default=OUTPUT_FILE)
    parser.add_argument("--annotation-file", default=None,
                         help="Optional CSV with columns filename,crash_timestamp_sec "
                              "if you have exact ground-truth timestamps.")
    args = parser.parse_args()

    crash_folder = os.path.join(args.ccd_root, CRASH_SUBFOLDER)
    normal_folder = os.path.join(args.ccd_root, NORMAL_SUBFOLDER)

    if not os.path.isdir(crash_folder):
        print(f"ERROR: {crash_folder} not found.")
        return

    if not os.path.isdir(normal_folder):
        print(f"ERROR: {normal_folder} not found.")
        return

    exact_timestamps = {}

    if args.annotation_file and os.path.exists(args.annotation_file):
        with open(args.annotation_file, newline="", encoding="utf-8") as file:
            for row in csv.DictReader(file):
                exact_timestamps[row["filename"]] = float(row["crash_timestamp_sec"])

    rows = []

    crash_files = sorted(os.listdir(crash_folder))
    print(f"Found {len(crash_files)} files in {CRASH_SUBFOLDER}")

    for filename in crash_files:
        if not filename.lower().endswith((".mp4", ".avi", ".mov")):
            continue

        relative_path = f"{CRASH_SUBFOLDER}/{filename}"

        if filename in exact_timestamps:
            crash_time = exact_timestamps[filename]
        else:
            duration = get_video_duration(os.path.join(crash_folder, filename))
            if duration is None:
                print(f"  Could not read duration for {filename}, skipping.")
                continue
            crash_time = max(duration - CRASH_OFFSET_FROM_END, 0.1)

        rows.append({"filename": relative_path, "crash_timestamp_sec": round(crash_time, 2)})

    normal_files = sorted(os.listdir(normal_folder))
    print(f"Found {len(normal_files)} files in {NORMAL_SUBFOLDER}")

    for filename in normal_files:
        if not filename.lower().endswith((".mp4", ".avi", ".mov")):
            continue

        relative_path = f"{NORMAL_SUBFOLDER}/{filename}"
        rows.append({"filename": relative_path, "crash_timestamp_sec": ""})

    os.makedirs(os.path.dirname(args.output), exist_ok=True)

    with open(args.output, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["filename", "crash_timestamp_sec"])
        writer.writeheader()
        writer.writerows(rows)

    print()
    print(f"Wrote {len(rows)} labeled rows to {args.output}")
    print(f"  Crash-1500 (positive): {len(crash_files)}")
    print(f"  Normal (negative): {len(normal_files)}")


if __name__ == "__main__":
    main()
