import os
import csv
import argparse

import cv2
from ultralytics import YOLO

from crash_features import extract_frame_features, summarize_window as _summarize_window


# ============================================================
# PROJECT PATHS
# This file lives in src/, same as road_risk.py, internal.py,
# etc. - so PROJECT_ROOT is one directory up, matching the
# pattern used everywhere else in the codebase.
# ============================================================

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)


# ============================================================
# CONFIG - matches your actual dataset/ layout:
#   dataset/raw_videos      <- untouched footage goes here
#   dataset/trimmed_videos  <- optional, clipped-down clips
#   dataset/frames          <- unused by this script
#   dataset/labels.csv      <- you create this (see below)
# ============================================================

# Folder containing your video clips.
VIDEOS_FOLDER = os.path.join(PROJECT_ROOT, "dataset", "raw_videos")

# CSV with columns: filename, crash_timestamp_sec
# crash_timestamp_sec is blank/empty for clips with no crash.
LABELS_FILE = os.path.join(PROJECT_ROOT, "dataset", "labels.csv")

# Output: one row per 1-second window, ready for XGBoost.
OUTPUT_FILE = os.path.join(PROJECT_ROOT, "dataset", "training_data.csv")

# yolo11n.pt sits at the project root, alongside main.py -
# same place internal.py looks for face_landmarker.task.
YOLO_MODEL = os.path.join(PROJECT_ROOT, "yolo11n.pt")

# How many seconds before impact count as "pre-crash" (label=1).
# Frames earlier than this are label=0 (normal riding).
PRE_CRASH_WINDOW_SECONDS = 3.0

# Frames at/after the crash timestamp itself are dropped rather
# than labeled - the impact frame and afterwards aren't a
# "predict ahead of time" signal, they're the crash itself.
POST_CRASH_DROP_SECONDS = 1.0

# Aggregate raw per-frame numbers into windows this long. This
# matters a lot: a single frame is noisy, but "the last second
# of riding" is a much more stable, learnable signal.
WINDOW_SECONDS = 1.0


# ============================================================
# LOAD LABELS
# ============================================================

def load_labels(labels_path):

    labels = {}

    with open(labels_path, "r", encoding="utf-8") as file:

        reader = csv.DictReader(file)

        for row in reader:

            filename = row["filename"].strip()

            raw_timestamp = row.get("crash_timestamp_sec", "").strip()

            crash_timestamp = (
                float(raw_timestamp) if raw_timestamp else None
            )

            labels[filename] = crash_timestamp

    return labels


# ============================================================
# PER-FRAME FEATURE EXTRACTION
# Imported from crash_features.py so training and the live
# external_camera.py always compute numbers the exact same way.
# ============================================================

# ============================================================
# LABEL A FRAME
# ============================================================

def label_for_time(current_time, crash_timestamp):

    if crash_timestamp is None:
        return 0

    # Drop the impact moment itself and just after - not a
    # useful "predict ahead" training signal either way.
    if crash_timestamp <= current_time <= crash_timestamp + POST_CRASH_DROP_SECONDS:
        return None

    if current_time > crash_timestamp + POST_CRASH_DROP_SECONDS:
        return None

    if crash_timestamp - PRE_CRASH_WINDOW_SECONDS <= current_time < crash_timestamp:
        return 1

    return 0


# ============================================================
# PROCESS ONE VIDEO -> WINDOWED FEATURE ROWS
# ============================================================

def process_video(model, video_path, crash_timestamp, video_id):

    capture = cv2.VideoCapture(video_path)

    if not capture.isOpened():
        print(f"  Could not open {video_path}, skipping.")
        return []

    fps = capture.get(cv2.CAP_PROP_FPS) or 30.0

    previous_sizes = {}

    window_rows = []
    window_frames = []
    window_start_time = 0.0

    frame_index = 0

    while True:

        ret, frame = capture.read()

        if not ret:
            break

        current_time = frame_index / fps

        features = extract_frame_features(model, frame, previous_sizes)

        label = label_for_time(current_time, crash_timestamp)

        window_frames.append((features, label))

        if current_time - window_start_time >= WINDOW_SECONDS:

            row = summarize_window(
                window_frames, video_id, window_start_time
            )

            if row is not None:
                window_rows.append(row)

            window_frames = []
            window_start_time = current_time

        frame_index += 1

    capture.release()

    return window_rows


# ============================================================
# SUMMARIZE ONE WINDOW OF FRAMES INTO ONE TRAINING ROW
# ============================================================

def summarize_window(window_frames, video_id, window_start_time):

    if not window_frames:
        return None

    features_only = [f for f, _ in window_frames]

    labels = [label for _, label in window_frames if label is not None]

    # If every frame in this window was dropped (e.g. it's the
    # impact moment itself), skip the window entirely.
    if not labels:
        return None

    # A window is "pre-crash" if any frame in it was flagged so.
    window_label = 1 if any(label == 1 for label in labels) else 0

    feature_row = _summarize_window(features_only)

    if feature_row is None:
        return None

    row = {
        "video_id": video_id,
        "window_start_sec": round(window_start_time, 2),
    }
    row.update(feature_row)
    row["label"] = window_label

    return row


# ============================================================
# MAIN
# ============================================================

def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("--videos", default=VIDEOS_FOLDER)
    parser.add_argument("--labels", default=LABELS_FILE)
    parser.add_argument("--output", default=OUTPUT_FILE)
    parser.add_argument("--limit", type=int, default=None,
                         help="Only process the first N labeled clips (for a quick test run).")

    args = parser.parse_args()

    if not os.path.exists(YOLO_MODEL):
        print(f"ERROR: YOLO model not found at {YOLO_MODEL}")
        return

    if not os.path.exists(args.labels):
        print(f"ERROR: labels file not found at {args.labels}")
        print("Create dataset/labels.csv with columns: filename,crash_timestamp_sec")
        return

    if not os.path.isdir(args.videos):
        print(f"ERROR: videos folder not found at {args.videos}")
        return

    print("Loading YOLO model...")
    model = YOLO(YOLO_MODEL)

    print(f"Loading labels from {args.labels}...")
    labels = load_labels(args.labels)

    filenames = list(labels.keys())

    if args.limit:
        filenames = filenames[:args.limit]

    print(f"Processing {len(filenames)} labeled clips...")

    all_rows = []

    for index, filename in enumerate(filenames):

        video_path = os.path.join(args.videos, filename)

        if not os.path.exists(video_path):
            print(f"  [{index+1}/{len(filenames)}] Missing file: {filename}")
            continue

        crash_timestamp = labels[filename]

        print(
            f"  [{index+1}/{len(filenames)}] {filename} "
            f"(crash at {crash_timestamp}s)" if crash_timestamp is not None
            else f"  [{index+1}/{len(filenames)}] {filename} (no crash)"
        )

        rows = process_video(model, video_path, crash_timestamp, video_id=filename)

        all_rows.extend(rows)

    if not all_rows:
        print("No rows produced - check your paths and labels file.")
        return

    fieldnames = list(all_rows[0].keys())

    os.makedirs(os.path.dirname(args.output), exist_ok=True)

    with open(args.output, "w", newline="", encoding="utf-8") as file:

        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_rows)

    positive = sum(row["label"] for row in all_rows)

    print()
    print("==========================================")
    print(f"Wrote {len(all_rows)} training rows to {args.output}")
    print(f"Positive (pre-crash) rows: {positive}")
    print(f"Negative (normal) rows: {len(all_rows) - positive}")
    print("==========================================")


if __name__ == "__main__":
    main()
