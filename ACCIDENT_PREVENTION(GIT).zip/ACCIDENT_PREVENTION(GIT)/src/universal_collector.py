"""
universal_collector.py

One pass over each video -> one row per 1-second window holding BOTH the old
14 features and the new view-independent u_ features, plus label, source,
viewpoint and crash_time_sec (needed for the warning-lead-time metric).

Run once per footage type (same labels files you already have):

  python src/universal_collector.py --videos dataset/raw_videos_ccd     --labels dataset/labels_ccd.csv     --output dataset/training_universal_ccd.csv     --source-name ccd     --viewpoint other_vehicle_dashcam
  python src/universal_collector.py --videos dataset/raw_videos_kaggle  --labels dataset/labels_kaggle.csv  --output dataset/training_universal_kaggle.csv  --source-name kaggle  --viewpoint other_vehicle_dashcam
  python src/universal_collector.py --videos dataset/raw_videos_cyclist --labels dataset/labels_cyclist.csv --output dataset/training_universal_cyclist.csv --source-name cyclist --viewpoint cyclist_pov
  python src/universal_collector.py --videos dataset/raw_videos_gopro   --labels dataset/labels_gopro.csv   --output dataset/training_universal_gopro.csv   --source-name gopro   --viewpoint biker_gopro

labels_gopro.csv: filename,crash_timestamp_sec   (blank = no crash / normal ride)
Use --target-fps 15 to speed things up (the features do not depend on fps).
"""
import os
import sys
import argparse

import cv2
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from feature_collector import load_labels, label_for_time
from universal_features import FrameAnalyzer, WindowAggregator

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
YOLO_MODEL = os.path.join(PROJECT_ROOT, "yolo11n.pt")


def process_video(analyzer, video_path, crash_time, video_id, source, viewpoint, target_fps=None):
    capture = cv2.VideoCapture(video_path)
    if not capture.isOpened():
        print(f"  Could not open {video_path}")
        return []

    fps = capture.get(cv2.CAP_PROP_FPS) or 30.0
    step = max(int(round(fps / target_fps)), 1) if target_fps and fps > target_fps else 1

    analyzer.reset()
    aggregator = WindowAggregator()
    rows, index = [], 0

    while True:
        ok, frame = capture.read()
        if not ok:
            break
        if index % step == 0:
            t = index / fps
            record = analyzer.analyze(frame, t)
            record["label"] = label_for_time(t, crash_time)
            closed = aggregator.add(record)
            if closed:
                start, legacy, universal, frames = closed
                labels = [r["label"] for r in frames if r["label"] is not None]
                if labels and legacy is not None:
                    row = {"video_id": video_id, "window_start_sec": round(start, 2),
                           "source": source, "viewpoint": viewpoint,
                           "crash_time_sec": crash_time if crash_time is not None else ""}
                    row.update(legacy)
                    row.update(universal)
                    row["label"] = 1 if any(l == 1 for l in labels) else 0
                    rows.append(row)
        index += 1

    capture.release()
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--videos", required=True)
    parser.add_argument("--labels", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--source-name", required=True)
    parser.add_argument("--viewpoint", default=None)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--target-fps", type=float, default=None)
    args = parser.parse_args()

    from ultralytics import YOLO
    model = YOLO(YOLO_MODEL)
    analyzer = FrameAnalyzer(yolo_model=model)

    labels = load_labels(args.labels)
    names = list(labels)[: args.limit] if args.limit else list(labels)
    print(f"{len(names)} labelled clips ({args.source_name})")

    out = []
    for i, name in enumerate(names, 1):
        path = os.path.join(args.videos, name)
        if not os.path.exists(path):
            print(f"  [{i}/{len(names)}] missing {name}")
            continue
        rows = process_video(analyzer, path, labels[name], name, args.source_name,
                             args.viewpoint or args.source_name, args.target_fps)
        out += rows
        print(f"  [{i}/{len(names)}] {name}: {len(rows)} windows")
        if i % 25 == 0 and out:
            pd.DataFrame(out).to_csv(args.output, index=False)   # checkpoint

    pd.DataFrame(out).to_csv(args.output, index=False)
    print(f"Saved {len(out)} windows -> {args.output}")


if __name__ == "__main__":
    main()
