"""
extract_features.py

Walks your labeled image dataset and turns each face image into one row
of numeric features (EAR, MAR, head pose) that XGBoost can train on.

EXPECTED FOLDER LAYOUT (edit DATASET_ROOT below if yours differs):

    dataset/
        drowsy/
            img001.jpg
            img002.jpg
            ...
        alert/
            img001.jpg
            img002.jpg
            ...

Each image should contain one visible face. Images where no face is
detected are skipped (and counted) rather than silently guessed at.

OUTPUT:
    dataset/training_data.csv
    Columns: ear_left, ear_right, ear_avg, mar, yaw, pitch, label, filename

    label = 1  -> drowsy
    label = 0  -> alert

Run:
    python extract_features.py
"""

import os
import csv

import cv2
import numpy as np
import mediapipe as mp

from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ============================================================
# CONFIG - edit these paths for your machine
# ============================================================

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))

DATASET_ROOT = os.path.join(PROJECT_ROOT, "dataset")

DROWSY_FOLDER = os.path.join(DATASET_ROOT, "drowsy")
ALERT_FOLDER = os.path.join(DATASET_ROOT, "alert")

MODEL_PATH = os.path.join(PROJECT_ROOT, "models", "face_landmarker.task")

OUTPUT_FILE = os.path.join(DATASET_ROOT, "training_data.csv")

VALID_EXTENSIONS = (".jpg", ".jpeg", ".png", ".bmp")


# ============================================================
# LANDMARK INDEXES (MediaPipe Face Mesh, 478-point model)
# ============================================================

LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]

# Mouth points for MAR (yawn detection):
# outer corners + top/bottom lip midpoints
MOUTH = [61, 291, 13, 14]

NOSE_TIP = 1
CHIN = 152
LEFT_EYE_OUTER = 33
RIGHT_EYE_OUTER = 263
LEFT_MOUTH_CORNER = 61
RIGHT_MOUTH_CORNER = 291

MODEL_POINTS = np.array(
    [
        (0.0, 0.0, 0.0),
        (0.0, -63.6, -12.5),
        (-43.3, 32.7, -26.0),
        (43.3, 32.7, -26.0),
        (-28.9, -28.9, -24.1),
        (28.9, -28.9, -24.1),
    ],
    dtype=np.float64,
)


# ============================================================
# GEOMETRY HELPERS
# ============================================================

def distance(point1, point2):
    return np.linalg.norm(np.array(point1) - np.array(point2))


def get_point(landmarks, index, width, height):
    landmark = landmarks[index]
    return (landmark.x * width, landmark.y * height)


def get_points(landmarks, indexes, width, height):
    return [get_point(landmarks, i, width, height) for i in indexes]


def calculate_ear(eye_points):
    vertical_1 = distance(eye_points[1], eye_points[5])
    vertical_2 = distance(eye_points[2], eye_points[4])
    horizontal = distance(eye_points[0], eye_points[3])

    if horizontal == 0:
        return 0.0

    return (vertical_1 + vertical_2) / (2.0 * horizontal)


def calculate_mar(mouth_points):
    # mouth_points = [left_corner, right_corner, top_lip, bottom_lip]
    horizontal = distance(mouth_points[0], mouth_points[1])
    vertical = distance(mouth_points[2], mouth_points[3])

    if horizontal == 0:
        return 0.0

    return vertical / horizontal


def calculate_head_pose(landmarks, width, height):
    try:
        image_points = np.array(
            [
                get_point(landmarks, NOSE_TIP, width, height),
                get_point(landmarks, CHIN, width, height),
                get_point(landmarks, LEFT_EYE_OUTER, width, height),
                get_point(landmarks, RIGHT_EYE_OUTER, width, height),
                get_point(landmarks, LEFT_MOUTH_CORNER, width, height),
                get_point(landmarks, RIGHT_MOUTH_CORNER, width, height),
            ],
            dtype=np.float64,
        )

        focal_length = width
        camera_center = (width / 2, height / 2)

        camera_matrix = np.array(
            [
                [focal_length, 0, camera_center[0]],
                [0, focal_length, camera_center[1]],
                [0, 0, 1],
            ],
            dtype=np.float64,
        )

        distortion_coefficients = np.zeros((4, 1))

        success, rotation_vector, _ = cv2.solvePnP(
            MODEL_POINTS,
            image_points,
            camera_matrix,
            distortion_coefficients,
            flags=cv2.SOLVEPNP_ITERATIVE,
        )

        if not success:
            return None, None

        rotation_matrix, _ = cv2.Rodrigues(rotation_vector)
        angles = cv2.RQDecomp3x3(rotation_matrix)[0]

        pitch = angles[0]
        yaw = angles[1]

        return yaw, pitch

    except Exception:
        return None, None


# ============================================================
# ONE-IMAGE FEATURE EXTRACTION
# ============================================================

def extract_features_from_image(landmarker, image_path):
    """
    Returns a dict of features, or None if no face was detected.
    Uses IMAGE running mode (single still image, no timestamp needed).
    """

    frame = cv2.imread(image_path)

    if frame is None:
        return None

    height, width, _ = frame.shape

    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)

    result = landmarker.detect(mp_image)

    if not result.face_landmarks:
        return None

    landmarks = result.face_landmarks[0]

    left_eye = get_points(landmarks, LEFT_EYE, width, height)
    right_eye = get_points(landmarks, RIGHT_EYE, width, height)
    mouth = get_points(landmarks, MOUTH, width, height)

    left_ear = calculate_ear(left_eye)
    right_ear = calculate_ear(right_eye)
    ear_avg = (left_ear + right_ear) / 2.0

    mar = calculate_mar(mouth)

    yaw, pitch = calculate_head_pose(landmarks, width, height)

    return {
        "ear_left": round(left_ear, 4),
        "ear_right": round(right_ear, 4),
        "ear_avg": round(ear_avg, 4),
        "mar": round(mar, 4),
        "yaw": round(yaw, 2) if yaw is not None else 0.0,
        "pitch": round(pitch, 2) if pitch is not None else 0.0,
    }


# ============================================================
# FOLDER PROCESSING
# ============================================================

def list_images(folder):
    if not os.path.isdir(folder):
        return []

    return sorted(
        os.path.join(folder, name)
        for name in os.listdir(folder)
        if name.lower().endswith(VALID_EXTENSIONS)
    )


def process_folder(landmarker, folder, label, rows):
    image_paths = list_images(folder)

    print(f"Found {len(image_paths)} images in {folder}")

    skipped = 0

    for index, image_path in enumerate(image_paths):

        features = extract_features_from_image(landmarker, image_path)

        if features is None:
            skipped += 1
            continue

        features["label"] = label
        features["filename"] = os.path.basename(image_path)

        rows.append(features)

        if (index + 1) % 100 == 0:
            print(f"  processed {index + 1}/{len(image_paths)}")

    print(f"  done. skipped (no face detected): {skipped}")


# ============================================================
# MAIN
# ============================================================

def main():

    if not os.path.exists(MODEL_PATH):
        print(f"ERROR: face_landmarker.task not found at {MODEL_PATH}")
        print(
            "Download it from: "
            "https://storage.googleapis.com/mediapipe-models/face_landmarker/"
            "face_landmarker/float16/latest/face_landmarker.task"
        )
        return

    if not os.path.isdir(DROWSY_FOLDER) or not os.path.isdir(ALERT_FOLDER):
        print("ERROR: expected these folders to exist:")
        print(f"  {DROWSY_FOLDER}")
        print(f"  {ALERT_FOLDER}")
        print("Edit DATASET_ROOT / DROWSY_FOLDER / ALERT_FOLDER in this script"
              " if your folders are named or located differently.")
        return

    base_options = python.BaseOptions(model_asset_path=MODEL_PATH)

    options = vision.FaceLandmarkerOptions(
        base_options=base_options,
        running_mode=vision.RunningMode.IMAGE,
        num_faces=1,
        min_face_detection_confidence=0.5,
        min_face_presence_confidence=0.5,
        output_face_blendshapes=False,
        output_facial_transformation_matrixes=False,
    )

    landmarker = vision.FaceLandmarker.create_from_options(options)

    rows = []

    print()
    print("==========================================")
    print("Extracting features from DROWSY images...")
    print("==========================================")
    process_folder(landmarker, DROWSY_FOLDER, label=1, rows=rows)

    print()
    print("==========================================")
    print("Extracting features from ALERT images...")
    print("==========================================")
    process_folder(landmarker, ALERT_FOLDER, label=0, rows=rows)

    landmarker.close()

    if not rows:
        print()
        print("No rows produced - check that your images contain visible "
              "faces and that folder paths are correct.")
        return

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

    fieldnames = [
        "filename", "ear_left", "ear_right", "ear_avg",
        "mar", "yaw", "pitch", "label"
    ]

    with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    positive = sum(row["label"] for row in rows)

    print()
    print("==========================================")
    print(f"Wrote {len(rows)} rows to {OUTPUT_FILE}")
    print(f"Drowsy rows : {positive}")
    print(f"Alert rows  : {len(rows) - positive}")
    print("==========================================")


if __name__ == "__main__":
    main()
