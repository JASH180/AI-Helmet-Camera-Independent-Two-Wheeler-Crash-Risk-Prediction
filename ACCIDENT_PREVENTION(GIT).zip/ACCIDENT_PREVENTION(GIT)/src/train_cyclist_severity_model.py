"""
train_cyclist_severity_model.py

Trains the CYCLIST-SPECIFIC severity model - this is different from
train_crash_model.py (which detects "is a crash about to happen"
from live camera footage). This one answers a different question:
"given the circumstances of a cyclist accident, how severe was/would
it be?" - trained on dataset.csv, the annotated cyclist-accident
dataset behind clips_output.

DATA NOTE: dataset.csv has 3,002 rows, but only the 1,000 rows whose
"File Name" starts with "u" (Id 1-1000) carry real accident labels
(Object Involved, Fault, Severity Score, etc.) - the other 2,002
"s"-prefixed rows (Id 1001+, the ones already in your clips_output
folder) are unlabeled filler/background clips with no severity
information. So this model trains on the CSV directly and does not
need any video files at all - it's ready to train right now.

If you later download the "u"-prefixed clips too (via extract_clips.py
on the original dataset.csv), those videos would let you build a
frame-based version of this model - not required for this to work.

Predicts: Severity Score, 0 (no injury) to 4 (most severe), as a
multi-class classification from the circumstances of the accident
(what was involved, directions, fault, right of way, age group,
rider experience, vulnerability score).

Run:
    python src/train_cyclist_severity_model.py
"""

import os
import json

import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report, accuracy_score

import xgboost as xgb


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

DATA_FILE = os.path.join(PROJECT_ROOT, "dataset", "dataset.csv")

MODEL_FILE = os.path.join(PROJECT_ROOT, "models", "cyclist_severity_model.joblib")
META_FILE = os.path.join(PROJECT_ROOT, "models", "cyclist_severity_features.json")

CATEGORICAL_FEATURES = [
    "Object Involved",
    "Cyclist Direction",
    "Object Involved in Accident Direction",
    "Camera Position",
    "Fault",
    "Right of Way",
]

NUMERIC_FEATURES = [
    "Age",
    "Competitive Biking?",
    "Vulnerability Score",
]

ALL_FEATURES = CATEGORICAL_FEATURES + NUMERIC_FEATURES

TARGET = "Severity Score"

RANDOM_STATE = 42
TEST_SIZE = 0.2


def load_data():
    data = pd.read_csv(DATA_FILE)

    # Only the "u"-prefixed rows carry real accident labels - the
    # "s"-prefixed rows are "N.A." across every accident-detail
    # column and would just be noise/leakage-free-but-useless rows.
    data = data[data["Ego Accident"] != "N.A."].copy()

    data = data[data[TARGET] != "N.A."].copy()
    data[TARGET] = data[TARGET].astype(int)

    for column in CATEGORICAL_FEATURES:
        data[column] = data[column].astype(str)

    return data


def build_pipeline():
    categorical_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="constant", fill_value="Unknown")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    numeric_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="median")),
    ])

    preprocessor = ColumnTransformer(transformers=[
        ("cat", categorical_transformer, CATEGORICAL_FEATURES),
        ("num", numeric_transformer, NUMERIC_FEATURES),
    ])

    model = xgb.XGBClassifier(
        n_estimators=300,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        eval_metric="mlogloss",
        random_state=RANDOM_STATE,
    )

    return Pipeline(steps=[("preprocess", preprocessor), ("model", model)])


def main():
    print("Loading data...")
    data = load_data()
    print(f"Loaded {len(data)} labeled cyclist-accident rows.")
    print(data[TARGET].value_counts().sort_index())

    X = data[ALL_FEATURES]
    y = data[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y,
    )

    pipeline = build_pipeline()

    print("Training...")
    pipeline.fit(X_train, y_train)

    predictions = pipeline.predict(X_test)

    print()
    print("==========================================")
    print("CLASSIFICATION REPORT (Severity Score 0-4)")
    print("==========================================")
    print(classification_report(y_test, predictions))

    accuracy = accuracy_score(y_test, predictions)
    print(f"Accuracy: {accuracy:.3f}")

    os.makedirs(os.path.dirname(MODEL_FILE), exist_ok=True)
    joblib.dump(pipeline, MODEL_FILE)

    metadata = {
        "categorical_features": CATEGORICAL_FEATURES,
        "numeric_features": NUMERIC_FEATURES,
        "target": "Severity Score (0=none .. 4=most severe)",
        "accuracy": round(float(accuracy), 4),
        "n_train_rows": int(len(X_train)),
        "n_test_rows": int(len(X_test)),
    }
    with open(META_FILE, "w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)

    print()
    print(f"Model saved to {MODEL_FILE}")
    print(f"Metadata saved to {META_FILE}")


if __name__ == "__main__":
    main()
