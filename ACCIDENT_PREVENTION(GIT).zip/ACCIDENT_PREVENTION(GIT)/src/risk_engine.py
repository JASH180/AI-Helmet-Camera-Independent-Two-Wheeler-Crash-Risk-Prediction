class RiskEngine:

    def __init__(self):
        self.distraction_score = 0
        self.drowsiness_score = 0
        self.road_score = 0

    def set_distraction(self, level):
        self.distraction_score = level

    def set_drowsiness(self, level):
        self.drowsiness_score = level

    def set_road_risk(self, level):
        self.road_score = level

    def calculate_risk(self):

        # Weighted risk score
        risk = (
            self.distraction_score * 0.30
            + self.drowsiness_score * 0.30
            + self.road_score * 0.40
        )

        return round(risk, 2)

    def get_status(self):

        risk = self.calculate_risk()

        if risk < 30:
            return "SAFE"

        elif risk < 60:
            return "CAUTION"

        elif risk < 80:
            return "HIGH RISK"

        else:
            return "CRITICAL"


if __name__ == "__main__":

    engine = RiskEngine()

    engine.set_distraction(70)
    engine.set_drowsiness(20)
    engine.set_road_risk(80)

    print()
    print("================================")
    print("       RISK ENGINE TEST")
    print("================================")

    print(
        f"Risk Score : {engine.calculate_risk()}"
    )

    print(
        f"Status     : {engine.get_status()}"
    )

    print("================================")