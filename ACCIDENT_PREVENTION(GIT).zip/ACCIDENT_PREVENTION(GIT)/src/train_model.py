"""
train_model.py  (drowsiness version)

Loads dataset/training_data.csv (produced by extract_features.py) and
trains an XGBoost classifier to distinguish DROWSY vs ALERT faces from
EAR / MAR / head-pose features.

Run:
    python train_model.py
"""

import os

import pandas as pd
import xgboost as xgb

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
)


# ============================================================
# CONFIG
# ============================================================

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))

DATA_FILE = os.path.join(PROJECT_ROOT, "dataset", "training_data.csv")

MODEL_OUTPUT = os.path.join(PROJECT_ROOT, "models", "drowsiness_model.json")

TEST_SIZE = 0.2
RANDOM_STATE = 42

FEATURE_COLUMNS = [
    "ear_left",
    "ear_right",
    "ear_avg",
    "mar",
    "yaw",
    "pitch",
]

LABEL_COLUMN = "label"


# ============================================================
# LOAD DATA
# ============================================================

def load_data():

    if not os.path.exists(DATA_FILE):
        raise FileNotFoundError(
            f"{DATA_FILE} not found - run extract_features.py first."
        )

    data = pd.read_csv(DATA_FILE)

    missing = [col for col in FEATURE_COLUMNS if col not in data.columns]

    if missing:
        raise ValueError(f"Missing expected columns: {missing}")

    return data


# ============================================================
# TRAIN
# ============================================================

def train_model(X_train, y_train):

    positive = (y_train == 1).sum()
    negative = (y_train == 0).sum()

    # Balance classes if drowsy/alert counts differ a lot.
    scale_pos_weight = negative / positive if positive > 0 else 1.0

    print(f"Train rows: {len(X_train)} "
          f"(drowsy: {positive}, alert: {negative})")
    print(f"scale_pos_weight: {scale_pos_weight:.2f}")

    model = xgb.XGBClassifier(
        n_estimators=300,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos_weight,
        eval_metric="logloss",
        random_state=RANDOM_STATE,
    )

    model.fit(X_train, y_train)

    return model


# ============================================================
# EVALUATE
# ============================================================

def evaluate_model(model, X_test, y_test):

    predictions = model.predict(X_test)
    probabilities = model.predict_proba(X_test)[:, 1]

    print()
    print("==========================================")
    print("CLASSIFICATION REPORT")
    print("==========================================")
    print(classification_report(
        y_test, predictions, target_names=["ALERT", "DROWSY"]
    ))

    print("CONFUSION MATRIX")
    print("(rows = actual, columns = predicted)")
    print("         ALERT  DROWSY")

    matrix = confusion_matrix(y_test, predictions)

    for label, row in zip(["ALERT ", "DROWSY"], matrix):
        print(f"{label}  {row}")

    if len(set(y_test)) > 1:
        auc = roc_auc_score(y_test, probabilities)
        print()
        print(f"ROC AUC: {auc:.3f}")

    print()
    print("FEATURE IMPORTANCE")
    print("==========================================")

    importances = sorted(
        zip(FEATURE_COLUMNS, model.feature_importances_),
        key=lambda item: item[1],
        reverse=True,
    )

    for name, importance in importances:
        print(f"  {name:<12} {importance:.3f}")


# ============================================================
# MAIN
# ============================================================

def main():

    data = load_data()

    print(f"Loaded {len(data)} rows total.")

    X = data[FEATURE_COLUMNS]
    y = data[LABEL_COLUMN]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    model = train_model(X_train, y_train)

    evaluate_model(model, X_test, y_test)

    os.makedirs(os.path.dirname(MODEL_OUTPUT), exist_ok=True)

    model.save_model(MODEL_OUTPUT)

    print()
    print(f"Model saved to {MODEL_OUTPUT}")


if __name__ == "__main__":
    main()
