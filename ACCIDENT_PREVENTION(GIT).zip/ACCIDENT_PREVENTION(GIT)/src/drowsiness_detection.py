"""
drowsiness_detection_ml.py

Same camera + MediaPipe pipeline as your original drowsiness_detection.py,
but the ALERT/DROWSY decision now comes from the trained XGBoost model
(models/drowsiness_model.json) instead of a fixed EAR_THRESHOLD.

Per frame:
  1. Extract EAR (both eyes), MAR, yaw, pitch - same features used
     during training (extract_features.py).
  2. Feed them to the XGBoost model -> probability of "drowsy".
  3. Smooth that probability over a short rolling window (single-frame
     model predictions are noisy) and require it to stay high for
     DROWSY_TIME seconds before raising a warning, exactly like your
     original EAR-based timer logic.

Run:
    python drowsiness_detection_ml.py
"""

import os
import time
from collections import deque

import cv2
import numpy as np
import mediapipe as mp
import xgboost as xgb

from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))

FACE_MODEL_PATH = os.path.join(PROJECT_ROOT, "models", "face_landmarker.task")

XGB_MODEL_PATH = os.path.join(PROJECT_ROOT, "models", "drowsiness_model.json")

FEATURE_COLUMNS = ["ear_left", "ear_right", "ear_avg", "mar", "yaw", "pitch"]


if not os.path.exists(FACE_MODEL_PATH):
    print("ERROR: face_landmarker.task not found.")
    print(f"Expected: {FACE_MODEL_PATH}")
    raise SystemExit

if not os.path.exists(XGB_MODEL_PATH):
    print("ERROR: drowsiness_model.json not found.")
    print(f"Expected: {XGB_MODEL_PATH}")
    print("Run extract_features.py then train_model.py first.")
    raise SystemExit


# ============================================================
# LOAD MODELS
# ============================================================

xgb_model = xgb.XGBClassifier()
xgb_model.load_model(XGB_MODEL_PATH)

base_options = python.BaseOptions(model_asset_path=FACE_MODEL_PATH)

options = vision.FaceLandmarkerOptions(
    base_options=base_options,
    running_mode=vision.RunningMode.VIDEO,
    num_faces=1,
    min_face_detection_confidence=0.5,
    min_face_presence_confidence=0.5,
    min_tracking_confidence=0.5,
    output_face_blendshapes=False,
    output_facial_transformation_matrixes=False,
)

landmarker = vision.FaceLandmarker.create_from_options(options)


# ============================================================
# CAMERA
# ============================================================

camera = cv2.VideoCapture(0)

if not camera.isOpened():
    print("ERROR: Camera could not be opened.")
    landmarker.close()
    raise SystemExit


# ============================================================
# LANDMARK INDEXES (must match extract_features.py exactly)
# ============================================================

LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]
MOUTH = [61, 291, 13, 14]

NOSE_TIP = 1
CHIN = 152
LEFT_EYE_OUTER = 33
RIGHT_EYE_OUTER = 263
LEFT_MOUTH_CORNER = 61
RIGHT_MOUTH_CORNER = 291

MODEL_POINTS = np.array(
    [
        (0.0, 0.0, 0.0),
        (0.0, -63.6, -12.5),
        (-43.3, 32.7, -26.0),
        (43.3, 32.7, -26.0),
        (-28.9, -28.9, -24.1),
        (28.9, -28.9, -24.1),
    ],
    dtype=np.float64,
)


# ============================================================
# SETTINGS
# ============================================================

# Probability threshold for calling a single frame "drowsy-looking".
DROWSY_PROB_THRESHOLD = 0.5

# Rolling window smoothing (frames), reduces per-frame jitter.
SMOOTHING_WINDOW = 5

# Must stay above threshold this long before raising DROWSY status.
DROWSY_TIME = 1.5


# ============================================================
# STATE
# ============================================================

prob_history = deque(maxlen=SMOOTHING_WINDOW)

drowsy_start = None
timestamp_ms = 0


# ============================================================
# HELPERS (identical math to extract_features.py, keep in sync)
# ============================================================

def distance(point1, point2):
    return np.linalg.norm(np.array(point1) - np.array(point2))


def get_point(landmarks, index, width, height):
    landmark = landmarks[index]
    return (landmark.x * width, landmark.y * height)


def get_points(landmarks, indexes, width, height):
    return [get_point(landmarks, i, width, height) for i in indexes]


def calculate_ear(eye_points):
    vertical_1 = distance(eye_points[1], eye_points[5])
    vertical_2 = distance(eye_points[2], eye_points[4])
    horizontal = distance(eye_points[0], eye_points[3])

    if horizontal == 0:
        return 0.0

    return (vertical_1 + vertical_2) / (2.0 * horizontal)


def calculate_mar(mouth_points):
    horizontal = distance(mouth_points[0], mouth_points[1])
    vertical = distance(mouth_points[2], mouth_points[3])

    if horizontal == 0:
        return 0.0

    return vertical / horizontal


def calculate_head_pose(landmarks, width, height):
    try:
        image_points = np.array(
            [
                get_point(landmarks, NOSE_TIP, width, height),
                get_point(landmarks, CHIN, width, height),
                get_point(landmarks, LEFT_EYE_OUTER, width, height),
                get_point(landmarks, RIGHT_EYE_OUTER, width, height),
                get_point(landmarks, LEFT_MOUTH_CORNER, width, height),
                get_point(landmarks, RIGHT_MOUTH_CORNER, width, height),
            ],
            dtype=np.float64,
        )

        focal_length = width
        camera_center = (width / 2, height / 2)

        camera_matrix = np.array(
            [
                [focal_length, 0, camera_center[0]],
                [0, focal_length, camera_center[1]],
                [0, 0, 1],
            ],
            dtype=np.float64,
        )

        distortion_coefficients = np.zeros((4, 1))

        success, rotation_vector, _ = cv2.solvePnP(
            MODEL_POINTS,
            image_points,
            camera_matrix,
            distortion_coefficients,
            flags=cv2.SOLVEPNP_ITERATIVE,
        )

        if not success:
            return None, None

        rotation_matrix, _ = cv2.Rodrigues(rotation_vector)
        angles = cv2.RQDecomp3x3(rotation_matrix)[0]

        return angles[1], angles[0]  # yaw, pitch

    except Exception:
        return None, None


# ============================================================
# MAIN LOOP
# ============================================================

print()
print("==========================================")
print("   DROWSINESS DETECTION (XGBoost model)")
print("==========================================")
print()
print("Camera starting... Press Q to quit.")
print()

try:

    while True:

        ret, frame = camera.read()

        if not ret:
            print("ERROR: Could not read camera.")
            break

        frame = cv2.flip(frame, 1)
        height, width, _ = frame.shape

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)

        result = landmarker.detect_for_video(mp_image, timestamp_ms)
        timestamp_ms += 33

        status = "NO FACE"
        status_color = (0, 0, 255)
        drowsy_prob = 0.0

        if result.face_landmarks:

            landmarks = result.face_landmarks[0]

            left_eye = get_points(landmarks, LEFT_EYE, width, height)
            right_eye = get_points(landmarks, RIGHT_EYE, width, height)
            mouth = get_points(landmarks, MOUTH, width, height)

            left_ear = calculate_ear(left_eye)
            right_ear = calculate_ear(right_eye)
            ear_avg = (left_ear + right_ear) / 2.0
            mar = calculate_mar(mouth)

            yaw, pitch = calculate_head_pose(landmarks, width, height)
            yaw = yaw if yaw is not None else 0.0
            pitch = pitch if pitch is not None else 0.0

            # --------------------------------------------------
            # MODEL INFERENCE
            # --------------------------------------------------

            features = np.array(
                [[left_ear, right_ear, ear_avg, mar, yaw, pitch]]
            )

            drowsy_prob = float(
                xgb_model.predict_proba(features)[0][1]
            )

            prob_history.append(drowsy_prob)
            smoothed_prob = sum(prob_history) / len(prob_history)

            # --------------------------------------------------
            # TIMER LOGIC (same pattern as your original code)
            # --------------------------------------------------

            if smoothed_prob >= DROWSY_PROB_THRESHOLD:

                if drowsy_start is None:
                    drowsy_start = time.time()

                closed_duration = time.time() - drowsy_start

                if closed_duration >= DROWSY_TIME:
                    status = "DROWSY"
                    status_color = (0, 0, 255)
                else:
                    status = "EYES CLOSING"
                    status_color = (0, 255, 255)

            else:
                drowsy_start = None
                status = "ALERT"
                status_color = (0, 255, 0)

            # --------------------------------------------------
            # DRAW EYE/MOUTH POINTS
            # --------------------------------------------------

            for point in left_eye + right_eye + mouth:
                cv2.circle(
                    frame, (int(point[0]), int(point[1])), 3,
                    (255, 255, 0), -1
                )

            cv2.putText(
                frame, f"EAR: {ear_avg:.3f}  MAR: {mar:.3f}",
                (30, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                (255, 255, 255), 2
            )

            cv2.putText(
                frame, f"Drowsy probability: {smoothed_prob:.2f}",
                (30, 125), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                (255, 255, 255), 2
            )

        cv2.putText(
            frame, f"STATUS: {status}", (30, 50),
            cv2.FONT_HERSHEY_SIMPLEX, 0.9, status_color, 2
        )

        if status == "DROWSY":
            cv2.putText(
                frame, "WARNING: DROWSINESS DETECTED!", (30, 170),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 3
            )

        cv2.putText(
            frame, "AI HELMET - DROWSINESS MONITOR (XGBoost)",
            (30, height - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.65,
            (255, 255, 255), 2
        )

        cv2.imshow("Helmet Drowsiness Detection (ML)", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break

finally:
    camera.release()
    cv2.destroyAllWindows()
    landmarker.close()

    print()
    print("Drowsiness detection stopped.")
