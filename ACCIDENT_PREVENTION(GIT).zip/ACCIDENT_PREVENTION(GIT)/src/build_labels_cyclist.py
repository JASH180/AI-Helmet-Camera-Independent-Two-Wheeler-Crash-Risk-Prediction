"""
build_labels_cyclist.py

Builds dataset/labels_cyclist.csv for feature_collector.py from your
cyclist-accident dataset.csv + clips_output folder.

TWO KINDS OF ROWS IN dataset.csv:

  "u"-prefixed (Id 1-1000): REAL labeled cyclist accidents/near-misses.
  Ego Accident is 0 or 1, and - unlike the CCD/Kaggle datasets - this
  one has an exact "Time of Collision" timestamp, so we don't have to
  guess. crash_timestamp_sec = Time of Collision - Start Time (i.e.
  seconds into the trimmed clip, not the source video).

  "s"-prefixed (Id 1001+): unlabeled filler/background clips - every
  accident-detail column is "N.A.". ASSUMPTION: these are treated as
  normal/no-crash footage (crash_timestamp_sec left blank). This is
  an assumption, not a confirmed label - if you find out otherwise,
  drop those rows or relabel them.

Only rows whose matching file actually exists in clips_output are
written - so this is safe to re-run as you extract more "u" clips
with extract_clips.py; already-processed rows just get picked up
next time you run feature_collector.py.

Usage:
    python src/build_labels_cyclist.py
"""

import os
import re
import csv

import pandas as pd


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

DATASET_CSV = os.path.join(PROJECT_ROOT, "dataset", "dataset.csv")
CLIPS_FOLDER = os.path.join(PROJECT_ROOT, "dataset", "clips_output")
OUTPUT_FILE = os.path.join(PROJECT_ROOT, "dataset", "labels_cyclist.csv")


def sanitize_filename(name):
    return re.sub(r'[\\/*?:"<>|]', "_", str(name)).strip()


def time_to_seconds(value):
    """Parses H:MM:SS:FF or H:MM:SS timestamps (same format extract_clips.py
    uses), ignoring the frame field, and returns seconds."""

    if pd.isna(value):
        return None

    parts = str(value).strip().split(":")

    if len(parts) == 4:
        h, m, s, _frames = parts
    elif len(parts) == 3:
        h, m, s = parts
    else:
        return None

    try:
        return int(h) * 3600 + int(m) * 60 + float(s)
    except ValueError:
        return None


def build_expected_filename(row):
    """Must match extract_clips.py's naming exactly:
    f"{base}_{counter}_id{Id}.mp4" (or without counter if blank)."""

    base_name = sanitize_filename(row["File Name"])
    counter = str(row.get("Counter", "")).strip()

    if counter and counter.lower() != "nan":
        return f"{base_name}_{counter}_id{row['Id']}.mp4"

    return f"{base_name}_id{row['Id']}.mp4"


def main():

    if not os.path.exists(DATASET_CSV):
        print(f"ERROR: {DATASET_CSV} not found.")
        return

    if not os.path.isdir(CLIPS_FOLDER):
        print(f"ERROR: {CLIPS_FOLDER} not found.")
        return

    data = pd.read_csv(DATASET_CSV)

    rows = []
    skipped_missing = 0

    for _, row in data.iterrows():

        filename = build_expected_filename(row)
        file_path = os.path.join(CLIPS_FOLDER, filename)

        if not os.path.exists(file_path):
            skipped_missing += 1
            continue

        ego_accident = str(row.get("Ego Accident", "")).strip()

        if ego_accident == "1":

            start_sec = time_to_seconds(row["Start Time"])
            collision_sec = time_to_seconds(row["Time of Collision"])

            if start_sec is None or collision_sec is None:
                crash_timestamp = ""
            else:
                # Collision time relative to the START of this trimmed
                # clip, not the source video.
                relative = collision_sec - start_sec
                crash_timestamp = round(max(relative, 0.0), 2)

        else:
            # ego_accident == "0" (real negative) or "N.A." (unlabeled
            # background clip, assumed negative - see docstring).
            crash_timestamp = ""

        rows.append({
            "filename": filename,
            "crash_timestamp_sec": crash_timestamp,
        })

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

    with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["filename", "crash_timestamp_sec"])
        writer.writeheader()
        writer.writerows(rows)

    positive = sum(1 for row in rows if row["crash_timestamp_sec"] != "")

    print(f"Found {len(rows)} clips already in {CLIPS_FOLDER}")
    print(f"  (skipped {skipped_missing} dataset.csv rows with no matching file yet)")
    print()
    print(f"Wrote {len(rows)} labeled rows to {OUTPUT_FILE}")
    print(f"  Real/assumed crash clips (positive): {positive}")
    print(f"  No-crash clips (negative): {len(rows) - positive}")


if __name__ == "__main__":
    main()
