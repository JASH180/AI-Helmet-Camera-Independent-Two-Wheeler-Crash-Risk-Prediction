"""
relabel_ccd.py - fixes the CCD labels using the official Crash-1500.txt
annotation (which frame the accident starts at) WITHOUT re-extracting features.

  python src/relabel_ccd.py --annotation dataset/Crash-1500.txt --videos dataset/ccd_videos

Reads  dataset/training_universal_ccd.csv   (backup: ..._ccd_before_relabel.csv)
Writes dataset/training_universal_ccd.csv   (labels + crash_time_sec corrected)
Also rewrites dataset/labels_ccd.csv timestamps (backup kept).
Then run: python src/combine_universal_data.py ; python src/train_universal_model.py
"""
import os, re, shutil, argparse
import cv2
import pandas as pd

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PRE = 3.0          # seconds before the crash that count as pre-crash (same as feature_collector)
POST_DROP = 1.0


def read_annotation(path):
    crash_frac = {}
    for line in open(path, encoding="utf-8"):
        m = re.match(r"\s*(?:\d+\s+)?(\d+),\[([^\]]*)\]", line)
        if not m:
            continue
        v = [int(x) for x in m.group(2).replace(",", " ").split()]
        if 1 in v:
            crash_frac[m.group(1).zfill(6)] = v.index(1) / len(v)
    return crash_frac


def duration(videos, name, fallback):
    cap = cv2.VideoCapture(os.path.join(videos, name))
    if cap.isOpened():
        fps, n = cap.get(cv2.CAP_PROP_FPS) or 0, cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
        cap.release()
        if fps > 0 and n > 0:
            return n / fps
    return fallback


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--annotation", default=os.path.join(ROOT, "dataset", "Crash-1500.txt"))
    ap.add_argument("--videos", default=os.path.join(ROOT, "dataset", "ccd_videos"))
    ap.add_argument("--data", default=os.path.join(ROOT, "dataset", "training_universal_ccd.csv"))
    ap.add_argument("--labels", default=os.path.join(ROOT, "dataset", "labels_ccd.csv"))
    a = ap.parse_args()

    frac = read_annotation(a.annotation)
    print(f"{len(frac)} annotated crash clips")

    df = pd.read_csv(a.data)
    shutil.copy(a.data, a.data.replace(".csv", "_before_relabel.csv"))

    crash_time, changed = {}, 0
    for vid in df["video_id"].unique():
        m = re.search(r"Crash-1500[/\\](\d+)\.", vid)
        if not m:
            continue
        key = m.group(1).zfill(6)
        if key not in frac:
            continue
        dur = duration(a.videos, vid, df.loc[df.video_id == vid, "window_start_sec"].max() + 1.0)
        crash_time[vid] = round(frac[key] * dur, 2)

    keep = []
    for vid, g in df.groupby("video_id", sort=False):
        if vid not in crash_time:
            keep.append(g)                      # Normal clips: untouched
            continue
        T = crash_time[vid]
        g = g[g["window_start_sec"] < T].copy() # windows starting at/after impact are not a warning signal
        g["label"] = ((g["window_start_sec"] + 1.0 > T - PRE)).astype(int)
        g["crash_time_sec"] = T
        keep.append(g)
        changed += 1

    out = pd.concat(keep, ignore_index=True)
    out.to_csv(a.data, index=False)
    print(f"relabelled {changed} clips; windows {len(df)} -> {len(out)}; "
          f"pre-crash share {100*df['label'].mean():.0f}% -> {100*out['label'].mean():.0f}%")

    if os.path.exists(a.labels):
        shutil.copy(a.labels, a.labels.replace(".csv", "_before_relabel.csv"))
        lab = pd.read_csv(a.labels)
        def fix(row):
            return crash_time.get(row["filename"], row["crash_timestamp_sec"])
        lab["crash_timestamp_sec"] = lab.apply(fix, axis=1)
        lab.to_csv(a.labels, index=False)


if __name__ == "__main__":
    main()
