import tkinter as tk
from tkinter import ttk
import csv
import os
import glob
from collections import Counter

try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False


PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

LOG_FILE = os.path.join(
    PROJECT_ROOT,
    "ride_data",
    "ride_events.csv"
)

# Where the R scripts in r_analysis/ save their output PNGs.
R_PLOTS_DIR = os.path.join(
    PROJECT_ROOT,
    "dataset",
    "r_plots"
)


def load_events():

    events = []

    if not os.path.exists(LOG_FILE):
        return events

    with open(
        LOG_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        reader = csv.DictReader(file)

        for row in reader:

            try:
                row["distance_km"] = float(
                    row["distance_km"]
                )

                events.append(row)

            except:
                pass

    return events


def open_analytics_gallery():
    """Opens a scrollable window showing every PNG chart the R scripts
    in r_analysis/ have generated into dataset/r_plots/. This is what
    "advanced data visualization" looks like inside the running app -
    run the R scripts on your own data whenever you want fresh charts,
    then just reopen this window; no code changes needed either side."""

    gallery = tk.Toplevel()
    gallery.title("Advanced Analytics")
    gallery.geometry("950x750")

    if not PIL_AVAILABLE:

        tk.Label(
            gallery,
            text=(
                "Pillow isn't installed, so images can't be displayed here.\n"
                "Run: pip install Pillow"
            ),
            font=("Arial", 12),
            fg="red",
            padx=20,
            pady=20,
        ).pack()

        return

    png_files = sorted(glob.glob(os.path.join(R_PLOTS_DIR, "*.png")))

    if not png_files:

        tk.Label(
            gallery,
            text=(
                "No charts found yet.\n\n"
                "Run the R scripts in r_analysis/ first (from the project "
                "root, in RStudio or a terminal):\n\n"
                "  Rscript r_analysis/plot_ncdot_crashes.R\n"
                "  Rscript r_analysis/plot_crash_model_data.R\n"
                "  Rscript r_analysis/plot_cyclist_dataset.R\n\n"
                "Then reopen this window."
            ),
            font=("Arial", 12),
            justify="left",
            padx=20,
            pady=20,
        ).pack()

        return

    # --------------------------------------------------------
    # SCROLLABLE CANVAS OF ALL CHARTS
    # --------------------------------------------------------

    outer = tk.Frame(gallery)
    outer.pack(fill="both", expand=True)

    canvas = tk.Canvas(outer)
    scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
    scroll_frame = tk.Frame(canvas)

    scroll_frame.bind(
        "<Configure>",
        lambda event: canvas.configure(scrollregion=canvas.bbox("all")),
    )

    canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    # Keep references so images aren't garbage-collected.
    gallery.image_refs = []

    MAX_WIDTH = 880

    for path in png_files:

        image = Image.open(path)

        if image.width > MAX_WIDTH:
            ratio = MAX_WIDTH / image.width
            image = image.resize(
                (MAX_WIDTH, int(image.height * ratio)),
                Image.LANCZOS,
            )

        photo = ImageTk.PhotoImage(image)
        gallery.image_refs.append(photo)

        title = os.path.splitext(os.path.basename(path))[0].replace("_", " ")

        tk.Label(
            scroll_frame,
            text=title.title(),
            font=("Arial", 13, "bold"),
            pady=10,
        ).pack()

        tk.Label(scroll_frame, image=photo).pack(pady=(0, 20))


def create_dashboard():

    events = load_events()

    # --------------------------------------------------------
    # CALCULATIONS
    # --------------------------------------------------------

    if events:

        distance = max(
            event["distance_km"]
            for event in events
        )

        warnings = len(events)

        warnings_per_km = (
            warnings / distance
            if distance > 0
            else 0
        )

        event_counts = Counter(
            event["event_type"]
            for event in events
        )

    else:

        distance = 0
        warnings = 0
        warnings_per_km = 0
        event_counts = Counter()


    # --------------------------------------------------------
    # WINDOW
    # --------------------------------------------------------

    root = tk.Tk()

    root.title(
        "AI Helmet Safety Dashboard"
    )

    root.geometry(
        "850x650"
    )

    root.configure(
        padx=30,
        pady=30
    )


    # --------------------------------------------------------
    # TITLE
    # --------------------------------------------------------

    title = tk.Label(
        root,
        text="AI HELMET SAFETY DASHBOARD",
        font=("Arial", 24, "bold")
    )

    title.pack(
        pady=15
    )


    subtitle = tk.Label(
        root,
        text="Driver Safety & Ride Analysis",
        font=("Arial", 12)
    )

    subtitle.pack(
        pady=5
    )


    # --------------------------------------------------------
    # SUMMARY
    # --------------------------------------------------------

    summary_frame = tk.Frame(
        root
    )

    summary_frame.pack(
        pady=25
    )


    def create_card(
        parent,
        title,
        value,
        row,
        column
    ):

        frame = tk.Frame(
            parent,
            relief="ridge",
            borderwidth=2,
            padx=25,
            pady=15
        )

        frame.grid(
            row=row,
            column=column,
            padx=10
        )


        tk.Label(
            frame,
            text=title,
            font=("Arial", 11)
        ).pack()


        tk.Label(
            frame,
            text=value,
            font=("Arial", 20, "bold")
        ).pack(
            pady=5
        )


    create_card(
        summary_frame,
        "Distance",
        f"{distance:.2f} km",
        0,
        0
    )


    create_card(
        summary_frame,
        "Warnings",
        str(warnings),
        0,
        1
    )


    create_card(
        summary_frame,
        "Warnings / KM",
        f"{warnings_per_km:.2f}",
        0,
        2
    )


    # --------------------------------------------------------
    # WARNING BREAKDOWN
    # --------------------------------------------------------

    tk.Label(
        root,
        text="WARNING BREAKDOWN",
        font=("Arial", 16, "bold")
    ).pack(
        pady=15
    )


    tree = ttk.Treeview(
        root,
        columns=("type", "count"),
        show="headings",
        height=8
    )


    tree.heading(
        "type",
        text="Event Type"
    )

    tree.heading(
        "count",
        text="Count"
    )


    tree.column(
        "type",
        width=300
    )

    tree.column(
        "count",
        width=150
    )


    for event_type, count in event_counts.items():

        tree.insert(
            "",
            "end",
            values=(
                event_type,
                count
            )
        )


    tree.pack(
        pady=10
    )


    # --------------------------------------------------------
    # ADVANCED ANALYTICS BUTTON
    # --------------------------------------------------------

    tk.Button(
        root,
        text="📊 View Advanced Analytics",
        font=("Arial", 12, "bold"),
        padx=20,
        pady=10,
        command=open_analytics_gallery,
    ).pack(
        pady=15
    )


    # --------------------------------------------------------
    # FOOTER
    # --------------------------------------------------------

    tk.Label(
        root,
        text="AI-based Driver Monitoring & Road Safety System",
        font=("Arial", 10)
    ).pack(
        pady=20
    )


    root.mainloop()


if __name__ == "__main__":

    create_dashboard()