import cv2
import os


def cut_video(input_video, output_video, start_time, end_time):
    """
    Cuts a section from a video.

    start_time and end_time are in seconds.
    """

    cap = cv2.VideoCapture(input_video)

    if not cap.isOpened():
        print("Error: Could not open video.")
        return

    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    start_frame = int(start_time * fps)
    end_frame = int(end_time * fps)

    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)

    fourcc = cv2.VideoWriter_fourcc(*"mp4v")

    out = cv2.VideoWriter(
        output_video,
        fourcc,
        fps,
        (width, height)
    )

    current_frame = start_frame

    while current_frame <= end_frame:

        ret, frame = cap.read()

        if not ret:
            break

        out.write(frame)

        current_frame += 1

    cap.release()
    out.release()

    print("Video successfully cut!")