import cv2
import mediapipe as mp
import os
import time
import numpy as np
import winsound

from mediapipe.tasks import python
from mediapipe.tasks.python import vision


# ============================================================
# PROJECT PATH
# ============================================================

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

MODEL_PATH = os.path.join(
    PROJECT_ROOT,
    "models",
    "face_landmarker.task"
)


# ============================================================
# CHECK MODEL
# ============================================================

if not os.path.exists(MODEL_PATH):
    print("ERROR: face_landmarker.task not found.")
    print("Expected location:")
    print(MODEL_PATH)
    exit()


# ============================================================
# MEDIAPIPE FACE LANDMARKER
# ============================================================

base_options = python.BaseOptions(
    model_asset_path=MODEL_PATH
)

options = vision.FaceLandmarkerOptions(
    base_options=base_options,
    running_mode=vision.RunningMode.VIDEO,
    num_faces=1,
    min_face_detection_confidence=0.5,
    min_face_presence_confidence=0.5,
    min_tracking_confidence=0.5,
    output_face_blendshapes=False,
    output_facial_transformation_matrixes=False
)

landmarker = vision.FaceLandmarker.create_from_options(
    options
)


# ============================================================
# CAMERA
# ============================================================

camera = cv2.VideoCapture(0)

if not camera.isOpened():
    print("ERROR: Camera could not be opened.")
    landmarker.close()
    exit()

camera.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)


# ============================================================
# FACE LANDMARK INDEXES
# ============================================================

NOSE_TIP = 1
CHIN = 152

LEFT_EYE_OUTER = 33
RIGHT_EYE_OUTER = 263

LEFT_MOUTH = 61
RIGHT_MOUTH = 291


# ============================================================
# 3D FACE MODEL
# ============================================================

MODEL_POINTS = np.array(
    [
        (0.0, 0.0, 0.0),
        (0.0, -63.6, -12.5),
        (-43.3, 32.7, -26.0),
        (43.3, 32.7, -26.0),
        (-28.9, -28.9, -24.1),
        (28.9, -28.9, -24.1)
    ],
    dtype=np.float64
)


# ============================================================
# SETTINGS
# ============================================================

# Calibration duration
CALIBRATION_TIME = 3.0

# How far the rider can move from the calibrated position
# before being considered distracted.
YAW_THRESHOLD = 15.0
PITCH_THRESHOLD = 15.0

# Rider must remain distracted for this long
DISTRACTION_TIME = 2.0

# Time between warning beeps
WARNING_INTERVAL = 1.5

# Beep settings
BEEP_FREQUENCY = 1000
BEEP_DURATION = 500


# ============================================================
# VARIABLES
# ============================================================

calibration_start = time.time()

calibration_yaw = []
calibration_pitch = []

calibration_complete = False

baseline_yaw = 0.0
baseline_pitch = 0.0

distraction_start = None

last_warning_time = 0

timestamp_ms = 0


# ============================================================
# GET LANDMARK POINT
# ============================================================

def get_landmark_point(
    landmarks,
    index,
    width,
    height
):

    landmark = landmarks[index]

    x = landmark.x * width
    y = landmark.y * height

    return (x, y)


# ============================================================
# CALCULATE HEAD POSE
# ============================================================

def calculate_head_pose(
    landmarks,
    width,
    height
):

    try:

        image_points = np.array(
            [
                get_landmark_point(
                    landmarks,
                    NOSE_TIP,
                    width,
                    height
                ),

                get_landmark_point(
                    landmarks,
                    CHIN,
                    width,
                    height
                ),

                get_landmark_point(
                    landmarks,
                    LEFT_EYE_OUTER,
                    width,
                    height
                ),

                get_landmark_point(
                    landmarks,
                    RIGHT_EYE_OUTER,
                    width,
                    height
                ),

                get_landmark_point(
                    landmarks,
                    LEFT_MOUTH,
                    width,
                    height
                ),

                get_landmark_point(
                    landmarks,
                    RIGHT_MOUTH,
                    width,
                    height
                )
            ],
            dtype=np.float64
        )

        focal_length = width

        center = (
            width / 2,
            height / 2
        )

        camera_matrix = np.array(
            [
                [focal_length, 0, center[0]],
                [0, focal_length, center[1]],
                [0, 0, 1]
            ],
            dtype=np.float64
        )

        distortion_coefficients = np.zeros(
            (4, 1)
        )

        success, rotation_vector, translation_vector = cv2.solvePnP(
            MODEL_POINTS,
            image_points,
            camera_matrix,
            distortion_coefficients,
            flags=cv2.SOLVEPNP_ITERATIVE
        )

        if not success:
            return None, None

        rotation_matrix, _ = cv2.Rodrigues(
            rotation_vector
        )

        angles = cv2.RQDecomp3x3(
            rotation_matrix
        )[0]

        pitch = angles[0]
        yaw = angles[1]

        return yaw, pitch

    except Exception:
        return None, None


# ============================================================
# DETERMINE HEAD DIRECTION
# ============================================================

def determine_direction(
    yaw,
    pitch,
    baseline_yaw,
    baseline_pitch
):

    if yaw is None or pitch is None:
        return "UNKNOWN"

    yaw_difference = yaw - baseline_yaw
    pitch_difference = pitch - baseline_pitch

    # Looking left
    if yaw_difference > YAW_THRESHOLD:
        return "LOOKING LEFT"

    # Looking right
    if yaw_difference < -YAW_THRESHOLD:
        return "LOOKING RIGHT"

    # Looking down
    if pitch_difference > PITCH_THRESHOLD:
        return "LOOKING DOWN"

    # Looking up
    if pitch_difference < -PITCH_THRESHOLD:
        return "LOOKING UP"

    # Normal position
    return "LOOKING FORWARD"


# ============================================================
# PLAY WARNING SOUND
# ============================================================

def play_warning_sound():

    winsound.Beep(
        BEEP_FREQUENCY,
        BEEP_DURATION
    )


# ============================================================
# START PROGRAM
# ============================================================

print()
print("==========================================")
print("     AI HELMET CONCENTRATION SYSTEM")
print("==========================================")
print()
print("Camera starting...")
print()
print("Look straight ahead during calibration.")
print()


# ============================================================
# MAIN LOOP
# ============================================================

try:

    while True:

        # ----------------------------------------------------
        # READ CAMERA
        # ----------------------------------------------------

        ret, frame = camera.read()

        if not ret:

            print("ERROR: Could not read camera.")
            break


        # Mirror camera
        frame = cv2.flip(frame, 1)

        height, width, _ = frame.shape


        # ----------------------------------------------------
        # CONVERT TO RGB
        # ----------------------------------------------------

        rgb_frame = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB
        )


        mp_image = mp.Image(
            image_format=mp.ImageFormat.SRGB,
            data=rgb_frame
        )


        # ----------------------------------------------------
        # FACE DETECTION
        # ----------------------------------------------------

        result = landmarker.detect_for_video(
            mp_image,
            timestamp_ms
        )

        timestamp_ms += 33


        # ----------------------------------------------------
        # DEFAULT VALUES
        # ----------------------------------------------------

        status = "NO FACE"

        direction = "UNKNOWN"

        status_color = (
            0,
            0,
            255
        )


        # ====================================================
        # FACE FOUND
        # ====================================================

        if result.face_landmarks:

            landmarks = result.face_landmarks[0]


            # ------------------------------------------------
            # HEAD POSE
            # ------------------------------------------------

            yaw, pitch = calculate_head_pose(
                landmarks,
                width,
                height
            )


            # =================================================
            # CALIBRATION
            # =================================================

            if not calibration_complete:

                elapsed = (
                    time.time() -
                    calibration_start
                )


                # Collect head-position data
                if yaw is not None and pitch is not None:

                    calibration_yaw.append(yaw)
                    calibration_pitch.append(pitch)


                remaining = max(
                    0,
                    CALIBRATION_TIME - elapsed
                )


                status = "CALIBRATING"

                status_color = (
                    0,
                    255,
                    255
                )


                # ------------------------------------------------
                # CALIBRATION MESSAGE
                # ------------------------------------------------

                cv2.putText(
                    frame,
                    "LOOK STRAIGHT AHEAD",
                    (30, 55),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1.0,
                    (0, 255, 255),
                    3
                )


                cv2.putText(
                    frame,
                    f"Calibration: {remaining:.1f}s",
                    (30, 100),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (255, 255, 255),
                    2
                )


                # ------------------------------------------------
                # COMPLETE CALIBRATION
                # ------------------------------------------------

                if elapsed >= CALIBRATION_TIME:

                    if len(calibration_yaw) > 0:

                        baseline_yaw = float(
                            np.median(
                                calibration_yaw
                            )
                        )

                        baseline_pitch = float(
                            np.median(
                                calibration_pitch
                            )
                        )

                        calibration_complete = True

                        print()
                        print("Calibration complete!")

                        print(
                            f"Baseline yaw: "
                            f"{baseline_yaw:.2f}"
                        )

                        print(
                            f"Baseline pitch: "
                            f"{baseline_pitch:.2f}"
                        )

                        print()

                    else:

                        # Restart calibration
                        calibration_start = time.time()


            # =================================================
            # NORMAL MONITORING
            # =================================================

            else:

                direction = determine_direction(
                    yaw,
                    pitch,
                    baseline_yaw,
                    baseline_pitch
                )


                # ------------------------------------------------
                # LOOKING FORWARD
                # ------------------------------------------------

                if direction == "LOOKING FORWARD":

                    status = "CONCENTRATED"

                    status_color = (
                        0,
                        255,
                        0
                    )

                    # Reset distraction timer
                    distraction_start = None


                # ------------------------------------------------
                # LOOKING AWAY
                # ------------------------------------------------

                else:

                    if distraction_start is None:

                        distraction_start = time.time()


                    distraction_duration = (
                        time.time() -
                        distraction_start
                    )


                    # ------------------------------------------------
                    # SHORT LOOK
                    # ------------------------------------------------

                    if distraction_duration < DISTRACTION_TIME:

                        status = direction

                        status_color = (
                            0,
                            255,
                            255
                        )


                    # ------------------------------------------------
                    # DISTRACTED
                    # ------------------------------------------------

                    else:

                        status = "DISTRACTED"

                        status_color = (
                            0,
                            0,
                            255
                        )


                        # =================================================
                        # AUDIO WARNING
                        # =================================================

                        current_time = time.time()


                        if (
                            current_time -
                            last_warning_time
                            >= WARNING_INTERVAL
                        ):

                            play_warning_sound()

                            last_warning_time = current_time


            # =================================================
            # DRAW ALL FACE LANDMARKS
            # =================================================

            for landmark in landmarks:

                x = int(
                    landmark.x * width
                )

                y = int(
                    landmark.y * height
                )

                cv2.circle(
                    frame,
                    (x, y),
                    1,
                    (255, 255, 255),
                    -1
                )


            # =================================================
            # DRAW IMPORTANT LANDMARKS
            # =================================================

            important_points = [
                NOSE_TIP,
                CHIN,
                LEFT_EYE_OUTER,
                RIGHT_EYE_OUTER,
                LEFT_MOUTH,
                RIGHT_MOUTH
            ]


            for index in important_points:

                x = int(
                    landmarks[index].x *
                    width
                )

                y = int(
                    landmarks[index].y *
                    height
                )


                cv2.circle(
                    frame,
                    (x, y),
                    4,
                    (0, 255, 255),
                    -1
                )


        # ====================================================
        # DISPLAY STATUS
        # ====================================================

        cv2.putText(
            frame,
            f"STATUS: {status}",
            (30, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.9,
            status_color,
            2
        )


        # ----------------------------------------------------
        # HEAD DIRECTION
        # ----------------------------------------------------

        if calibration_complete:

            cv2.putText(
                frame,
                f"HEAD: {direction}",
                (30, 90),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


        # ----------------------------------------------------
        # DISTRACTION TIMER
        # ----------------------------------------------------

        if distraction_start is not None:

            duration = (
                time.time() -
                distraction_start
            )

            cv2.putText(
                frame,
                f"Distraction: {duration:.1f}s",
                (30, 125),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 255),
                2
            )


        # ====================================================
        # WARNING MESSAGE
        # ====================================================

        if status == "DISTRACTED":

            cv2.putText(
                frame,
                "WARNING: PLEASE FOCUS ON THE ROAD!",
                (30, 170),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                (0, 0, 255),
                3
            )


        # ====================================================
        # PROJECT TITLE
        # ====================================================

        cv2.putText(
            frame,
            "AI HELMET SAFETY SYSTEM",
            (30, height - 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2
        )


        # ====================================================
        # SHOW CAMERA
        # ====================================================

        cv2.imshow(
            "Helmet Concentration Detection",
            frame
        )


        # ====================================================
        # EXIT
        # ====================================================

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break


finally:

    camera.release()

    cv2.destroyAllWindows()

    landmarker.close()

    print()
    print("Concentration detection stopped.")