import csv
import os
from datetime import datetime


# ============================================================
# PROJECT PATH
# ============================================================

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

DATA_FOLDER = os.path.join(
    PROJECT_ROOT,
    "ride_data"
)

LOG_FILE = os.path.join(
    DATA_FOLDER,
    "ride_events.csv"
)


# ============================================================
# CREATE DATA FOLDER
# ============================================================

os.makedirs(
    DATA_FOLDER,
    exist_ok=True
)


# ============================================================
# CREATE CSV FILE
# ============================================================

def create_log_file():

    if not os.path.exists(LOG_FILE):

        with open(
            LOG_FILE,
            "w",
            newline="",
            encoding="utf-8"
        ) as file:

            writer = csv.writer(file)

            writer.writerow(
                [
                    "timestamp",
                    "distance_km",
                    "event_type",
                    "warning_level",
                    "message"
                ]
            )


# ============================================================
# LOG EVENT
# ============================================================

def log_event(
    distance_km,
    event_type,
    warning_level,
    message
):

    create_log_file()

    timestamp = datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )

    with open(
        LOG_FILE,
        "a",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.writer(file)

        writer.writerow(
            [
                timestamp,
                round(distance_km, 2),
                event_type,
                warning_level,
                message
            ]
        )


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    print("Testing data logger...")

    log_event(
        0.5,
        "DISTRACTION",
        "MEDIUM",
        "Driver looking left"
    )

    log_event(
        1.2,
        "DROWSINESS",
        "HIGH",
        "Eyes closed for too long"
    )

    log_event(
        2.7,
        "ROAD_WARNING",
        "HIGH",
        "Vehicle approaching"
    )

    print()
    print("Test events saved successfully.")
    print()
    print("File location:")
    print(LOG_FILE)