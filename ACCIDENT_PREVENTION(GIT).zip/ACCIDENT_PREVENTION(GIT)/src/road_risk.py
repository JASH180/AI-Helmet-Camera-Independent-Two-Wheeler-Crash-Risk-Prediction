ROAD_VEHICLES = {
    "car",
    "motorcycle",
    "bus",
    "truck",
    "bicycle"
}


def is_road_vehicle(class_name):
    return class_name in ROAD_VEHICLES


def calculate_vehicle_risk(
    x1,
    y1,
    x2,
    y2,
    frame_width,
    frame_height,
    growth_ratio
):

    object_width = x2 - x1
    object_height = y2 - y1

    frame_area = frame_width * frame_height
    object_area = object_width * object_height

    area_ratio = object_area / frame_area

    # Object center
    center_x = (x1 + x2) / 2

    frame_center = frame_width / 2

    # How close the object is to the centre
    center_offset = abs(
        center_x - frame_center
    ) / frame_width


    # --------------------------------------------------------
    # VERY SMALL / FAR OBJECT
    # --------------------------------------------------------

    if area_ratio < 0.05:

        return 10, "SAFE"


    # --------------------------------------------------------
    # SMALL OBJECT
    # --------------------------------------------------------

    if area_ratio < 0.12:

        if growth_ratio > 0.20:

            return 40, "MEDIUM"

        return 20, "SAFE"


    # --------------------------------------------------------
    # MEDIUM OBJECT
    # --------------------------------------------------------

    if area_ratio < 0.25:

        if growth_ratio > 0.25 and center_offset < 0.20:

            return 65, "HIGH"

        elif growth_ratio > 0.15:

            return 45, "MEDIUM"

        return 30, "MEDIUM"


    # --------------------------------------------------------
    # LARGE OBJECT
    # --------------------------------------------------------

    if center_offset < 0.18:

        if growth_ratio > 0.30:

            return 95, "CRITICAL"

        elif growth_ratio > 0.15:

            return 80, "HIGH"

        return 60, "HIGH"


    # Large but not directly ahead
    return 45, "MEDIUM"