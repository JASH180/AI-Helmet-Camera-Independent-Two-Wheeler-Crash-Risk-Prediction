"""
universal_predict.py - run the universal model on ANY footage.

  python src/universal_predict.py --source "E:/videos/ride.mp4"
  python src/universal_predict.py --source "E:/videos/folder" --batch
  python src/universal_predict.py --source "http://192.168.1.5:8080/video"   (phone IP Webcam)
  python src/universal_predict.py --source 0                                  (webcam)

Options: --save-ride NAME   writes dataset/rides/ride_NAME.csv (R dashboard schema)
         --live-log         appends to the R dashboard live log while running
         --no-show          no window (batch / headless)   --no-beep
"""
import os
import sys
import csv
import time
import argparse
import collections

import cv2
import numpy as np
import joblib
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from universal_features import FrameAnalyzer, WindowAggregator, ContextBuilder, UNIVERSAL_BASE_COLUMNS

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MODEL = os.path.join(ROOT, "models", "universal_crash_model.joblib")
RIDES = os.path.join(ROOT, "dataset", "rides")
LIVE_LOG = os.path.join(ROOT, "dataset", "live_ride_log.csv")      # read by the R dashboard
FRAME_PATH = os.path.join(ROOT, "dataset", "live_frame.jpg")        # latest camera picture for the R dashboard
FRAME_EVERY_SEC = 0.4
FRAME_WIDTH = 640
DASH_ALERT = 0.75                                                   # the dashboard's fixed alert line

# the 14 window columns the R dashboard expects
R_FEATURES = ["mean_risk_score", "max_risk_score", "max_growth_ratio", "mean_growth_ratio",
              "max_object_count", "mean_object_count", "high_risk_frame_count",
              "critical_risk_frame_count", "risk_score_trend", "risk_score_std",
              "risk_score_p90", "growth_ratio_trend", "object_count_trend",
              "time_to_collision_estimate"]
VIDEO_EXT = (".mp4", ".avi", ".mov", ".mkv", ".mts")


class UniversalPredictor:
    def __init__(self, model_path=MODEL):
        art = joblib.load(model_path)
        self.estimator, self.calibrator = art["estimator"], art["calibrator"]
        self.columns, self.threshold = art["feature_columns"], art["threshold"]
        self.persistence = art.get("persistence", 2)
        self.name = art.get("model_name", "")
        self.reset()

    def reset(self):
        self.context = ContextBuilder()
        self.recent = collections.deque(maxlen=self.persistence)

    def score_window(self, legacy_row, universal_row):
        base = dict(universal_row)
        full = self.context.update(base)
        row = {**legacy_row, **full}
        x = pd.DataFrame([[row.get(c, 0.0) for c in self.columns]], columns=self.columns).fillna(0.0)
        p = float(self.calibrator.predict([self.estimator.predict_proba(x)[0, 1]])[0])
        self.recent.append(p >= self.threshold)
        alert = len(self.recent) == self.persistence and all(self.recent)
        return p, alert, row


def dashboard_score(p, threshold):
    """Monotonic rescale so the model's alert threshold lands on the dashboard's
    0.75 line (the R app uses one fixed line). Ranking and AUC are unchanged."""
    if p <= threshold:
        return p * DASH_ALERT / threshold
    return DASH_ALERT + (p - threshold) * (1 - DASH_ALERT) / (1 - threshold)


def write_frame(frame, path=None):
    """Atomic write so the R app never reads a half-written picture."""
    path = path or FRAME_PATH
    h, w = frame.shape[:2]
    small = cv2.resize(frame, (FRAME_WIDTH, int(h * FRAME_WIDTH / w))) if w > FRAME_WIDTH else frame
    tmp = path + ".tmp.jpg"
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        cv2.imwrite(tmp, small, [cv2.IMWRITE_JPEG_QUALITY, 80])
        os.replace(tmp, path)
    except OSError:
        pass          # R may be reading it right now: skip this picture


def beep():
    try:
        import winsound
        winsound.Beep(1500, 250)
    except Exception:
        print("\a", end="")


def run(source, predictor, analyzer, show=True, sound=True, save_name=None, live_log=False):
    cap = cv2.VideoCapture(int(source) if str(source).isdigit() else source)
    if not cap.isOpened():
        print(f"Cannot open {source}")
        return None
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    is_file = os.path.isfile(str(source))
    analyzer.reset(); predictor.reset()
    if live_log and os.path.exists(LIVE_LOG):     # keep the previous session as a saved ride
        os.makedirs(RIDES, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(os.path.getmtime(LIVE_LOG)))
        os.replace(LIVE_LOG, os.path.join(RIDES, f"ride_{stamp}.csv"))
    agg = WindowAggregator()
    rows, p, alert, idx, t0, last_frame_t = [], 0.0, False, 0, time.time(), 0.0

    while True:
        ok, frame = cap.read()
        if not ok:
            break
        t = idx / fps if is_file else time.time() - t0
        rec = analyzer.analyze(frame, t)
        closed = agg.add(rec)
        if closed:
            start, legacy, universal, _ = closed
            if legacy is not None:
                p, alert, row = predictor.score_window(legacy, universal)
                shown = dashboard_score(p, predictor.threshold)
                out = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"), "elapsed_sec": round(t, 2)}
                out.update({c: float(row.get(c, 0.0) or 0.0) for c in R_FEATURES})
                out["crash_probability"] = round(shown, 4)
                out["status"] = "CRITICAL" if shown >= 0.8 else "HIGH RISK" if shown >= 0.6 else "CAUTION" if shown >= 0.3 else "SAFE"
                out["model_probability"] = round(p, 4)
                rows.append(out)
                if live_log:
                    new = not os.path.exists(LIVE_LOG)
                    with open(LIVE_LOG, "a", newline="") as f:
                        w = csv.DictWriter(f, fieldnames=list(out)); 
                        if new: w.writeheader()
                        w.writerow(out)
                if alert and sound:
                    beep()
        if show or live_log:
            color = (0, 0, 255) if alert else (0, 200, 0)
            cv2.rectangle(frame, (0, 0), (frame.shape[1], 46), (20, 20, 20), -1)
            cv2.putText(frame, f"risk {p:.2f}  {'!! ALERT !!' if alert else 'ok'}", (10, 32),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 2)
            if live_log and time.time() - last_frame_t >= FRAME_EVERY_SEC:
                write_frame(frame)
                last_frame_t = time.time()
        if show:
            cv2.imshow("Universal crash risk", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
        idx += 1
    cap.release()
    if show:
        cv2.destroyAllWindows()

    df = pd.DataFrame(rows)
    if save_name and len(df):
        os.makedirs(RIDES, exist_ok=True)
        path = os.path.join(RIDES, f"ride_{save_name}.csv")
        df.to_csv(path, index=False)
        print(f"Saved ride -> {path}")
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", required=True)
    ap.add_argument("--batch", action="store_true")
    ap.add_argument("--save-ride", default=None)
    ap.add_argument("--live-log", action="store_true")
    ap.add_argument("--no-show", action="store_true")
    ap.add_argument("--no-beep", action="store_true")
    ap.add_argument("--model", default=MODEL)
    a = ap.parse_args()

    from ultralytics import YOLO
    analyzer = FrameAnalyzer(yolo_model=YOLO(os.path.join(ROOT, "yolo11n.pt")))
    predictor = UniversalPredictor(a.model)

    if a.batch:
        for f in sorted(os.listdir(a.source)):
            if f.lower().endswith(VIDEO_EXT):
                df = run(os.path.join(a.source, f), predictor, analyzer, show=False,
                         sound=False, save_name=os.path.splitext(f)[0])
                if df is not None and len(df):
                    print(f"{f}: peak risk {df.crash_probability.max():.2f}, "
                          f"alerts {(df.status == 'ALERT').sum()}")
    else:
        run(a.source, predictor, analyzer, show=not a.no_show, sound=not a.no_beep,
            save_name=a.save_ride, live_log=a.live_log)


if __name__ == "__main__":
    main()
