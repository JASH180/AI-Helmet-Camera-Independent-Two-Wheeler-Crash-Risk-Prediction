"""
train_accident_risk_model.py

Trains the "will this ride/route/condition end in a SEVERE accident"
model for the 2-Wheeler Accident Prediction & Prevention system.

DATA SOURCE
    dataset/archive/NCDOT_BikePedCrash.csv
    (11,266 real bicyclist/pedestrian crash records, NC DOT)

WHY THIS FILE EXISTS
    This is the piece that was missing from the project: every other
    script (extract_features.py, feature_collector.py, train_model.py)
    needs raw videos or labeled face images that are not in the zip.
    NCDOT_BikePedCrash.csv is the one dataset in the project that is
    already tabular, already labeled, and large enough to train a real
    model on right now - no video/image collection required.

WHAT IT PREDICTS
    HighSeverity = 1  ->  crash was "A: Suspected Serious Injury" or
                          "K: Killed"
    HighSeverity = 0  ->  everything else (No/Possible/Minor injury)

    Only features that are known BEFORE or DURING the ride (time of
    day, weather, road type, speed limit, rider/driver demographics,
    crash configuration) are used. Post-crash outcome columns
    (BikeInjury, DrvrInjury, NumBicsKil/Ain/Bin/Cin/Noi/Uin/Tot,
    AmbulanceR, HitRun) are dropped - training on those would leak
    the answer and produce a model that looks accurate but is useless
    for prevention (you don't know the outcome before it happens).

OUTPUT
    models/accident_risk_model.joblib   <- trained pipeline (encoder + model)
    models/accident_risk_features.json  <- feature list + metadata for inference

Run:
    python src/train_accident_risk_model.py
"""

import os
import json

import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
)

import xgboost as xgb


# ============================================================
# PATHS
# ============================================================

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

DATA_FILE = os.path.join(
    PROJECT_ROOT, "dataset", "archive", "NCDOT_BikePedCrash.csv"
)

MODEL_DIR = os.path.join(PROJECT_ROOT, "models")
MODEL_FILE = os.path.join(MODEL_DIR, "accident_risk_model.joblib")
META_FILE = os.path.join(MODEL_DIR, "accident_risk_features.json")

RANDOM_STATE = 42
TEST_SIZE = 0.2


# ============================================================
# FEATURES
# ============================================================

# Known before/at the moment of the ride - safe to use.
CATEGORICAL_FEATURES = [
    "LightCond", "Weather", "RdConditio", "RdSurface", "RdCharacte",
    "RdClass", "RdConfig", "RdDefects", "RdFeature", "TraffCntrl",
    "Workzone", "RuralUrban", "Developmen", "Region", "Locality",
    "BikeAgeGrp", "BikeSex", "BikePos", "BikeDir", "BikeAlcFlg",
    "DrvrAgeGrp", "DrvrSex", "DrvrVehTyp", "DrvrAlcFlg", "CrashAlcoh",
    "CrashType", "CrashGrp", "CrashLoc", "CrashDay", "CrashMonth",
    "SpeedLimit", "NumLanes",
]

NUMERIC_FEATURES = [
    "CrashHour", "NumUnits",
]

ALL_FEATURES = CATEGORICAL_FEATURES + NUMERIC_FEATURES

TARGET_RAW = "CrashSevr"

# Outcome / post-crash columns that must NEVER be used as inputs
# (kept here as documentation of what was deliberately excluded).
LEAKY_COLUMNS = [
    "BikeInjury", "DrvrInjury", "NumBicsAin", "NumBicsBin", "NumBicsCin",
    "NumBicsKil", "NumBicsNoi", "NumBicsTot", "NumBicsUin",
    "AmbulanceR", "HitRun",
]


# ============================================================
# LOAD + LABEL
# ============================================================

def load_data():
    if not os.path.exists(DATA_FILE):
        raise FileNotFoundError(
            f"{DATA_FILE} not found. Expected the NCDOT_BikePedCrash.csv "
            "dataset inside dataset/archive/."
        )

    data = pd.read_csv(DATA_FILE, low_memory=False)

    # Drop rows with an unusable/unknown severity label.
    data = data[data[TARGET_RAW] != "Unknown Injury"].copy()

    high_severity_labels = {
        "A: Suspected Serious Injury",
        "K: Killed",
    }

    data["HighSeverity"] = data[TARGET_RAW].apply(
        lambda value: 1 if value in high_severity_labels else 0
    )

    return data


# ============================================================
# BUILD PREPROCESSING + MODEL PIPELINE
# ============================================================

def build_pipeline(scale_pos_weight):

    categorical_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="constant", fill_value="Unknown")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])

    numeric_transformer = Pipeline(steps=[
        ("impute", SimpleImputer(strategy="median")),
    ])

    preprocessor = ColumnTransformer(transformers=[
        ("cat", categorical_transformer, CATEGORICAL_FEATURES),
        ("num", numeric_transformer, NUMERIC_FEATURES),
    ])

    model = xgb.XGBClassifier(
        n_estimators=400,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos_weight,
        eval_metric="logloss",
        random_state=RANDOM_STATE,
    )

    pipeline = Pipeline(steps=[
        ("preprocess", preprocessor),
        ("model", model),
    ])

    return pipeline


# ============================================================
# MAIN
# ============================================================

def main():

    print("Loading data...")
    data = load_data()

    for column in ALL_FEATURES:
        if column not in data.columns:
            raise ValueError(f"Expected column missing from dataset: {column}")
        # Force everything to string for categoricals so mixed
        # int/str columns (e.g. SpeedLimit) don't break OneHotEncoder.
        if column in CATEGORICAL_FEATURES:
            data[column] = data[column].astype(str)

    X = data[ALL_FEATURES]
    y = data["HighSeverity"]

    print(f"Loaded {len(data)} usable rows.")
    print(f"High severity (fatal/serious): {y.sum()} "
          f"({100 * y.mean():.1f}%)")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    positive = (y_train == 1).sum()
    negative = (y_train == 0).sum()
    scale_pos_weight = negative / positive if positive > 0 else 1.0

    print(f"Train rows: {len(X_train)} "
          f"(high-severity: {positive}, other: {negative})")
    print(f"scale_pos_weight: {scale_pos_weight:.2f}")

    pipeline = build_pipeline(scale_pos_weight)

    print("Training...")
    pipeline.fit(X_train, y_train)

    predictions = pipeline.predict(X_test)
    probabilities = pipeline.predict_proba(X_test)[:, 1]

    print()
    print("==========================================")
    print("CLASSIFICATION REPORT")
    print("==========================================")
    print(classification_report(
        y_test, predictions, target_names=["OTHER", "HIGH_SEVERITY"]
    ))

    print("CONFUSION MATRIX (rows=actual, cols=predicted)")
    print("              OTHER  HIGH_SEVERITY")
    matrix = confusion_matrix(y_test, predictions)
    for label, row in zip(["OTHER        ", "HIGH_SEVERITY"], matrix):
        print(f"{label} {row}")

    auc = roc_auc_score(y_test, probabilities)
    print()
    print(f"ROC AUC: {auc:.3f}")

    os.makedirs(MODEL_DIR, exist_ok=True)

    joblib.dump(pipeline, MODEL_FILE)

    metadata = {
        "categorical_features": CATEGORICAL_FEATURES,
        "numeric_features": NUMERIC_FEATURES,
        "target": "HighSeverity (1 = suspected serious injury or killed)",
        "roc_auc": round(float(auc), 4),
        "n_train_rows": int(len(X_train)),
        "n_test_rows": int(len(X_test)),
    }

    with open(META_FILE, "w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)

    print()
    print(f"Model saved to {MODEL_FILE}")
    print(f"Metadata saved to {META_FILE}")


if __name__ == "__main__":
    main()
