"""
train_universal_model.py

Trains ONE crash-risk model that works on every kind of footage:
other-vehicle dashcams (CCD / Crash-1500 / Kaggle), cyclist point-of-view
clips, and helmet / GoPro clips.

WHAT IS DIFFERENT FROM train_crash_model.py
  * Features are view-independent (universal_features.py): looming, time to
    contact, sideways miss distance, pair overlap / convergence, whole-scene
    optical flow, plus a causal per-ride baseline and the last few seconds.
  * Training is balanced across sources, so the biggest dataset cannot
    dominate and the model cannot simply learn "which camera is this".
  * The headline number is the LEAVE-ONE-SOURCE-OUT score: train on three
    camera types, test on the fourth, which the model has never seen. A
    model that is truly input-independent keeps its score there.
  * Scores are reported PER SOURCE, not only pooled.
  * Event-level metrics: of the real crash clips, how many got a warning
    before the crash, how many seconds ahead, and how many false alerts per
    minute of normal riding. That is what a rider actually experiences.
  * The saved model is calibrated, so 0.75 really means "about 3 in 4".

RUN (after universal_collector.py + combine_universal_data.py):
    python src/train_universal_model.py
    python src/train_universal_model.py --quick        (fewer trees, minutes)

OUTPUT
    models/universal_crash_model.joblib       the model for live use
    dataset/universal_ablation.csv            which feature set helps, mixed + leave-one-source-out
    dataset/universal_source_metrics.csv      per-source results (both protocols)
    dataset/universal_event_metrics.csv       warning rate, lead time, false alerts / min
    dataset/universal_oof_predictions.csv     out-of-fold probability of every window
  and the same four files the R dashboard already reads, so Model Insights
  shows THIS model with no R changes:
    dataset/model_comparison_metrics.csv, cv_fold_metrics.csv,
    holdout_predictions.csv, feature_importance.csv
"""

import os
import sys
import argparse
import datetime
import warnings

import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import StratifiedGroupKFold, GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, VotingClassifier
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import roc_auc_score, average_precision_score, confusion_matrix, f1_score, roc_curve
from sklearn.inspection import permutation_importance

import xgboost as xgb

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from crash_features import FEATURE_COLUMNS
from universal_features import UNIVERSAL_BASE_COLUMNS, CONTEXT_FEATURE_COLUMNS, build_context_table

warnings.filterwarnings("ignore")

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RANDOM_STATE = 42
N_FOLDS = 5
ALERT_LOOKBACK_SECONDS = 8.0       # a warning this far before the crash counts as a success
MIN_WARNING_SECONDS = 0.2          # ...but it must come at least this long before impact


# ============================================================
# DATA
# ============================================================

def load_data(path):
    data = pd.read_csv(path)

    needed = ["video_id", "window_start_sec", "label", "source"] + UNIVERSAL_BASE_COLUMNS
    missing = [c for c in needed if c not in data.columns]
    if missing:
        raise ValueError(f"{path} is missing columns {missing}. Build it with universal_collector.py "
                         f"and combine_universal_data.py.")

    if "viewpoint" not in data.columns:
        data["viewpoint"] = data["source"]
    if "crash_time_sec" not in data.columns:
        data["crash_time_sec"] = np.nan

    for column in FEATURE_COLUMNS:
        if column not in data.columns:
            data[column] = np.nan
    data[FEATURE_COLUMNS] = data[FEATURE_COLUMNS].fillna(data[FEATURE_COLUMNS].median(numeric_only=True))

    data[UNIVERSAL_BASE_COLUMNS] = data[UNIVERSAL_BASE_COLUMNS].fillna(0.0)
    data = data.sort_values(["video_id", "window_start_sec"]).reset_index(drop=True)

    context = build_context_table(data)
    for column in context.columns:
        if column not in data.columns:
            data[column] = context[column].values

    return data


def balance_weights(frame):
    """Every (source, class) cell contributes equally, so no single camera
    type and not the majority class dominates the fit."""
    cell = frame["source"].astype(str) + "_" + frame["label"].astype(str)
    counts = cell.map(cell.value_counts())
    weights = len(frame) / (cell.nunique() * counts)
    return (weights / weights.mean()).values


# ============================================================
# MODELS
# ============================================================

def build_models(quick):
    trees = 150 if quick else 400
    boost = 150 if quick else 300

    logistic = Pipeline([("scale", StandardScaler()),
                         ("model", LogisticRegression(max_iter=3000, C=0.5, random_state=RANDOM_STATE))])

    forest = RandomForestClassifier(n_estimators=trees, max_depth=10, min_samples_leaf=4,
                                    random_state=RANDOM_STATE, n_jobs=-1)

    hist = HistGradientBoostingClassifier(max_iter=boost, max_depth=6, learning_rate=0.06,
                                          l2_regularization=1.0, random_state=RANDOM_STATE)

    boosted = xgb.XGBClassifier(n_estimators=boost, max_depth=4, learning_rate=0.05, subsample=0.8,
                                colsample_bytree=0.7, min_child_weight=3, eval_metric="logloss",
                                random_state=RANDOM_STATE, n_jobs=-1)

    vote = VotingClassifier([("rf", forest), ("hgb", hist), ("xgb", boosted)], voting="soft")

    return {
        "Logistic Regression": logistic,
        "Random Forest": forest,
        "HistGradientBoosting": hist,
        "XGBoost": boosted,
        "Voting Ensemble (RF+HGB+XGB)": vote,
    }


def fit_model(estimator, X, y, weights):
    from sklearn.base import clone
    model = clone(estimator)
    try:
        if isinstance(model, Pipeline):
            model.fit(X, y, model__sample_weight=weights)
        else:
            model.fit(X, y, sample_weight=weights)
    except TypeError:
        model.fit(X, y)
    return model


# ============================================================
# METRICS
# ============================================================

def tpr_at_fpr(y, p, max_fpr=0.10):
    fpr, tpr, _ = roc_curve(y, p)
    allowed = tpr[fpr <= max_fpr]
    return float(allowed.max()) if len(allowed) else 0.0


def safe_auc(y, p):
    return float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else float("nan")


def classification_metrics(y, p, threshold=0.5):
    predicted = (p >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, predicted, labels=[0, 1]).ravel()
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    specificity = tn / (tn + fp) if tn + fp else 0.0
    return {
        "accuracy": (tp + tn) / len(y), "precision": precision, "recall_sensitivity": recall,
        "specificity": specificity, "f1_score": (2 * precision * recall / (precision + recall)) if precision + recall else 0.0,
        "roc_auc": safe_auc(y, p),
    }


def per_source_table(frame, probs, scenario, threshold):
    rows = []
    for source, part in frame.groupby("source"):
        y, p = part["label"].values, probs[part.index]
        rows.append({
            "scenario": scenario, "source": source, "n_windows": len(part), "n_clips": part["video_id"].nunique(),
            "roc_auc": safe_auc(y, p),
            "avg_precision": float(average_precision_score(y, p)) if y.sum() else float("nan"),
            "tpr_at_10pct_fpr": tpr_at_fpr(y, p),
            "f1_at_threshold": float(f1_score(y, (p >= threshold).astype(int), zero_division=0)),
            "base_rate": float(y.mean()),
        })
    return rows


# ============================================================
# CROSS-VALIDATION PROTOCOLS
# ============================================================

def grouped_oof(estimator, frame, columns, folds=N_FOLDS):
    """Out-of-fold probability for every window; no clip is ever in both
    the training and the test side of a fold."""
    probs = np.zeros(len(frame))
    fold_of = np.zeros(len(frame), dtype=int)
    X, y, groups = frame[columns], frame["label"], frame["video_id"]
    splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=RANDOM_STATE)

    for fold, (train_idx, test_idx) in enumerate(splitter.split(X, y, groups), 1):
        weights = balance_weights(frame.iloc[train_idx].reset_index(drop=True))
        model = fit_model(estimator, X.iloc[train_idx], y.iloc[train_idx], weights)
        probs[test_idx] = model.predict_proba(X.iloc[test_idx])[:, 1]
        fold_of[test_idx] = fold

    return probs, fold_of


def leave_one_source_out(estimator, frame, columns):
    """Train on all other camera types, test on the one never seen."""
    probs = np.full(len(frame), np.nan)

    for source in sorted(frame["source"].unique()):
        test_mask = (frame["source"] == source).values
        train = frame[~test_mask].reset_index(drop=True)
        if train["label"].nunique() < 2 or test_mask.sum() == 0:
            continue
        model = fit_model(estimator, train[columns], train["label"], balance_weights(train))
        probs[test_mask] = model.predict_proba(frame.loc[test_mask, columns])[:, 1]

    return probs


def macro_auc(frame, probs):
    values = []
    for _, part in frame.groupby("source"):
        auc = safe_auc(part["label"].values, probs[part.index])
        if not np.isnan(auc):
            values.append(auc)
    return float(np.mean(values)) if values else float("nan")


# ============================================================
# EVENT-LEVEL EVALUATION
# ============================================================

def event_metrics(frame, probs, threshold, persistence):
    """What a rider experiences.

    An ALERT needs `persistence` consecutive windows at or above threshold.
    A crash clip is WARNED if an alert happens between ALERT_LOOKBACK_SECONDS
    and MIN_WARNING_SECONDS before the crash. Any other alert episode counts
    as a false alert; rates are per minute of riding.
    """
    rows = []

    for source, part in list(frame.groupby("source")) + [("ALL SOURCES", frame)]:
        crash_clips = warned = 0
        leads, false_alerts, minutes = [], 0, 0.0

        for _, clip in part.groupby("video_id"):
            clip = clip.sort_values("window_start_sec")
            p = probs[clip.index]
            above = p >= threshold
            run = 0
            alert_times, episode_starts = [], []
            for i, flag in enumerate(above):
                run = run + 1 if flag else 0
                if run >= persistence:
                    alert_end = clip["window_start_sec"].iloc[i] + 1.0
                    alert_times.append(alert_end)
                    if run == persistence:
                        episode_starts.append(alert_end)

            crash_time = clip["crash_time_sec"].dropna()
            if len(crash_time):
                crash_clips += 1
                crash = float(crash_time.iloc[0])
                good = [t for t in alert_times if crash - ALERT_LOOKBACK_SECONDS <= t <= crash - MIN_WARNING_SECONDS]
                if good:
                    warned += 1
                    leads.append(crash - min(good))
                false_alerts += sum(1 for t in episode_starts if t < crash - ALERT_LOOKBACK_SECONDS)
                minutes += max(crash - ALERT_LOOKBACK_SECONDS, 0) / 60.0
            else:
                false_alerts += len(episode_starts)
                minutes += len(clip) / 60.0

        rows.append({
            "source": source, "persistence_windows": persistence, "threshold": round(threshold, 3),
            "crash_clips": crash_clips,
            "warned_before_crash_pct": round(100 * warned / crash_clips, 1) if crash_clips else float("nan"),
            "median_warning_seconds": round(float(np.median(leads)), 2) if leads else float("nan"),
            "false_alerts_per_minute": round(false_alerts / minutes, 3) if minutes else float("nan"),
            "riding_minutes_checked": round(minutes, 1),
        })

    return rows


# ============================================================
# MAIN
# ============================================================

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=os.path.join(PROJECT_ROOT, "dataset", "training_universal.csv"))
    parser.add_argument("--dataset-dir", default=os.path.join(PROJECT_ROOT, "dataset"))
    parser.add_argument("--model-out", default=os.path.join(PROJECT_ROOT, "models", "universal_crash_model.joblib"))
    parser.add_argument("--quick", action="store_true", help="fewer trees; finishes in minutes")
    args = parser.parse_args()

    os.makedirs(args.dataset_dir, exist_ok=True)
    os.makedirs(os.path.dirname(args.model_out), exist_ok=True)

    data = load_data(args.data)
    sources = sorted(data["source"].unique())

    print(f"Loaded {len(data)} windows from {data['video_id'].nunique()} clips.")
    print(f"Camera sources: " + ", ".join(f"{s} ({(data['source'] == s).sum()} windows, "
                                          f"{100 * data.loc[data['source'] == s, 'label'].mean():.0f}% pre-crash)" for s in sources))
    if len(sources) < 2:
        print("NOTE: only one source found - leave-one-source-out needs at least two.")

    # ------------------------------------------------------------
    # STAGE 1: WHICH FEATURES? (one fast model, two protocols)
    # ------------------------------------------------------------

    feature_sets = {
        "Legacy 14 (old, view-dependent)": FEATURE_COLUMNS,
        "Universal (no context)": UNIVERSAL_BASE_COLUMNS,
        "Universal + context": CONTEXT_FEATURE_COLUMNS,
        "Legacy + universal + context": FEATURE_COLUMNS + CONTEXT_FEATURE_COLUMNS,
    }

    probe = build_models(args.quick)["HistGradientBoosting"]
    ablation = []

    print("\n=========================================================")
    print("STAGE 1 - FEATURE SETS (HistGradientBoosting probe)")
    print("=========================================================")
    print(f"{'Feature set':<34}{'Mixed AUC':>11}{'Per-source AUC':>16}{'Unseen-camera AUC':>19}")

    for name, columns in feature_sets.items():
        mixed, _ = grouped_oof(probe, data, columns)
        loso = leave_one_source_out(probe, data, columns) if len(sources) > 1 else np.full(len(data), np.nan)
        row = {
            "feature_set": name, "n_features": len(columns),
            "mixed_auc": safe_auc(data["label"].values, mixed),
            "mixed_macro_source_auc": macro_auc(data, mixed),
            "unseen_camera_macro_auc": macro_auc(data[~np.isnan(loso)], loso) if not np.all(np.isnan(loso)) else float("nan"),
        }
        ablation.append(row)
        print(f"{name:<34}{row['mixed_auc']:>11.3f}{row['mixed_macro_source_auc']:>16.3f}{row['unseen_camera_macro_auc']:>19.3f}")

    ablation_frame = pd.DataFrame(ablation)
    ablation_frame.to_csv(os.path.join(args.dataset_dir, "universal_ablation.csv"), index=False)

    usable = ablation_frame[ablation_frame["feature_set"] != "Legacy 14 (old, view-dependent)"].copy()
    ranking = usable["unseen_camera_macro_auc"].fillna(usable["mixed_macro_source_auc"])
    best_set = usable.loc[ranking.idxmax(), "feature_set"]
    columns = feature_sets[best_set]
    print(f"\nFeature set chosen (best on unseen cameras): {best_set}  ({len(columns)} features)")

    # ------------------------------------------------------------
    # STAGE 2: WHICH MODEL?
    # ------------------------------------------------------------

    print("\n=========================================================")
    print("STAGE 2 - MODEL COMPARISON ON THE CHOSEN FEATURES")
    print("=========================================================")

    models = build_models(args.quick)
    oof, fold_tables, summary_rows, fold_rows = {}, {}, [], []

    for name, estimator in models.items():
        probs, fold_of = grouped_oof(estimator, data, columns)
        oof[name] = probs
        fold_tables[name] = fold_of

        per_fold = []
        for fold in range(1, N_FOLDS + 1):
            mask = fold_of == fold
            if mask.sum() == 0:
                continue
            metrics = classification_metrics(data.loc[mask, "label"].values, probs[mask])
            per_fold.append(metrics)
            fold_rows.append({"model": name, "fold": fold, **{k: round(float(v), 4) for k, v in metrics.items()}})

        mean = {k: float(np.mean([f[k] for f in per_fold])) for k in per_fold[0]}
        summary_rows.append({"model": name, **mean, "macro_source_auc": macro_auc(data, probs)})
        print(f"{name:<32} AUC {mean['roc_auc']:.3f}  per-source AUC {macro_auc(data, probs):.3f}  "
              f"recall {mean['recall_sensitivity']:.3f}  specificity {mean['specificity']:.3f}  F1 {mean['f1_score']:.3f}")

    winner = max(summary_rows, key=lambda r: r["macro_source_auc"])["model"]
    print(f"\nBest model (highest average per-source AUC): {winner}")

    # ------------------------------------------------------------
    # STAGE 3: CALIBRATE + PICK THE ALERT THRESHOLD
    # ------------------------------------------------------------

    raw_oof = oof[winner]
    calibrator = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
    calibrator.fit(raw_oof, data["label"].values, sample_weight=balance_weights(data))
    calibrated_oof = calibrator.predict(raw_oof)

    grid = np.arange(0.20, 0.91, 0.01)
    f1_scores = [f1_score(data["label"].values, (calibrated_oof >= t).astype(int), zero_division=0) for t in grid]
    threshold = float(grid[int(np.argmax(f1_scores))])
    print(f"Alert threshold (best F1 on calibrated out-of-fold scores): {threshold:.2f}")

    # ------------------------------------------------------------
    # STAGE 4: PER-SOURCE, UNSEEN-CAMERA, AND EVENT RESULTS
    # ------------------------------------------------------------

    print("\n=========================================================")
    print("STAGE 4 - RESULTS PER CAMERA TYPE")
    print("=========================================================")

    source_rows = per_source_table(data, calibrated_oof, "Mixed training (clips held out)", threshold)

    loso_raw = leave_one_source_out(models[winner], data, columns) if len(sources) > 1 else np.full(len(data), np.nan)
    if not np.all(np.isnan(loso_raw)):
        loso_frame = data[~np.isnan(loso_raw)]
        source_rows += per_source_table(loso_frame, np.nan_to_num(loso_raw), "Unseen camera type (leave-one-source-out)", threshold)

    source_table = pd.DataFrame(source_rows)
    source_table.to_csv(os.path.join(args.dataset_dir, "universal_source_metrics.csv"), index=False)
    print(source_table.round(3).to_string(index=False))

    event_rows = []
    for k in (1, 2, 3):
        event_rows += event_metrics(data, calibrated_oof, threshold, k)
    event_table = pd.DataFrame(event_rows)
    event_table.to_csv(os.path.join(args.dataset_dir, "universal_event_metrics.csv"), index=False)

    print("\nEvent level (what a rider experiences), all sources:")
    print(event_table[event_table["source"] == "ALL SOURCES"].drop(columns=["source"]).to_string(index=False))

    pd.DataFrame({
        "video_id": data["video_id"], "source": data["source"], "viewpoint": data["viewpoint"],
        "window_start_sec": data["window_start_sec"], "label": data["label"],
        "y_prob_raw": np.round(raw_oof, 5), "y_prob": np.round(calibrated_oof, 5),
    }).to_csv(os.path.join(args.dataset_dir, "universal_oof_predictions.csv"), index=False)

    # ------------------------------------------------------------
    # STAGE 5: FINAL MODEL + FILES FOR THE R DASHBOARD
    # ------------------------------------------------------------

    final = fit_model(models[winner], data[columns], data["label"], balance_weights(data))

    artifact = {
        "estimator": final, "calibrator": calibrator, "feature_columns": columns,
        "feature_set": best_set, "threshold": threshold, "persistence": 2,
        "model_name": winner, "trained_sources": sources,
        "trained_on": datetime.datetime.now().isoformat(timespec="seconds"),
        "oof_macro_source_auc": macro_auc(data, calibrated_oof),
    }
    joblib.dump(artifact, args.model_out)
    print(f"\nSaved universal model -> {args.model_out}")

    # Files the R dashboard already knows how to read.
    comparison = pd.DataFrame(summary_rows)
    comparison["is_best"] = np.where(comparison["model"] == winner, "yes", "no")
    comparison[["model", "accuracy", "precision", "recall_sensitivity", "specificity", "f1_score", "roc_auc", "is_best"]] \
        .round(4).to_csv(os.path.join(args.dataset_dir, "model_comparison_metrics.csv"), index=False)
    pd.DataFrame(fold_rows).to_csv(os.path.join(args.dataset_dir, "cv_fold_metrics.csv"), index=False)

    splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=RANDOM_STATE)
    train_idx, test_idx = next(splitter.split(data[columns], data["label"], data["video_id"]))
    train_part = data.iloc[train_idx].reset_index(drop=True)
    test_part = data.iloc[test_idx]

    holdout_frames, fitted = [], {}
    for name, estimator in models.items():
        model = fit_model(estimator, train_part[columns], train_part["label"], balance_weights(train_part))
        fitted[name] = model
        holdout_frames.append(pd.DataFrame({
            "model": name, "video_id": test_part["video_id"].values, "y_true": test_part["label"].values,
            "y_prob": np.round(model.predict_proba(test_part[columns])[:, 1], 5),
            "is_best": "yes" if name == winner else "no",
        }))
    pd.concat(holdout_frames).to_csv(os.path.join(args.dataset_dir, "holdout_predictions.csv"), index=False)

    sample = test_part.sample(n=min(4000, len(test_part)), random_state=RANDOM_STATE)
    importance = permutation_importance(fitted[winner], sample[columns], sample["label"], scoring="roc_auc",
                                        n_repeats=3, random_state=RANDOM_STATE, n_jobs=1)
    pd.DataFrame({"feature": columns, "importance_mean": np.round(importance.importances_mean, 5),
                  "importance_std": np.round(importance.importances_std, 5)}) \
        .sort_values("importance_mean", ascending=False).head(25) \
        .to_csv(os.path.join(args.dataset_dir, "feature_importance.csv"), index=False)

    print("R dashboard files written (model_comparison_metrics, cv_fold_metrics, holdout_predictions, feature_importance).")


if __name__ == "__main__":
    main()
