"""
build_labels_kaggle.py

Builds dataset/labels_kaggle.csv for feature_collector.py from the
"archive/train" accident_XXX.mp4 / driving_XXX.mp4 clips, using the
filename + case + duration already given in train.csv - no need to
open each video file.

LABELING ASSUMPTION: same as build_labels_ccd.py - these clips don't
ship with an exact collision timestamp, so accident_* clips are
assumed to end in the crash (crash_timestamp_sec = duration - 1.0).
driving_* clips get a blank crash_timestamp_sec (no crash at all).

Usage:
    python src/build_labels_kaggle.py
    python src/build_labels_kaggle.py --train-csv path/to/train.csv
"""

import argparse
import csv
import os


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

DEFAULT_TRAIN_CSV = os.path.join(PROJECT_ROOT, "dataset", "train.csv")
OUTPUT_FILE = os.path.join(PROJECT_ROOT, "dataset", "labels_kaggle.csv")

CRASH_OFFSET_FROM_END = 1.0


def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("--train-csv", default=DEFAULT_TRAIN_CSV)
    parser.add_argument("--output", default=OUTPUT_FILE)
    args = parser.parse_args()

    if not os.path.exists(args.train_csv):
        print(f"ERROR: {args.train_csv} not found.")
        return

    rows = []

    with open(args.train_csv, newline="", encoding="utf-8") as file:
        for row in csv.DictReader(file):

            filename = row["filename"].strip()
            case = row["case"].strip().lower()
            duration = float(row["duration"])

            if case == "accident":
                crash_time = max(duration - CRASH_OFFSET_FROM_END, 0.1)
            else:
                crash_time = None

            rows.append({
                "filename": filename,
                "crash_timestamp_sec": round(crash_time, 2) if crash_time is not None else "",
            })

    os.makedirs(os.path.dirname(args.output), exist_ok=True)

    with open(args.output, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=["filename", "crash_timestamp_sec"])
        writer.writeheader()
        writer.writerows(rows)

    positive = sum(1 for row in rows if row["crash_timestamp_sec"] != "")

    print(f"Wrote {len(rows)} labeled rows to {args.output}")
    print(f"  accident (positive): {positive}")
    print(f"  driving (negative): {len(rows) - positive}")


if __name__ == "__main__":
    main()
