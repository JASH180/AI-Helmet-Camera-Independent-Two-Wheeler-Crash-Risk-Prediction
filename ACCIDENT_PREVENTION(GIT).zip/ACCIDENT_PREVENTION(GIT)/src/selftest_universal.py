"""
selftest_universal.py - SANITY CHECK on synthetic multi-camera data.

Builds fake clips from four very different "cameras" (different resolution,
field of view, fps, shake, first-person vs third-person) by pushing synthetic
detections through the REAL FrameAnalyzer / WindowAggregator, then trains the
universal pipeline on them.  It checks that the maths and the pipeline work
and that the new features beat the old ones when the camera changes.

It is NOT evidence about real-world accuracy. Real numbers come only from
train_universal_model.py on your real videos.

    python src/selftest_universal.py
"""
import os, sys, subprocess, tempfile
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from universal_features import FrameAnalyzer, WindowAggregator
from feature_collector import label_for_time

CAMERAS = {
    # name: (W, H, fps, focal-scale, shake px, view)
    "ccd":     (1280, 720, 30, 1.0, 1.5, "third"),
    "kaggle":  (1920, 1080, 25, 0.8, 3.0, "third"),
    "cyclist": (1280, 720, 30, 0.9, 6.0, "first"),
    "gopro":   (1920, 1080, 60, 0.45, 12.0, "first"),
}


def box(cx, cy, w, h):
    return (cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def make_clip(rng, cam, crash, length=14.0):
    W, H, fps, f, shake, view = CAMERAS[cam]
    an = FrameAnalyzer(yolo_model=None, use_flow=False)
    agg = WindowAggregator()
    T = rng.uniform(8, length - 2) if crash else None
    rows = []
    n = int(length * fps)
    phase = rng.uniform(0, 6)
    kind = rng.choice(["lead", "cross"])
    for i in range(n):
        t = i / fps
        sh = shake * np.sin(2 * np.pi * (0.7 * t + phase)) + rng.normal(0, shake * 0.3)
        dets, flow_div = [], 0.0
        if view == "first":
            # ego approaches an object. crash: collision at T. else: pass beside / keep gap.
            if crash:
                Z = max(30 * (1 - t / (T + 0.4)), 0.8) if t < T + 0.4 else 0.8
                X = 0.25
            else:
                Z = max(30 - 1.2 * t if kind == "lead" else 30 * (1 - t / (length + 2)), 6) if kind == "lead" else max(30 * (1 - t / (length * 0.9)), 3)
                X = 0.0 if kind == "lead" else 3.0
                if kind == "lead":
                    Z = 18 + 2 * np.sin(0.3 * t)
            size = f * 400 / Z
            cx = W / 2 + f * 900 * X / Z + sh
            dets.append({"track_id": 1, "cls": "car", "xyxy": box(cx, H * 0.55, size * 1.2, size)})
            if not crash or True:
                dets.append({"track_id": 2, "cls": "car", "xyxy": box(W * 0.2 + sh, H * 0.5, 90 * f + 20, 60 * f + 15)})
            flow_div = 0.02 + (0.03 if crash and t > T - 3 else 0.0) + rng.normal(0, 0.01)
        else:
            # fixed camera, two other vehicles. crash: they converge and meet at T.
            a0, b0 = W * 0.2, W * 0.8
            if crash:
                prog = min(t / T, 1.0)
                ax, bx = a0 + (W * 0.5 - 40 * f - a0) * prog, b0 + (W * 0.5 + 40 * f - b0) * prog
                ay = by = H * 0.6
            else:
                ax, bx = a0 + 90 * t * f / 1.0, b0 - 90 * t * f
                ay, by = H * 0.55, H * 0.7           # different lanes: pass without touching
            s = 90 * f + 20
            dets.append({"track_id": 1, "cls": "car", "xyxy": box(ax + sh, ay, s * 1.4, s)})
            dets.append({"track_id": 2, "cls": "car", "xyxy": box(bx + sh, by, s * 1.4, s)})
            flow_div = rng.normal(0, 0.01)
        flow = {"flow_dx": rng.normal(0, 0.02), "flow_dy": rng.normal(0, 0.02),
                "flow_div": flow_div, "flow_mag": abs(rng.normal(0.05, 0.02))}
        rec = an.analyze_detections(dets, W, H, t, flow)
        rec["label"] = label_for_time(t, T)
        closed = agg.add(rec)
        if closed:
            start, legacy, uni, frames = closed
            labels = [r["label"] for r in frames if r["label"] is not None]
            if labels and legacy is not None:
                row = {"window_start_sec": round(start, 2), "source": cam,
                       "viewpoint": "third" if view == "third" else "first",
                       "crash_time_sec": T if T is not None else ""}
                row.update(legacy); row.update(uni)
                row["label"] = int(any(l == 1 for l in labels))
                rows.append(row)
    return rows


def main():
    rng = np.random.default_rng(7)
    all_rows = []
    for cam in CAMERAS:
        for k in range(36):
            crash = k % 2 == 0
            for r in make_clip(rng, cam, crash):
                r["video_id"] = f"{cam}/clip{k:03d}.mp4"
                all_rows.append(r)
    df = pd.DataFrame(all_rows)
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "training_universal.csv")
    df.to_csv(path, index=False)
    print(f"Synthetic data: {len(df)} windows, {df.video_id.nunique()} clips, "
          f"{df.source.nunique()} camera types\n")
    here = os.path.dirname(os.path.abspath(__file__))
    subprocess.run([sys.executable, os.path.join(here, "train_universal_model.py"), "--data", path,
                    "--dataset-dir", tmp, "--model-out", os.path.join(tmp, "m.joblib"), "--quick"], check=True)
    print("\nOutputs in", tmp)


if __name__ == "__main__":
    main()
