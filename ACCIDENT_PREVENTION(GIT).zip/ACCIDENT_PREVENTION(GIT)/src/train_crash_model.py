"""
train_crash_model.py

Trains and COMPARES several model types for "is a crash about to
happen in the next few seconds", using the exact feature set computed
by crash_features.py (the same code external_camera.py uses live),
aggregated into 1-second windows by feature_collector.py.

WHY MULTIPLE MODELS:
    The single-XGBoost version topped out around 0.65 accuracy /
    0.73 ROC AUC. Rather than guess at one fix, this script trains
    six different candidates - a linear baseline, two tree ensembles,
    XGBoost, a neural network, and a soft-voting ensemble of the best
    tree models - and picks whichever actually scores best on
    leakage-free grouped cross-validation. This is the honest way to
    answer "would a different model help" instead of assuming.

    Realistic expectation: with 8 hand-aggregated features from noisy,
    heterogeneous dashcam/POV footage, getting solidly into the 80s is
    a good outcome; 90%+ usually needs richer features (real velocity/
    time-to-collision, more data) or a deep model trained on raw frame
    sequences rather than these hand-crafted summaries. This script
    will show you the real number for each model - it won't inflate it.

Run AFTER:
    python src/build_labels_ccd.py
    python src/build_labels_kaggle.py
    python src/build_labels_cyclist.py
    python src/feature_collector.py --videos dataset/ccd_videos --labels dataset/labels_ccd.csv --output dataset/training_data_ccd.csv
    python src/feature_collector.py --videos dataset/kaggle_videos --labels dataset/labels_kaggle.csv --output dataset/training_data_kaggle.csv
    python src/feature_collector.py --videos dataset/clips_output --labels dataset/labels_cyclist.csv --output dataset/training_data_cyclist.csv
    python src/combine_training_data.py

Then:
    python src/train_crash_model.py

Output:
    models/crash_risk_model.joblib        <- best model, generic sklearn format
    dataset/model_comparison_metrics.csv  <- full metrics for every model tried,
                                              read by r_analysis/plot_model_comparison.R
    dataset/cv_fold_metrics.csv           <- per-fold metrics (fold-to-fold spread)
    dataset/holdout_predictions.csv       <- probabilities of EVERY model on the
                                              unseen holdout clips (ROC/PR/calibration)
    dataset/feature_importance.csv        <- permutation importance of the best model
                                              (all three read by plot_prediction_diagnostics.R
                                              and the Shiny dashboard "Model Insights" tab)

NOTE ON THE SAVED FORMAT:
    Previously this saved an XGBoost-only .json file. Since the winner
    might now be any model type (Random Forest, a Pipeline, a Voting
    ensemble...), the model is saved with joblib instead, which works
    for any scikit-learn-compatible estimator. external_camera.py has
    been updated to load .joblib first and fall back to the old .json
    format automatically if you haven't retrained yet.
"""

import os
import csv
import warnings

import numpy as np
import pandas as pd
import joblib

from sklearn.model_selection import GroupShuffleSplit, StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, VotingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
)

import xgboost as xgb

from crash_features import FEATURE_COLUMNS

warnings.filterwarnings("ignore", category=UserWarning)


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

DATA_FILE = os.path.join(PROJECT_ROOT, "dataset", "training_data.csv")
MODEL_OUTPUT = os.path.join(PROJECT_ROOT, "models", "crash_risk_model.joblib")
METRICS_OUTPUT = os.path.join(PROJECT_ROOT, "dataset", "model_comparison_metrics.csv")
FOLD_METRICS_OUTPUT = os.path.join(PROJECT_ROOT, "dataset", "cv_fold_metrics.csv")
HOLDOUT_PREDICTIONS_OUTPUT = os.path.join(PROJECT_ROOT, "dataset", "holdout_predictions.csv")
FEATURE_IMPORTANCE_OUTPUT = os.path.join(PROJECT_ROOT, "dataset", "feature_importance.csv")

TEST_SIZE = 0.2
RANDOM_STATE = 42
N_CV_FOLDS = 5


# ============================================================
# MODEL CANDIDATES
# ============================================================

def build_candidates(scale_pos_weight):
    """Returns a dict of {name: estimator}. Linear/neural models get
    StandardScaler since they're sensitive to feature scale; tree
    models don't need it."""

    logistic_regression = Pipeline([
        ("scale", StandardScaler()),
        ("model", LogisticRegression(
            max_iter=2000,
            class_weight="balanced",
            random_state=RANDOM_STATE,
        )),
    ])

    random_forest = RandomForestClassifier(
        n_estimators=400,
        max_depth=8,
        min_samples_leaf=3,
        class_weight="balanced",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )

    hist_gradient_boosting = HistGradientBoostingClassifier(
        max_iter=300,
        max_depth=6,
        learning_rate=0.06,
        class_weight="balanced",
        random_state=RANDOM_STATE,
    )

    xgboost_model = xgb.XGBClassifier(
        n_estimators=300,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos_weight,
        eval_metric="logloss",
        random_state=RANDOM_STATE,
    )

    neural_net = Pipeline([
        ("scale", StandardScaler()),
        ("model", MLPClassifier(
            hidden_layer_sizes=(64, 32),
            activation="relu",
            alpha=1e-3,
            max_iter=800,
            early_stopping=True,
            random_state=RANDOM_STATE,
        )),
    ])

    # Soft-voting ensemble of the three strongest tree-based
    # candidates - averages their predicted probabilities.
    voting_ensemble = VotingClassifier(
        estimators=[
            ("random_forest", random_forest),
            ("hist_gb", hist_gradient_boosting),
            ("xgboost", xgboost_model),
        ],
        voting="soft",
    )

    return {
        "Logistic Regression": logistic_regression,
        "Random Forest": random_forest,
        "HistGradientBoosting": hist_gradient_boosting,
        "XGBoost": xgboost_model,
        "Neural Network (MLP)": neural_net,
        "Voting Ensemble (RF+HGB+XGB)": voting_ensemble,
    }


# ============================================================
# METRICS
# ============================================================

def compute_full_metrics(y_true, y_pred, y_proba):
    """Every metric the person asked for: accuracy, precision, recall
    (sensitivity), specificity, F1, ROC AUC - all for the PRE_CRASH
    (positive) class, which is the one that actually matters for a
    safety alert."""

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()

    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, pos_label=1, zero_division=0)
    recall = recall_score(y_true, y_pred, pos_label=1, zero_division=0)  # a.k.a. sensitivity
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    f1 = f1_score(y_true, y_pred, pos_label=1, zero_division=0)

    try:
        auc = roc_auc_score(y_true, y_proba)
    except ValueError:
        auc = float("nan")

    return {
        "accuracy": accuracy,
        "precision": precision,
        "recall_sensitivity": recall,
        "specificity": specificity,
        "f1_score": f1,
        "roc_auc": auc,
        "true_positive": int(tp),
        "true_negative": int(tn),
        "false_positive": int(fp),
        "false_negative": int(fn),
    }


def print_metrics(label, metrics):
    print(f"  {label}")
    print(f"    Accuracy:            {metrics['accuracy']:.3f}")
    print(f"    Precision:           {metrics['precision']:.3f}")
    print(f"    Recall (Sensitivity):{metrics['recall_sensitivity']:.3f}")
    print(f"    Specificity:         {metrics['specificity']:.3f}")
    print(f"    F1 Score:            {metrics['f1_score']:.3f}")
    print(f"    ROC AUC:             {metrics['roc_auc']:.3f}")
    print(f"    Confusion: TP={metrics['true_positive']} TN={metrics['true_negative']} "
          f"FP={metrics['false_positive']} FN={metrics['false_negative']}")


# ============================================================
# MAIN
# ============================================================

def main():

    if not os.path.exists(DATA_FILE):
        raise FileNotFoundError(f"{DATA_FILE} not found. Run combine_training_data.py first.")

    data = pd.read_csv(DATA_FILE)

    missing = [column for column in FEATURE_COLUMNS if column not in data.columns]
    if missing:
        raise ValueError(f"Missing expected columns: {missing}")

    if "video_id" not in data.columns:
        raise ValueError("training_data.csv has no video_id column - can't do a grouped split.")

    print(f"Loaded {len(data)} rows from {data['video_id'].nunique()} unique clips.")

    X = data[FEATURE_COLUMNS]
    y = data["label"]
    groups = data["video_id"]

    # ------------------------------------------------------------
    # HANDLE MISSING VALUES
    # A few models here (Logistic Regression, Random Forest, MLP)
    # can't accept NaN natively, even though XGBoost/HistGB can.
    # Rather than silently crash on whichever model hits it first,
    # report exactly where the NaNs are, then impute with the
    # column median so every candidate model can actually run.
    # ------------------------------------------------------------

    nan_counts = X.isna().sum()
    nan_counts = nan_counts[nan_counts > 0]

    if len(nan_counts) > 0:
        print("WARNING: found missing (NaN) values in these feature columns:")
        for column, count in nan_counts.items():
            print(f"  {column}: {count} rows ({100 * count / len(X):.1f}%)")
        X = X.fillna(X.median(numeric_only=True))
        print("Filled with each column's median so all models can train.\n")

    print(f"Pre-crash windows: {y.sum()}  |  Normal windows: {(y == 0).sum()}\n")

    overall_positive = (y == 1).sum()
    overall_negative = (y == 0).sum()
    scale_pos_weight = overall_negative / overall_positive if overall_positive > 0 else 1.0

    candidates = build_candidates(scale_pos_weight)

    # ------------------------------------------------------------
    # STEP 1: GROUPED 5-FOLD CV FOR EVERY CANDIDATE
    # ------------------------------------------------------------

    print("==========================================")
    print(f"{N_CV_FOLDS}-FOLD GROUPED CROSS-VALIDATION (leakage-free)")
    print("==========================================\n")

    cv = StratifiedGroupKFold(n_splits=N_CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)

    cv_summary = {}  # name -> list of per-fold metric dicts
    fold_rows = []   # one row per (model, fold) for R

    for name, estimator in candidates.items():

        print(f"--- {name} ---")
        fold_metrics = []

        for fold_index, (train_idx, test_idx) in enumerate(cv.split(X, y, groups), 1):

            X_train_cv, X_test_cv = X.iloc[train_idx], X.iloc[test_idx]
            y_train_cv, y_test_cv = y.iloc[train_idx], y.iloc[test_idx]

            model = clone_or_rebuild(estimator, candidates_builder=build_candidates,
                                      name=name, scale_pos_weight=scale_pos_weight,
                                      y_train=y_train_cv)

            model.fit(X_train_cv, y_train_cv)

            predictions = model.predict(X_test_cv)
            probabilities = model.predict_proba(X_test_cv)[:, 1]

            metrics = compute_full_metrics(y_test_cv, predictions, probabilities)
            fold_metrics.append(metrics)
            fold_rows.append({"model": name, "fold": fold_index, **{
                key: round(float(metrics[key]), 4)
                for key in ["accuracy", "precision", "recall_sensitivity", "specificity", "f1_score", "roc_auc"]
            }})

        mean_metrics = {
            key: float(np.mean([fold[key] for fold in fold_metrics]))
            for key in ["accuracy", "precision", "recall_sensitivity", "specificity", "f1_score", "roc_auc"]
        }
        std_auc = float(np.std([fold["roc_auc"] for fold in fold_metrics]))

        print_metrics("Mean across folds:", {**mean_metrics,
                                              "true_positive": sum(f["true_positive"] for f in fold_metrics),
                                              "true_negative": sum(f["true_negative"] for f in fold_metrics),
                                              "false_positive": sum(f["false_positive"] for f in fold_metrics),
                                              "false_negative": sum(f["false_negative"] for f in fold_metrics)})
        print(f"    ROC AUC std dev:      {std_auc:.3f}\n")

        cv_summary[name] = mean_metrics

    # ------------------------------------------------------------
    # STEP 2: PICK THE WINNER (highest mean CV ROC AUC)
    # ------------------------------------------------------------

    winner_name = max(cv_summary, key=lambda name: cv_summary[name]["roc_auc"])

    print("==========================================")
    print("MODEL COMPARISON SUMMARY (mean of 5 folds)")
    print("==========================================")
    header = f"{'Model':<32} {'Acc':>6} {'Prec':>6} {'Recall':>7} {'Spec':>6} {'F1':>6} {'AUC':>6}"
    print(header)
    print("-" * len(header))
    for name, metrics in sorted(cv_summary.items(), key=lambda item: -item[1]["roc_auc"]):
        marker = " <-- BEST" if name == winner_name else ""
        print(f"{name:<32} {metrics['accuracy']:.3f}  {metrics['precision']:.3f}  "
              f"{metrics['recall_sensitivity']:.3f}   {metrics['specificity']:.3f}  "
              f"{metrics['f1_score']:.3f}  {metrics['roc_auc']:.3f}{marker}")

    print(f"\nBest model by mean CV ROC AUC: {winner_name}\n")

    # ------------------------------------------------------------
    # STEP 3: FINAL HOLDOUT EVALUATION + SAVE THE WINNER
    # ------------------------------------------------------------

    print("==========================================")
    print(f"FINAL HOLDOUT EVALUATION: {winner_name}")
    print("(single grouped 80/20 split, never-before-seen clips)")
    print("==========================================")

    splitter = GroupShuffleSplit(n_splits=1, test_size=TEST_SIZE, random_state=RANDOM_STATE)
    train_idx, test_idx = next(splitter.split(X, y, groups))

    X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
    y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

    # Fit EVERY candidate on the same holdout split, so R can overlay
    # all six ROC / precision-recall curves, not just the winner's.
    holdout_frames = []
    fitted_models = {}

    for name, estimator in candidates.items():
        fitted = clone_or_rebuild(estimator, candidates_builder=build_candidates,
                                   name=name, scale_pos_weight=scale_pos_weight,
                                   y_train=y_train)
        fitted.fit(X_train, y_train)
        fitted_models[name] = fitted

        holdout_frames.append(pd.DataFrame({
            "model": name,
            "video_id": groups.iloc[test_idx].values,
            "y_true": y_test.values,
            "y_prob": np.round(fitted.predict_proba(X_test)[:, 1], 5),
            "is_best": "yes" if name == winner_name else "no",
        }))

    final_model = fitted_models[winner_name]

    predictions = final_model.predict(X_test)
    probabilities = final_model.predict_proba(X_test)[:, 1]

    holdout_metrics = compute_full_metrics(y_test, predictions, probabilities)
    print_metrics("Holdout metrics:", holdout_metrics)

    print("\nFull classification report:")
    print(classification_report(y_test, predictions, target_names=["NORMAL", "PRE_CRASH"]))

    pd.concat(holdout_frames).to_csv(HOLDOUT_PREDICTIONS_OUTPUT, index=False)
    pd.DataFrame(fold_rows).to_csv(FOLD_METRICS_OUTPUT, index=False)
    print(f"Holdout predictions saved to {HOLDOUT_PREDICTIONS_OUTPUT}")
    print(f"Per-fold metrics saved to {FOLD_METRICS_OUTPUT}")

    # Permutation importance: how much does ROC AUC drop on the unseen
    # holdout when one feature is shuffled? Works for any model type.
    from sklearn.inspection import permutation_importance
    importance = permutation_importance(
        final_model, X_test, y_test, scoring="roc_auc",
        n_repeats=5, random_state=RANDOM_STATE, n_jobs=1,
    )
    pd.DataFrame({
        "feature": FEATURE_COLUMNS,
        "importance_mean": np.round(importance.importances_mean, 5),
        "importance_std": np.round(importance.importances_std, 5),
    }).sort_values("importance_mean", ascending=False).to_csv(FEATURE_IMPORTANCE_OUTPUT, index=False)
    print(f"Feature importance saved to {FEATURE_IMPORTANCE_OUTPUT}")

    os.makedirs(os.path.dirname(MODEL_OUTPUT), exist_ok=True)
    joblib.dump(final_model, MODEL_OUTPUT)
    print(f"Best model ({winner_name}) saved to {MODEL_OUTPUT}")

    # ------------------------------------------------------------
    # STEP 4: EXPORT COMPARISON TABLE FOR R
    # ------------------------------------------------------------

    with open(METRICS_OUTPUT, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([
            "model", "accuracy", "precision", "recall_sensitivity",
            "specificity", "f1_score", "roc_auc", "is_best",
        ])
        for name, metrics in cv_summary.items():
            writer.writerow([
                name,
                round(metrics["accuracy"], 4),
                round(metrics["precision"], 4),
                round(metrics["recall_sensitivity"], 4),
                round(metrics["specificity"], 4),
                round(metrics["f1_score"], 4),
                round(metrics["roc_auc"], 4),
                "yes" if name == winner_name else "no",
            ])

    print(f"Model comparison table saved to {METRICS_OUTPUT}")
    print("(Now run r_analysis/run_all_plots.R in RStudio to regenerate every chart.)")


def clone_or_rebuild(estimator, candidates_builder, name, scale_pos_weight, y_train):
    """Cross-validation needs a FRESH, unfitted copy of the model for
    every fold (reusing a fitted one would leak information across
    folds). sklearn's clone() handles this for everything except
    XGBoost's scale_pos_weight, which should reflect THIS fold's
    class balance, not the overall one - so for XGBoost/the ensemble
    (which contains XGBoost), rebuild from scratch with the fold's
    own scale_pos_weight instead of cloning."""

    from sklearn.base import clone

    if name in ("XGBoost", "Voting Ensemble (RF+HGB+XGB)"):
        fold_positive = (y_train == 1).sum()
        fold_negative = (y_train == 0).sum()
        fold_scale_pos_weight = fold_negative / fold_positive if fold_positive > 0 else 1.0
        fresh_candidates = candidates_builder(fold_scale_pos_weight)
        return fresh_candidates[name]

    return clone(estimator)


if __name__ == "__main__":
    main()
