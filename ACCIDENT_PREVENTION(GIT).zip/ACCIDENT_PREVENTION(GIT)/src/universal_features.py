"""
universal_features.py

View-independent crash-risk features.

THE PROBLEM WITH THE OLD FEATURES
    crash_features.py scores a frame from the object's box size as a share
    of the frame (area_ratio < 0.05, < 0.12, < 0.25 ...) and from how close
    its centre is to the middle of the picture. Those thresholds silently
    assume a forward-facing dashcam with one particular field of view. A
    GoPro (wide lens, shaky), a cyclist's phone, or a bystander dashcam
    watching OTHER cars crash all break that assumption, so a model trained
    on the old numbers does not transfer between camera types.

WHAT THIS MODULE USES INSTEAD  (all independent of lens, resolution, fps,
mounting height and whether the camera is "in" the crash or watching it)

  1. LOOMING  e = d ln(size) / dt   (1/s)
        How fast an object's image is expanding, measured per SECOND (not per
        frame) and relative to its own size. Dividing by the object's own size
        removes distance, field of view and resolution.
  2. TIME TO CONTACT  tau = 1 / e   (s)
        The classic result from vision science: tau is the time until an
        approaching object reaches the camera, and it can be read straight
        from the image with no knowledge of distance or speed.
  3. MISS DISTANCE IN OBJECT WIDTHS
        How far to the side the object will pass, measured in its own widths,
        taken from its sideways drift divided by its expansion. A near-zero
        value together with a large expansion is the "constant bearing,
        decreasing range" signature of a collision course. The sideways drift
        is corrected for camera shake / panning using optical flow.
  4. PAIR FEATURES  (overlap and convergence between two OTHER objects)
        Many dashcam crashes are between two other vehicles. Their boxes
        overlap and converge, which the camera-centric features above would
        miss. These work equally for a camera that is part of the crash.
  5. WHOLE-SCENE FLOW  (divergence, magnitude, shake)
        Dense optical flow on a small copy of each frame: how fast the scene
        is rushing toward the camera, and how violent the camera motion is.
        Covers hard braking, a fall, an impact jolt.

  Then ContextBuilder adds a CAUSAL per-clip baseline ("how unusual is this
  second compared with the previous minute of the SAME ride") and the last
  few seconds of history. Both are computed from past windows only, so
  training and live use produce identical numbers.

Everything here is plain numpy / OpenCV. Detection comes from YOLO, but the
maths works on a list of detections, so it can be unit-tested without a GPU
or a video (see selftest_universal.py).
"""

from collections import deque, Counter
import math

import numpy as np

# ============================================================
# CONSTANTS
# ============================================================

WINDOW_SECONDS = 1.0

LOOM_LAG_SECONDS = 0.25      # compare an object's size now with ~0.25 s ago
LOOM_LAG_MIN = 0.12
LOOM_LAG_MAX = 0.80

TRACK_HISTORY_SECONDS = 1.6
TRACK_STALE_SECONDS = 1.0

TAU_CAP = 30.0               # "no approach" value for time-to-contact
MISS_CAP = 10.0              # "will pass far to the side" value
EXPANSION_FOR_MISS = 0.10    # miss distance only meaningful if clearly closing

VULNERABLE = {"person", "bicycle", "motorcycle"}
ROAD_OBJECTS = {"car", "motorcycle", "bus", "truck", "bicycle", "person"}

FLOW_WIDTH = 160             # optical flow is computed on a 160-px-wide copy


# ============================================================
# SMALL MATHS HELPERS
# ============================================================

def _slope(times, values):
    """Least-squares slope of values against time (units: value per second)."""
    n = len(values)
    if n < 2:
        return 0.0
    t = np.asarray(times, dtype=float)
    v = np.asarray(values, dtype=float)
    t = t - t.mean()
    denom = float((t * t).sum())
    if denom <= 1e-9:
        return 0.0
    return float((t * (v - v.mean())).sum() / denom)


def _iou(a, b):
    ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
    ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


# ============================================================
# OPTICAL FLOW (whole-scene motion)
# ============================================================

class FlowEstimator:
    """Dense Farneback optical flow on a small grey copy of each frame.

    Returns, per frame and PER SECOND, in units of image widths:
        flow_dx, flow_dy : global translation (camera pan / shake)
        flow_div         : divergence (how fast the scene is expanding
                           from the centre = forward speed / depth)
        flow_mag         : residual motion after removing the translation
    """

    def __init__(self):
        self.prev_gray = None
        self.prev_t = None

    def reset(self):
        self.prev_gray = None
        self.prev_t = None

    def step(self, frame, t):
        import cv2

        h, w = frame.shape[:2]
        small_w = FLOW_WIDTH
        small_h = max(8, int(round(h * small_w / w)))
        gray = cv2.cvtColor(cv2.resize(frame, (small_w, small_h)), cv2.COLOR_BGR2GRAY)

        zero = {"flow_dx": 0.0, "flow_dy": 0.0, "flow_div": 0.0, "flow_mag": 0.0}

        if self.prev_gray is None or self.prev_gray.shape != gray.shape:
            self.prev_gray, self.prev_t = gray, t
            return zero

        dt = t - self.prev_t
        if dt <= 1e-3:
            return zero

        flow = cv2.calcOpticalFlowFarneback(self.prev_gray, gray, None, 0.5, 2, 9, 2, 5, 1.1, 0)
        self.prev_gray, self.prev_t = gray, t

        u, v = flow[..., 0], flow[..., 1]
        dx, dy = float(np.median(u)), float(np.median(v))
        u2, v2 = u - dx, v - dy

        ys, xs = np.mgrid[0:small_h, 0:small_w]
        rx, ry = xs - (small_w - 1) / 2.0, ys - (small_h - 1) / 2.0
        r2 = rx * rx + ry * ry
        mask = r2 > (0.15 * small_w) ** 2

        divergence = float(np.median(((u2 * rx + v2 * ry)[mask]) / r2[mask])) if mask.any() else 0.0
        magnitude = float(np.median(np.sqrt(u2 * u2 + v2 * v2)))

        return {
            "flow_dx": dx / small_w / dt,
            "flow_dy": dy / small_w / dt,
            "flow_div": divergence / dt,
            "flow_mag": magnitude / small_w / dt,
        }


# ============================================================
# PER-FRAME ANALYSIS
# ============================================================

class FrameAnalyzer:
    """Turns one frame (or one list of detections) into a record of
    view-independent signals PLUS the old legacy risk fields, so both feature
    families can be produced from the same single pass over the video.

    A detection is a dict:
        {"track_id": int (-1 if untracked), "cls": "car", "xyxy": (x1,y1,x2,y2)}
    """

    def __init__(self, yolo_model=None, use_flow=True, confidence=0.45):
        self.yolo = yolo_model
        self.confidence = confidence
        self.flow = FlowEstimator() if use_flow else None
        self.reset()

    def reset(self):
        self.tracks = {}            # id -> deque of (t, cx, cy, w, h)
        self.pair_prev = {}         # (id,id) -> (t, iou, dist_rel)
        self.pan_log = deque()      # (t, cumulative pan in image widths)
        self.pan_total = 0.0
        self.last_t = None
        self.legacy_sizes = {}
        if self.flow is not None:
            self.flow.reset()

    # ---------- detection ----------

    def detections_from_yolo(self, frame):
        result = self.yolo.track(frame, persist=True, conf=self.confidence, verbose=False)[0]
        detections = []
        if result.boxes is not None:
            for box in result.boxes:
                name = self.yolo.names[int(box.cls[0])]
                if name not in ROAD_OBJECTS:
                    continue
                track_id = int(box.id[0]) if box.id is not None else -1
                x1, y1, x2, y2 = [float(v) for v in box.xyxy[0]]
                detections.append({"track_id": track_id, "cls": name, "xyxy": (x1, y1, x2, y2)})
        return detections

    def analyze(self, frame, t):
        flow = self.flow.step(frame, t) if self.flow is not None else None
        detections = self.detections_from_yolo(frame)
        height, width = frame.shape[:2]
        return self.analyze_detections(detections, width, height, t, flow)

    # ---------- the maths ----------

    def _pan_between(self, t_from, t_to):
        """Camera pan (in image widths) accumulated between two times."""
        if not self.pan_log:
            return 0.0

        def at(t):
            best = self.pan_log[0][1]
            for ts, value in self.pan_log:
                if ts <= t:
                    best = value
                else:
                    break
            return best

        return at(t_to) - at(t_from)

    def analyze_detections(self, detections, width, height, t, flow=None):

        flow = flow or {"flow_dx": 0.0, "flow_dy": 0.0, "flow_div": 0.0, "flow_mag": 0.0}

        dt_frame = (t - self.last_t) if self.last_t is not None else 0.0
        self.last_t = t
        if dt_frame > 0:
            self.pan_total += flow["flow_dx"] * dt_frame
        self.pan_log.append((t, self.pan_total))
        while self.pan_log and t - self.pan_log[0][0] > TRACK_HISTORY_SECONDS + 0.5:
            self.pan_log.popleft()

        eps_values, tau_values, miss_values, threat_values, track_exp_values = [], [], [], [], []
        seen_ids = set()

        # ---------- per-object looming ----------
        for det in detections:
            x1, y1, x2, y2 = det["xyxy"]
            w, h = max(x2 - x1, 1.0), max(y2 - y1, 1.0)
            cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
            tid = det["track_id"]
            if tid == -1:
                continue

            seen_ids.add(tid)
            history = self.tracks.setdefault(tid, deque())
            history.append((t, cx, cy, w, h))
            while history and t - history[0][0] > TRACK_HISTORY_SECONDS:
                history.popleft()

            reference = None
            best_gap = 1e9
            for sample in history:
                dt = t - sample[0]
                if LOOM_LAG_MIN <= dt <= LOOM_LAG_MAX:
                    gap = abs(dt - LOOM_LAG_SECONDS)
                    if gap < best_gap:
                        best_gap, reference = gap, sample
            if reference is None:
                continue

            ref_t, ref_cx, _, ref_w, ref_h = reference
            dt = t - ref_t
            s_now, s_ref = math.sqrt(w * h), math.sqrt(ref_w * ref_h)

            eps = float(np.clip(math.log(s_now / s_ref) / dt, -3.0, 6.0))

            pan_pixels = self._pan_between(ref_t, t) * width
            lateral = ((cx - ref_cx) - pan_pixels) / dt / s_now          # object-widths per second

            tau = float(np.clip(1.0 / eps, 0.1, TAU_CAP)) if eps > 0.05 else TAU_CAP
            miss = min(abs(lateral) / eps, MISS_CAP) if eps > EXPANSION_FOR_MISS else MISS_CAP
            threat = max(eps, 0.0) * math.exp(-((miss / 1.5) ** 2))

            first = history[0]
            age = t - first[0]
            track_exp = math.log(s_now / math.sqrt(first[3] * first[4])) if age >= 0.5 else 0.0

            eps_values.append(eps)
            tau_values.append(tau)
            miss_values.append(miss)
            threat_values.append(threat)
            track_exp_values.append(float(np.clip(track_exp, -3.0, 6.0)))

        for tid in [k for k, hist in self.tracks.items() if t - hist[-1][0] > TRACK_STALE_SECONDS]:
            del self.tracks[tid]

        # ---------- pairs of objects ----------
        iou_max, iou_rate_max, dist_min, close_rate_max = 0.0, 0.0, MISS_CAP * 2, 0.0
        largest = sorted(detections, key=lambda d: -((d["xyxy"][2] - d["xyxy"][0]) * (d["xyxy"][3] - d["xyxy"][1])))[:12]
        new_pairs = {}

        for i in range(len(largest)):
            for j in range(i + 1, len(largest)):
                a, b = largest[i], largest[j]
                ba, bb = a["xyxy"], b["xyxy"]
                iou = _iou(ba, bb)
                size_a = math.sqrt(max((ba[2] - ba[0]) * (ba[3] - ba[1]), 1.0))
                size_b = math.sqrt(max((bb[2] - bb[0]) * (bb[3] - bb[1]), 1.0))
                dist_rel = math.hypot((ba[0] + ba[2]) / 2 - (bb[0] + bb[2]) / 2,
                                      (ba[1] + ba[3]) / 2 - (bb[1] + bb[3]) / 2) / ((size_a + size_b) / 2)

                iou_max = max(iou_max, iou)
                dist_min = min(dist_min, dist_rel)

                if a["track_id"] != -1 and b["track_id"] != -1:
                    key = (min(a["track_id"], b["track_id"]), max(a["track_id"], b["track_id"]))
                    new_pairs[key] = (t, iou, dist_rel)
                    previous = self.pair_prev.get(key)
                    if previous is not None and 0.05 <= t - previous[0] <= 0.8:
                        span = t - previous[0]
                        iou_rate_max = max(iou_rate_max, (iou - previous[1]) / span)
                        close_rate_max = max(close_rate_max, (previous[2] - dist_rel) / span)

        self.pair_prev = {k: v for k, v in {**self.pair_prev, **new_pairs}.items() if t - v[0] <= 1.0}

        # ---------- legacy fields (old crash_features.py logic, unchanged) ----------
        legacy = self._legacy_frame(detections, width, height)

        return {
            "t": t,
            "eps_max": max(eps_values) if eps_values else 0.0,
            "tau_min": min(tau_values) if tau_values else TAU_CAP,
            "miss_min": min(miss_values) if miss_values else MISS_CAP,
            "threat_max": max(threat_values) if threat_values else 0.0,
            "track_exp_max": max(track_exp_values) if track_exp_values else 0.0,
            "n_obj": len(detections),
            "n_vuln": sum(1 for d in detections if d["cls"] in VULNERABLE),
            "iou_max": iou_max,
            "iou_rate_max": iou_rate_max,
            "dist_rel_min": min(dist_min, MISS_CAP * 2),
            "close_rate_max": close_rate_max,
            "flow_dx": flow["flow_dx"], "flow_dy": flow["flow_dy"],
            "flow_div": flow["flow_div"], "flow_mag": flow["flow_mag"],
            **legacy,
        }

    def _legacy_frame(self, detections, width, height):
        from road_risk import calculate_vehicle_risk, is_road_vehicle

        highest_risk, highest_status, count, max_growth = 0, "SAFE", 0, 0.0

        for det in detections:
            if not is_road_vehicle(det["cls"]):
                continue
            count += 1
            x1, y1, x2, y2 = [int(v) for v in det["xyxy"]]
            area = (x2 - x1) * (y2 - y1)
            tid = det["track_id"]
            growth = 0.0
            if tid != -1:
                previous = self.legacy_sizes.get(tid)
                if previous is not None and previous > 0:
                    growth = (area - previous) / previous
                self.legacy_sizes[tid] = area
            risk, status = calculate_vehicle_risk(x1, y1, x2, y2, width, height, growth)
            if risk > highest_risk:
                highest_risk, highest_status = risk, status
            max_growth = max(max_growth, growth)

        return {"risk_score": highest_risk, "risk_status": highest_status,
                "object_count": count, "growth_ratio": max_growth}


# ============================================================
# WINDOW SUMMARY  (frames -> one row of universal features)
# ============================================================

UNIVERSAL_BASE_COLUMNS = [
    "u_exp_max", "u_exp_mean", "u_exp_p90", "u_exp_trend",
    "u_tau_min", "u_miss_min", "u_threat_max", "u_threat_mean", "u_threat_trend",
    "u_track_exp_max",
    "u_iou_max", "u_iou_rate_max", "u_dist_rel_min", "u_close_rate_max",
    "u_n_obj_max", "u_n_obj_mean", "u_n_obj_trend", "u_n_vuln_max", "u_visible_frac",
    "u_flow_div_mean", "u_flow_div_max", "u_flow_div_trend", "u_flow_mag_mean",
    "u_flow_pan_std", "u_flow_tilt_std",
]


def summarize_universal(records):
    if not records:
        return None

    t = [r["t"] for r in records]
    exp = [r["eps_max"] for r in records]
    threat = [r["threat_max"] for r in records]
    n_obj = [r["n_obj"] for r in records]
    div = [r["flow_div"] for r in records]

    return {
        "u_exp_max": round(max(exp), 4),
        "u_exp_mean": round(float(np.mean(exp)), 4),
        "u_exp_p90": round(float(np.percentile(exp, 90)), 4),
        "u_exp_trend": round(_slope(t, exp), 4),
        "u_tau_min": round(min(r["tau_min"] for r in records), 3),
        "u_miss_min": round(min(r["miss_min"] for r in records), 3),
        "u_threat_max": round(max(threat), 4),
        "u_threat_mean": round(float(np.mean(threat)), 4),
        "u_threat_trend": round(_slope(t, threat), 4),
        "u_track_exp_max": round(max(r["track_exp_max"] for r in records), 4),
        "u_iou_max": round(max(r["iou_max"] for r in records), 4),
        "u_iou_rate_max": round(max(r["iou_rate_max"] for r in records), 4),
        "u_dist_rel_min": round(min(r["dist_rel_min"] for r in records), 3),
        "u_close_rate_max": round(max(r["close_rate_max"] for r in records), 4),
        "u_n_obj_max": max(n_obj),
        "u_n_obj_mean": round(float(np.mean(n_obj)), 3),
        "u_n_obj_trend": round(_slope(t, n_obj), 4),
        "u_n_vuln_max": max(r["n_vuln"] for r in records),
        "u_visible_frac": round(sum(1 for n in n_obj if n > 0) / len(n_obj), 3),
        "u_flow_div_mean": round(float(np.mean(div)), 4),
        "u_flow_div_max": round(max(div), 4),
        "u_flow_div_trend": round(_slope(t, div), 4),
        "u_flow_mag_mean": round(float(np.mean([r["flow_mag"] for r in records])), 4),
        "u_flow_pan_std": round(float(np.std([r["flow_dx"] for r in records])), 4),
        "u_flow_tilt_std": round(float(np.std([r["flow_dy"] for r in records])), 4),
    }


def summarize_legacy(records):
    """The original 14 features, via the unchanged crash_features.summarize_window."""
    from crash_features import summarize_window

    return summarize_window([
        {"risk_score": r["risk_score"], "risk_status": r["risk_status"],
         "object_count": r["object_count"], "growth_ratio": r["growth_ratio"]}
        for r in records
    ])


class WindowAggregator:
    """Collects frame records and emits one (legacy_row, universal_row)
    every WINDOW_SECONDS of video time."""

    def __init__(self, window_seconds=WINDOW_SECONDS):
        self.window_seconds = window_seconds
        self.records = []
        self.start = None

    def reset(self):
        self.records, self.start = [], None

    def add(self, record):
        """Returns (window_start, legacy, universal, frames) when a window closes."""
        if self.start is None:
            self.start = record["t"]
        self.records.append(record)

        if record["t"] - self.start >= self.window_seconds:
            window_start, frames = self.start, self.records
            self.records, self.start = [], None
            return window_start, summarize_legacy(frames), summarize_universal(frames), frames
        return None


# ============================================================
# CAUSAL CONTEXT  (per-ride baseline + recent history)
# ============================================================

# Columns that get a baseline-relative value and a short history.
CONTEXT_COLUMNS = [
    "u_exp_max", "u_exp_trend", "u_threat_max", "u_track_exp_max",
    "u_iou_rate_max", "u_close_rate_max", "u_flow_div_mean", "u_flow_mag_mean",
]

# Smallest meaningful change for each column - stops the baseline-relative
# value exploding on a very calm ride where the spread is almost zero.
RELATIVE_FLOOR = {
    "u_exp_max": 0.15, "u_exp_trend": 0.3, "u_threat_max": 0.10, "u_track_exp_max": 0.15,
    "u_iou_rate_max": 0.10, "u_close_rate_max": 0.15, "u_flow_div_mean": 0.05, "u_flow_mag_mean": 0.03,
}

BASELINE_WINDOWS = 60
MIN_BASELINE_WINDOWS = 3

CONTEXT_FEATURE_COLUMNS = (
    list(UNIVERSAL_BASE_COLUMNS)
    + [f"{c}_rel" for c in CONTEXT_COLUMNS]
    + [f"{c}_lag1" for c in CONTEXT_COLUMNS]
    + [f"{c}_lag2" for c in CONTEXT_COLUMNS]
    + [f"{c}_max3" for c in CONTEXT_COLUMNS]
    + [f"{c}_delta1" for c in CONTEXT_COLUMNS]
)


class ContextBuilder:
    """Stateful and CAUSAL: each call sees only the current window and the
    windows before it. The same class is used to build the training table
    (one ContextBuilder per video, windows in time order) and live (one
    instance for the whole ride), so the numbers match exactly.

      <col>_rel    (value - running median of the previous minute)
                   / (running spread + floor)   -> "how unusual for THIS ride"
      <col>_lag1/2 value 1 and 2 windows ago
      <col>_max3   max over the last 3 windows including this one
      <col>_delta1 value minus value one window ago
    """

    def __init__(self):
        self.history = deque(maxlen=BASELINE_WINDOWS)

    def reset(self):
        self.history.clear()

    def update(self, base_row):
        out = dict(base_row)
        past = list(self.history)

        for column in CONTEXT_COLUMNS:
            value = base_row[column]

            if len(past) >= MIN_BASELINE_WINDOWS:
                series = np.array([p[column] for p in past], dtype=float)
                median = float(np.median(series))
                spread = float(np.percentile(series, 75) - np.percentile(series, 25))
                out[f"{column}_rel"] = round((value - median) / (spread + RELATIVE_FLOOR[column]), 4)
            else:
                out[f"{column}_rel"] = 0.0

            lag1 = past[-1][column] if len(past) >= 1 else value
            lag2 = past[-2][column] if len(past) >= 2 else lag1
            out[f"{column}_lag1"] = lag1
            out[f"{column}_lag2"] = lag2
            out[f"{column}_max3"] = max(value, lag1, lag2)
            out[f"{column}_delta1"] = round(value - lag1, 4)

        self.history.append({c: base_row[c] for c in CONTEXT_COLUMNS})
        return out


def build_context_table(frame, video_col="video_id", time_col="window_start_sec"):
    """Applies ContextBuilder to a whole training table, one video at a time."""
    import pandas as pd

    pieces = []
    for _, group in frame.sort_values([video_col, time_col]).groupby(video_col, sort=False):
        builder = ContextBuilder()
        rows = [builder.update({c: row[c] for c in UNIVERSAL_BASE_COLUMNS})
                for row in group[UNIVERSAL_BASE_COLUMNS].to_dict("records")]
        context = pd.DataFrame(rows, index=group.index)[CONTEXT_FEATURE_COLUMNS]
        pieces.append(context)

    context_frame = pd.concat(pieces).loc[frame.index]
    return context_frame
