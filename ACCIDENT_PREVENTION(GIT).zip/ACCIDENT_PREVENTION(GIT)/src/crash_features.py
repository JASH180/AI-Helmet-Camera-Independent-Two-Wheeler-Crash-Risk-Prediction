"""
crash_features.py

The ONE place that defines "what a crash looks like in the numbers."

Both the training pipeline (feature_collector.py, run on Crash-1500 /
Normal / Kaggle accident clips) and the live system (external_camera.py,
run on your actual road camera) import extract_frame_features() and
summarize_window() from here. That is deliberate: the model must be
trained on exactly the same numbers it will see live, or accuracy on
your real camera won't match the numbers you saw during training.

This is the same per-frame risk logic external_camera.py already used
(YOLO detection -> is_road_vehicle -> calculate_vehicle_risk), just
pulled out so it isn't duplicated in two files anymore.
"""

from collections import Counter

from road_risk import calculate_vehicle_risk, is_road_vehicle


CONFIDENCE = 0.45


# ============================================================
# PER-FRAME FEATURE EXTRACTION
# ============================================================

def extract_frame_features(model, frame, previous_sizes):

    height, width, _ = frame.shape

    results = model.track(
        frame,
        persist=True,
        conf=CONFIDENCE,
        verbose=False
    )

    result = results[0]

    highest_risk = 0
    highest_status = "SAFE"
    object_count = 0
    max_growth_ratio = 0.0

    if result.boxes is not None:

        for box in result.boxes:

            class_id = int(box.cls[0])
            class_name = model.names[class_id]

            if not is_road_vehicle(class_name):
                continue

            object_count += 1

            if box.id is not None:
                track_id = int(box.id[0])
            else:
                track_id = -1

            x1, y1, x2, y2 = map(int, box.xyxy[0])

            object_width = x2 - x1
            object_height = y2 - y1
            current_area = object_width * object_height

            growth_ratio = 0.0

            if track_id != -1:

                previous_area = previous_sizes.get(track_id)

                if previous_area is not None and previous_area > 0:
                    growth_ratio = (
                        (current_area - previous_area) / previous_area
                    )

                previous_sizes[track_id] = current_area

            risk, risk_status = calculate_vehicle_risk(
                x1, y1, x2, y2,
                width, height,
                growth_ratio
            )

            if risk > highest_risk:
                highest_risk = risk
                highest_status = risk_status

            max_growth_ratio = max(max_growth_ratio, growth_ratio)

    return {
        "risk_score": highest_risk,
        "risk_status": highest_status,
        "object_count": object_count,
        "growth_ratio": max_growth_ratio
    }


# ============================================================
# SUMMARIZE A ROLLING WINDOW OF FRAMES INTO ONE FEATURE ROW
# This exact shape is what crash_risk_model.joblib was trained on -
# don't change the key names/order without retraining.
# ============================================================

def _linear_trend(values):
    """Slope of values against frame position (simple least squares,
    no numpy needed - windows are small, ~10-90 frames). Positive =
    rising over the window (e.g. risk building up), negative = falling.
    Returns 0.0 for a single-frame window (slope undefined)."""

    n = len(values)

    if n < 2:
        return 0.0

    mean_x = (n - 1) / 2.0
    mean_y = sum(values) / n

    numerator = sum((i - mean_x) * (values[i] - mean_y) for i in range(n))
    denominator = sum((i - mean_x) ** 2 for i in range(n))

    if denominator == 0:
        return 0.0

    return numerator / denominator


def _percentile(values, pct):
    """Simple percentile without numpy - good enough for small windows."""

    if not values:
        return 0.0

    sorted_values = sorted(values)
    index = (pct / 100.0) * (len(sorted_values) - 1)
    lower = int(index)
    upper = min(lower + 1, len(sorted_values) - 1)
    fraction = index - lower

    return sorted_values[lower] + (sorted_values[upper] - sorted_values[lower]) * fraction


def summarize_window(window_frames):

    if not window_frames:
        return None

    risk_scores = [f["risk_score"] for f in window_frames]
    growth_ratios = [f["growth_ratio"] for f in window_frames]
    object_counts = [f["object_count"] for f in window_frames]
    statuses = [f["risk_status"] for f in window_frames]

    status_counts = Counter(statuses)

    n = len(risk_scores)
    mean_risk = sum(risk_scores) / n

    # Volatility: how much risk swings within the window (a jittery,
    # rapidly-changing scene reads differently than a steadily rising one).
    risk_variance = sum((r - mean_risk) ** 2 for r in risk_scores) / n
    risk_std = risk_variance ** 0.5

    # Fastest observed closing rate in this window, turned into a crude
    # "seconds until the object fills the frame" estimate. Capped at 99
    # to represent "not closing in / no meaningful estimate" rather than
    # an unbounded or divide-by-zero value.
    fastest_growth = max(growth_ratios)
    time_to_collision_estimate = round(1.0 / fastest_growth, 2) if fastest_growth > 0.02 else 99.0

    return {
        "mean_risk_score": round(mean_risk, 2),
        "max_risk_score": max(risk_scores),
        "max_growth_ratio": round(max(growth_ratios), 3),
        "mean_growth_ratio": round(sum(growth_ratios) / n, 3),
        "max_object_count": max(object_counts),
        "mean_object_count": round(sum(object_counts) / n, 2),
        "high_risk_frame_count": status_counts.get("HIGH", 0),
        "critical_risk_frame_count": status_counts.get("CRITICAL", 0),

        # Newer, richer features - capture the SHAPE of the window,
        # not just its average/peak.
        "risk_score_trend": round(_linear_trend(risk_scores), 3),
        "risk_score_std": round(risk_std, 2),
        "risk_score_p90": round(_percentile(risk_scores, 90), 2),
        "growth_ratio_trend": round(_linear_trend(growth_ratios), 4),
        "object_count_trend": round(_linear_trend(object_counts), 3),
        "time_to_collision_estimate": time_to_collision_estimate,
    }


# The exact feature column order the model is trained/predicted on.
FEATURE_COLUMNS = [
    "mean_risk_score",
    "max_risk_score",
    "max_growth_ratio",
    "mean_growth_ratio",
    "max_object_count",
    "mean_object_count",
    "high_risk_frame_count",
    "critical_risk_frame_count",
    "risk_score_trend",
    "risk_score_std",
    "risk_score_p90",
    "growth_ratio_trend",
    "object_count_trend",
    "time_to_collision_estimate",
]
