import os
import csv
import glob

import cv2


# ============================================================
# PATHS - matches your dataset/ layout
# ============================================================

PROJECT_ROOT = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..")
)

VIDEOS_FOLDER = os.path.join(PROJECT_ROOT, "dataset", "raw_videos")

LABELS_FILE = os.path.join(PROJECT_ROOT, "dataset", "labels.csv")


# ============================================================
# CONTROLS
# ============================================================
#
#   SPACE       play / pause
#   .  (period) step forward one frame  (while paused)
#   ,  (comma)  step back one frame     (while paused)
#   C           mark THIS frame as the crash moment -> saves & next video
#   N           mark this clip as NO CRASH -> saves & next video
#   S           skip this clip without labeling it (come back later)
#   Q           quit (progress so far is already saved)
#
# ============================================================


def load_existing_labels():

    labeled = {}

    if not os.path.exists(LABELS_FILE):
        return labeled

    with open(LABELS_FILE, "r", encoding="utf-8") as file:

        reader = csv.DictReader(file)

        for row in reader:
            labeled[row["filename"]] = row.get("crash_timestamp_sec", "")

    return labeled


def append_label(filename, crash_timestamp_sec):

    file_exists = os.path.exists(LABELS_FILE)

    os.makedirs(os.path.dirname(LABELS_FILE), exist_ok=True)

    with open(LABELS_FILE, "a", newline="", encoding="utf-8") as file:

        writer = csv.writer(file)

        if not file_exists:
            writer.writerow(["filename", "crash_timestamp_sec"])

        writer.writerow([filename, crash_timestamp_sec])


def label_video(video_path, filename):

    capture = cv2.VideoCapture(video_path)

    if not capture.isOpened():
        print(f"Could not open {filename}, skipping.")
        return "skip"

    fps = capture.get(cv2.CAP_PROP_FPS) or 30.0

    playing = True
    frame = None
    frame_index = 0

    print()
    print(f"Labeling: {filename}")
    print("SPACE=play/pause  ,/.=step  C=mark crash  N=no crash  S=skip  Q=quit")

    while True:

        if playing:

            ret, new_frame = capture.read()

            if not ret:
                # Reached the end - loop back to the start so you
                # can re-watch and still make a decision.
                capture.set(cv2.CAP_PROP_POS_FRAMES, 0)
                frame_index = 0
                continue

            frame = new_frame
            frame_index += 1

        if frame is not None:

            display_frame = frame.copy()

            current_time = frame_index / fps

            cv2.putText(
                display_frame,
                f"{filename}  t={current_time:.2f}s  "
                f"{'PLAYING' if playing else 'PAUSED'}",
                (20, 30),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (0, 255, 0) if playing else (0, 255, 255),
                2
            )

            cv2.imshow("Label helper", display_frame)

        key = cv2.waitKey(30 if playing else 0) & 0xFF

        if key == ord(" "):
            playing = not playing

        elif key == ord(".") and not playing:
            ret, new_frame = capture.read()
            if ret:
                frame = new_frame
                frame_index += 1

        elif key == ord(",") and not playing:
            frame_index = max(0, frame_index - 2)
            capture.set(cv2.CAP_PROP_POS_FRAMES, frame_index)
            ret, new_frame = capture.read()
            if ret:
                frame = new_frame
                frame_index += 1

        elif key == ord("c"):
            current_time = frame_index / fps
            capture.release()
            cv2.destroyWindow("Label helper")
            return round(current_time, 2)

        elif key == ord("n"):
            capture.release()
            cv2.destroyWindow("Label helper")
            return None

        elif key == ord("s"):
            capture.release()
            cv2.destroyWindow("Label helper")
            return "skip"

        elif key == ord("q"):
            capture.release()
            cv2.destroyWindow("Label helper")
            return "quit"


def main():

    if not os.path.isdir(VIDEOS_FOLDER):
        print(f"ERROR: videos folder not found at {VIDEOS_FOLDER}")
        return

    video_files = sorted(
        os.path.basename(path)
        for pattern in ("*.mp4", "*.mov", "*.avi", "*.mkv")
        for path in glob.glob(os.path.join(VIDEOS_FOLDER, pattern))
    )

    if not video_files:
        print(f"No video files found in {VIDEOS_FOLDER}")
        return

    already_labeled = load_existing_labels()

    remaining = [f for f in video_files if f not in already_labeled]

    print(f"Total clips: {len(video_files)}")
    print(f"Already labeled: {len(already_labeled)}")
    print(f"Remaining: {len(remaining)}")

    for filename in remaining:

        video_path = os.path.join(VIDEOS_FOLDER, filename)

        result = label_video(video_path, filename)

        if result == "quit":
            print("Stopped. Progress so far is saved in labels.csv.")
            break

        if result == "skip":
            print(f"Skipped {filename} (not saved - will show up again next run).")
            continue

        if result is None:
            append_label(filename, "")
            print(f"Saved: {filename} -> no crash")
        else:
            append_label(filename, result)
            print(f"Saved: {filename} -> crash at {result}s")

    cv2.destroyAllWindows()

    print()
    print(f"Labels file: {LABELS_FILE}")


if __name__ == "__main__":
    main()
