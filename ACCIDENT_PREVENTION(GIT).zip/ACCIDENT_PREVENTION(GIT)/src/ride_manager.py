from gps_tracker import GPSTracker
from data_logger import log_event


class RideManager:

    def __init__(self):

        self.gps = GPSTracker()

        self.warning_count = 0

        print("Ride Manager started.")


    # ========================================================
    # UPDATE GPS LOCATION
    # ========================================================

    def update_gps(self, latitude, longitude):

        distance_added = self.gps.update_location(
            latitude,
            longitude
        )

        return distance_added


    # ========================================================
    # GET CURRENT DISTANCE
    # ========================================================

    def get_distance(self):

        return self.gps.get_total_distance()


    # ========================================================
    # RECORD WARNING
    # ========================================================

    def record_warning(
        self,
        event_type,
        warning_level,
        message
    ):

        distance = self.get_distance()

        self.warning_count += 1

        log_event(
            distance,
            event_type,
            warning_level,
            message
        )

        print()
        print("WARNING RECORDED")
        print("----------------------------")
        print(
            f"Distance : {distance:.2f} km"
        )
        print(
            f"Type     : {event_type}"
        )
        print(
            f"Level    : {warning_level}"
        )
        print(
            f"Message  : {message}"
        )
        print(
            f"Warnings : {self.warning_count}"
        )
        print()


    # ========================================================
    # RIDE SUMMARY
    # ========================================================

    def get_summary(self):

        return {
            "distance_km":
                round(
                    self.get_distance(),
                    2
                ),

            "warnings":
                self.warning_count
        }


# ============================================================
# TEST
# ============================================================

if __name__ == "__main__":

    print()
    print("================================")
    print("       RIDE MANAGER TEST")
    print("================================")
    print()

    ride = RideManager()


    # Starting GPS point
    ride.update_gps(
        12.9716,
        77.5946
    )


    # Simulate movement
    ride.update_gps(
        12.9750,
        77.6000
    )


    # Simulate road warning
    ride.record_warning(
        "ROAD_WARNING",
        "HIGH",
        "Vehicle approaching"
    )


    # More movement
    ride.update_gps(
        12.9800,
        77.6050
    )


    # Simulate distraction
    ride.record_warning(
        "DISTRACTION",
        "MEDIUM",
        "Driver looking away"
    )


    # Summary
    summary = ride.get_summary()


    print("================================")
    print("          RIDE SUMMARY")
    print("================================")

    print(
        f"Distance : "
        f"{summary['distance_km']} km"
    )

    print(
        f"Warnings : "
        f"{summary['warnings']}"
    )

    print()
    print("Ride Manager working successfully!")