"""
predict_risk.py

Loads the trained accident_risk_model.joblib and scores new
ride conditions with a HIGH_SEVERITY probability (0-1) and a
SAFE / CAUTION / HIGH RISK / CRITICAL label - same style of
label the rest of the app (risk_engine.py, road_risk.py) already
uses, so this can be dropped straight into RiskEngine as another
input score (e.g. engine.set_road_risk(context_risk_0_to_100)).

Run:
    python src/predict_risk.py
"""

import os
import json

import pandas as pd
import joblib


PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MODEL_FILE = os.path.join(PROJECT_ROOT, "models", "accident_risk_model.joblib")
META_FILE = os.path.join(PROJECT_ROOT, "models", "accident_risk_features.json")


def load_model():
    if not os.path.exists(MODEL_FILE):
        raise FileNotFoundError(
            f"{MODEL_FILE} not found. Run "
            "src/train_accident_risk_model.py first."
        )

    pipeline = joblib.load(MODEL_FILE)

    with open(META_FILE, "r", encoding="utf-8") as file:
        metadata = json.load(file)

    return pipeline, metadata


def status_from_probability(probability):
    score = probability * 100

    if score < 30:
        return "SAFE"
    elif score < 60:
        return "CAUTION"
    elif score < 80:
        return "HIGH RISK"
    else:
        return "CRITICAL"


def predict(pipeline, metadata, ride_conditions: dict):
    """
    ride_conditions: dict with any subset of the feature columns the
    model was trained on (missing ones are imputed). Example:

        {
            "LightCond": "Dark - Lighted Roadway",
            "Weather": "Rain",
            "RdSurface": "Wet Asphalt",
            "SpeedLimit": "45 - 55 MPH",
            "RuralUrban": "Urban",
            "CrashHour": 22,
        }
    """

    all_features = metadata["categorical_features"] + metadata["numeric_features"]

    row = {feature: ride_conditions.get(feature) for feature in all_features}

    frame = pd.DataFrame([row])

    for column in metadata["categorical_features"]:
        frame[column] = frame[column].astype(str)

    probability = pipeline.predict_proba(frame)[0, 1]

    return {
        "high_severity_probability": round(float(probability), 3),
        "risk_score_0_100": round(float(probability) * 100, 1),
        "status": status_from_probability(probability),
    }


# A "typical" ride, built from the most common value of every
# feature in the training data. Each scenario below starts from
# this baseline and only overrides the factors that differ, so the
# comparison actually isolates those factors instead of drowning
# them in a pile of unseen/missing fields.
BASELINE_CONDITIONS = {
    "LightCond": "Daylight",
    "Weather": "Clear",
    "RdConditio": "Dry",
    "RdSurface": "Smooth Asphalt",
    "RdCharacte": "Straight - Level",
    "RdClass": "Local Street",
    "RdConfig": "Two-Way, Not Divided",
    "RdDefects": "Unknown",
    "RdFeature": "No Special Feature",
    "TraffCntrl": "No Control Present",
    "Workzone": "No",
    "RuralUrban": "Urban",
    "Developmen": "Commercial",
    "Region": "Piedmont",
    "Locality": "Urban (>70% Developed)",
    "BikeAgeGrp": "50-59",
    "BikeSex": "Male",
    "BikePos": "Travel Lane",
    "BikeDir": "With Traffic",
    "BikeAlcFlg": "No",
    "DrvrAgeGrp": "30-39",
    "DrvrSex": "Male",
    "DrvrVehTyp": "Passenger Car",
    "DrvrAlcFlg": "No",
    "CrashAlcoh": "No",
    "CrashType": "Motorist Overtaking - Other / Unknown",
    "CrashGrp": "Motorist Overtaking Bicyclist",
    "CrashLoc": "Non-Intersection",
    "CrashDay": "Friday",
    "CrashMonth": "September",
    "SpeedLimit": "30 - 35  MPH",
    "NumLanes": "2 lanes",
    "CrashHour": 14,
    "NumUnits": 2,
}


def scenario(overrides):
    conditions = dict(BASELINE_CONDITIONS)
    conditions.update(overrides)
    return conditions


if __name__ == "__main__":

    pipeline, metadata = load_model()

    print(f"Model ROC AUC on held-out test set: {metadata['roc_auc']}")
    print()

    example_rides = [
        {
            "name": "Baseline: typical daytime urban ride",
            "conditions": scenario({}),
        },
        {
            "name": "Dark, unlit rural road, high speed limit, no alcohol",
            "conditions": scenario({
                "LightCond": "Dark - Roadway Not Lighted",
                "RuralUrban": "Rural",
                "Locality": "Rural (<30% Developed)",
                "SpeedLimit": "60 - 75 MPH",
                "RdCharacte": "Curve - Grade",
                "TraffCntrl": "No Control Present",
                "CrashHour": 23,
            }),
        },
        {
            "name": "Same dark/rural/high-speed scenario, driver had been drinking",
            "conditions": scenario({
                "LightCond": "Dark - Roadway Not Lighted",
                "RuralUrban": "Rural",
                "Locality": "Rural (<30% Developed)",
                "SpeedLimit": "60 - 75 MPH",
                "RdCharacte": "Curve - Grade",
                "TraffCntrl": "No Control Present",
                "CrashHour": 23,
                "DrvrAlcFlg": "Yes",
                "CrashAlcoh": "Yes",
            }),
        },
    ]

    for example in example_rides:
        result = predict(pipeline, metadata, example["conditions"])

        print(f"Scenario: {example['name']}")
        print(f"  -> {result}")
        print()
