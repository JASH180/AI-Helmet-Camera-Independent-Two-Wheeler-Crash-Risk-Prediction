import os
import sys
import subprocess
import tkinter as tk


# ============================================================
# AI HELMET SAFETY SYSTEM
# MAIN APPLICATION
# ============================================================

PROJECT_ROOT = os.path.dirname(
    os.path.abspath(__file__)
)

SRC = os.path.join(
    PROJECT_ROOT,
    "src"
)

INTERNAL = os.path.join(
    SRC,
    "internal.py"
)

EXTERNAL = os.path.join(
    SRC,
    "external_camera.py"
)

DASHBOARD = os.path.join(
    SRC,
    "dashboard.py"
)


# ============================================================
# PROCESS VARIABLES
# ============================================================

internal_process = None
external_process = None
dashboard_process = None


# ============================================================
# LAUNCH MODULE
# ============================================================

def launch_module(path):

    if not os.path.isfile(path):

        print()
        print("MODULE NOT FOUND:")
        print(path)
        print()

        return None

    try:

        process = subprocess.Popen(
            [
                sys.executable,
                path
            ],
            cwd=PROJECT_ROOT
        )

        return process

    except Exception as error:

        print()
        print("ERROR STARTING MODULE:")
        print(path)
        print(error)
        print()

        return None


# ============================================================
# START AI HELMET
# ============================================================

def start_system():

    global internal_process
    global external_process

    start_button.config(
        state="disabled"
    )

    system_status.config(
        text="● STARTING SYSTEM",
        fg="#facc15"
    )

    activity_label.config(
        text="Initializing driver and road monitoring..."
    )

    root.update()


    # --------------------------------------------------------
    # INTERNAL DRIVER MONITORING
    # --------------------------------------------------------

    if os.path.isfile(INTERNAL):

        internal_process = launch_module(
            INTERNAL
        )

        if internal_process is not None:

            internal_status.config(
                text="RUNNING",
                fg="#22c55e"
            )

        else:

            internal_status.config(
                text="ERROR",
                fg="#ef4444"
            )

    else:

        internal_status.config(
            text="NOT FOUND",
            fg="#ef4444"
        )


    # --------------------------------------------------------
    # EXTERNAL ROAD MONITORING
    # --------------------------------------------------------

    if os.path.isfile(EXTERNAL):

        external_process = launch_module(
            EXTERNAL
        )

        if external_process is not None:

            external_status.config(
                text="RUNNING",
                fg="#22c55e"
            )

        else:

            external_status.config(
                text="ERROR",
                fg="#ef4444"
            )

    else:

        external_status.config(
            text="NOT FOUND",
            fg="#ef4444"
        )


    # --------------------------------------------------------
    # FINAL STATUS
    # --------------------------------------------------------

    if (
        internal_process is not None
        and
        external_process is not None
    ):

        system_status.config(
            text="● SYSTEM ACTIVE",
            fg="#22c55e"
        )

        activity_label.config(
            text=(
                "Driver awareness and road monitoring "
                "are active."
            )
        )

    else:

        system_status.config(
            text="● SYSTEM ERROR",
            fg="#ef4444"
        )

        activity_label.config(
            text=(
                "Check the terminal for the module error."
            )
        )


# ============================================================
# OPEN DASHBOARD
# ============================================================

def open_dashboard():

    global dashboard_process

    dashboard_process = launch_module(
        DASHBOARD
    )

    if dashboard_process is not None:

        dashboard_status.config(
            text="RUNNING",
            fg="#22c55e"
        )


# ============================================================
# STOP ONE PROCESS
# ============================================================

def stop_process(process):

    if process is None:
        return

    try:

        if process.poll() is None:

            process.terminate()

    except Exception:
        pass


# ============================================================
# STOP SYSTEM
# ============================================================

def stop_system():

    global internal_process
    global external_process
    global dashboard_process

    stop_process(
        internal_process
    )

    stop_process(
        external_process
    )

    stop_process(
        dashboard_process
    )

    internal_process = None
    external_process = None
    dashboard_process = None

    internal_status.config(
        text="STOPPED",
        fg="#ef4444"
    )

    external_status.config(
        text="STOPPED",
        fg="#ef4444"
    )

    dashboard_status.config(
        text="STOPPED",
        fg="#ef4444"
    )

    system_status.config(
        text="● SYSTEM STOPPED",
        fg="#ef4444"
    )

    activity_label.config(
        text="Monitoring has been stopped."
    )

    start_button.config(
        state="normal"
    )


# ============================================================
# CLOSE APPLICATION
# ============================================================

def close_application():

    stop_system()

    root.destroy()


# ============================================================
# CREATE WINDOW
# ============================================================

root = tk.Tk()

root.title(
    "AI Helmet Safety System"
)

root.geometry(
    "850x650"
)

root.configure(
    bg="#0f172a"
)

root.resizable(
    False,
    False
)


# ============================================================
# HEADER
# ============================================================

header = tk.Frame(
    root,
    bg="#111827",
    height=125
)

header.pack(
    fill="x"
)


title = tk.Label(
    header,
    text="AI HELMET",
    font=(
        "Segoe UI",
        30,
        "bold"
    ),
    fg="white",
    bg="#111827"
)

title.pack(
    pady=(22, 0)
)


subtitle = tk.Label(
    header,
    text="INTELLIGENT DRIVER SAFETY SYSTEM",
    font=(
        "Segoe UI",
        12
    ),
    fg="#94a3b8",
    bg="#111827"
)

subtitle.pack(
    pady=4
)


# ============================================================
# SYSTEM STATUS
# ============================================================

system_status = tk.Label(
    root,
    text="● SYSTEM READY",
    font=(
        "Segoe UI",
        18,
        "bold"
    ),
    fg="#22c55e",
    bg="#0f172a"
)

system_status.pack(
    pady=(22, 4)
)


activity_label = tk.Label(
    root,
    text="Ready to initialize the AI safety system.",
    font=(
        "Segoe UI",
        11
    ),
    fg="#94a3b8",
    bg="#0f172a"
)

activity_label.pack(
    pady=(0, 18)
)


# ============================================================
# MODULE PANEL
# ============================================================

modules_frame = tk.Frame(
    root,
    bg="#1e293b"
)

modules_frame.pack(
    padx=50,
    fill="x"
)


def add_module(
    row,
    name,
    description
):

    name_label = tk.Label(
        modules_frame,
        text=name,
        font=(
            "Segoe UI",
            12,
            "bold"
        ),
        fg="white",
        bg="#1e293b",
        anchor="w"
    )

    name_label.grid(
        row=row,
        column=0,
        sticky="w",
        padx=25,
        pady=12
    )


    description_label = tk.Label(
        modules_frame,
        text=description,
        font=(
            "Segoe UI",
            10
        ),
        fg="#94a3b8",
        bg="#1e293b",
        anchor="w"
    )

    description_label.grid(
        row=row,
        column=1,
        sticky="w"
    )


    status_label = tk.Label(
        modules_frame,
        text="READY",
        font=(
            "Segoe UI",
            10,
            "bold"
        ),
        fg="#22c55e",
        bg="#1e293b"
    )

    status_label.grid(
        row=row,
        column=2,
        padx=25
    )

    return status_label


internal_status = add_module(
    0,
    "Driver Awareness",
    "Concentration + Drowsiness"
)


external_status = add_module(
    1,
    "Road Monitoring",
    "YOLO Vehicle Detection"
)


gps_status = add_module(
    2,
    "GPS Tracking",
    "Distance & Ride Tracking"
)


logger_status = add_module(
    3,
    "Event Logger",
    "Safety Event Recording"
)


dashboard_status = add_module(
    4,
    "Safety Dashboard",
    "Ride Analysis & Statistics"
)


# ============================================================
# DESCRIPTION
# ============================================================

description = tk.Label(
    root,
    text=(
        "INTERNAL CAMERA\n"
        "Driver concentration • Drowsiness • Awareness\n\n"
        "EXTERNAL CAMERA\n"
        "Vehicle detection • Tracking • Road risk"
    ),
    font=(
        "Segoe UI",
        10
    ),
    fg="#cbd5e1",
    bg="#0f172a",
    justify="center"
)

description.pack(
    pady=22
)


# ============================================================
# BUTTONS
# ============================================================

button_frame = tk.Frame(
    root,
    bg="#0f172a"
)

button_frame.pack()


start_button = tk.Button(
    button_frame,
    text="START AI HELMET",
    command=start_system,
    font=(
        "Segoe UI",
        12,
        "bold"
    ),
    bg="#2563eb",
    fg="white",
    activebackground="#1d4ed8",
    activeforeground="white",
    relief="flat",
    padx=35,
    pady=12,
    cursor="hand2"
)

start_button.grid(
    row=0,
    column=0,
    padx=8
)


dashboard_button = tk.Button(
    button_frame,
    text="OPEN DASHBOARD",
    command=open_dashboard,
    font=(
        "Segoe UI",
        12,
        "bold"
    ),
    bg="#475569",
    fg="white",
    activebackground="#334155",
    activeforeground="white",
    relief="flat",
    padx=35,
    pady=12,
    cursor="hand2"
)

dashboard_button.grid(
    row=0,
    column=1,
    padx=8
)


stop_button = tk.Button(
    button_frame,
    text="STOP",
    command=stop_system,
    font=(
        "Segoe UI",
        12,
        "bold"
    ),
    bg="#dc2626",
    fg="white",
    activebackground="#b91c1c",
    activeforeground="white",
    relief="flat",
    padx=25,
    pady=12,
    cursor="hand2"
)

stop_button.grid(
    row=0,
    column=2,
    padx=8
)


# ============================================================
# FOOTER
# ============================================================

footer = tk.Label(
    root,
    text="AI Helmet Safety System • Integrated Prototype",
    font=(
        "Segoe UI",
        9
    ),
    fg="#64748b",
    bg="#0f172a"
)

footer.pack(
    side="bottom",
    pady=10
)


# ============================================================
# CLOSE EVENT
# ============================================================

root.protocol(
    "WM_DELETE_WINDOW",
    close_application
)


# ============================================================
# RUN APPLICATION
# ============================================================

root.mainloop()