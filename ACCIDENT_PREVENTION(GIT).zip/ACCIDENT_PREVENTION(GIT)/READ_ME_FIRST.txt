AI HELMET - R VISUALIZATION UPDATE
Copy these folders INTO E:\ML PROJECT\ACCIDENT_PREVENTION (say Yes to replace):
  r_analysis\...        (7 new files + live_dashboard\ 4 files; app.R replaces the old one)
  src\train_crash_model.py, src\external_camera.py   (replace)
Optional clean-up: delete r_analysis\live_dashboard\generate_synthetic_ride.R and export_synthetic_ride_csv.R (no longer used).

Order:
 1. RStudio: open the project, then   source("r_analysis/install_packages.R")      (once)
 2. Terminal:  python src/train_crash_model.py        (writes the 3 new CSVs the ML charts need)
 3. RStudio:   source("r_analysis/run_all_plots.R")    (builds all 43 charts)
 4. Open r_analysis/live_dashboard/app.R -> Run App (Run External)
